<div align="center">

# ♘ TITAN OS v1.5 ♘

### Your Local AI SuperNode • Operator → Coordinator → Specialist Agents

<img src="screenshots/titanos_ui.png" width="700" alt="Titan OS Screenshot">

<br>

**100% Local • Multi-Agent • Private • Offline**  
Powered by [Ollama](https://ollama.com) • AGPL-3.0 License

<br>

[⭐ Star this project](https://github.com/jufa44/titan-os/stargazers) — help support local, open AI.

</div>

---

## 🛰️ Overview

**Titan OS** is a **local AI supernode** powered by **Ollama**, featuring:

- **Operator → Coordinator → Specialist multi-agent routing**
- **Cinematic bunker-terminal UI**
- **Performance modes (Fast / Balanced / Quality)**
- **Slash commands and quick actions**
- **Typing indicators & LED agent statuses**
- **Offline, private, no cloud, no API keys**
- **Runs any Ollama model (Phi-3, LLaMA 3, Qwen 2.5, DeepSeek, Mistral)**

Titan OS turns your laptop into a **local autonomous AI mission center**.

Everything runs **100% on your machine.**  
No data leaves your device. There are **no remote calls** of any kind.

---

## 🔥 Features (v1.5)

### 🧠 Multi-Agent Intelligence
- Operator → Coordinator → Specialist flow  
- Automatic agent selection  
- Clean routing messages  
- Local LLM-powered reasoning  

### 🖥️ Hybrid Terminal UI
- CRT scanlines + cinematic glow  
- Tactical bunker-style interface  
- Smooth chat bubble animations  
- Agent LED status lights  

### ⚙️ Performance Mode Switching
- **FAST** → Small models (Phi3 Mini, Qwen 1.5B)  
- **BALANCED** → 3–4B  
- **QUALITY** → 7B+ Q4 quantized  
- Switch instantly, no backend restart  
- Fully local  

### ⌨️ Operator Tools
- Slash commands (`/analyze`, `/research`, `/email`, `/optimize`)  
- Command history (↑ / ↓)  
- Quick actions  
- Mission log export  
- Clean code-block formatting  

### 🔐 Privacy First
- Runs entirely on localhost  
- Powered by Ollama  
- No cloud  
- No accounts  
- No telemetry  
- AGPL-3.0 open-core licensing  

---

## 🚀 Quick Start

### 1. Install Ollama
https://ollama.com/download

### 2. Pull a model (recommended default)
```bash
ollama pull phi3:mini
```

### 3. Clone Titan OS
```bash
git clone https://github.com/jufa44/titan-os
cd titan-os
```

### 4. Create and activate virtual environment
```bash
python -m venv venv
source venv/bin/activate      # macOS/Linux
.\venv\Scripts\activate       # Windows
```

### 5. Install dependencies
```bash
pip install -r requirements.txt
```

### 6. Run Titan OS
```bash
python titan_os.py
```

Open in your browser: **http://127.0.0.1:8000**

---

## 🤖 Supported Models

Titan OS supports all Ollama models, including:

- **Phi-3 Mini** (default)
- **LLaMA 3.2**
- **Qwen 2.5**
- **DeepSeek R1-Distilled**
- **Mistral**
- **Gemma**

See `models.md` for recommended picks by hardware (8GB/16GB/32GB+).

---

## ⚡ Performance Modes

Switch from the UI header:

**FAST**  
🏎️ 1–3B models  
Low memory, laptop-friendly

**BALANCED**  
⚖️ 3–4B quantized  
Great quality & speed

**QUALITY**  
✨ 7B+ Q4  
High-depth reasoning, still fully local

All modes run offline and per-request model selection (no restart required).

---

## 🔐 Privacy & Security

Titan OS is:
- ✅ Fully local
- ✅ Offline
- ✅ Self-hosted
- ✅ Private
- ✅ AGPL-3.0 licensed

No telemetry. No remote calls. No cloud endpoints.

**Your missions stay on your machine.**

---

## 🧩 Project Structure
```
titan-os/
│── titan_os.py           # Main server + UI
│── titan_llm.py          # Local LLM driver (Ollama)
│── requirements.txt
│── models.md             # Recommended local models
│── README.md
│── screenshots/
│── demo/
└── LICENSE
```

---

## 🛣️ Roadmap

### v1.6 – Next
- Memory panel
- Per-agent model specialization
- Configurable agent prompts
- Local filesystem tool

### v2.0 – Titan OS Pro
- Desktop app (Electron)
- Voice commands & wake word
- Browser agent
- File agents (PDF, docs)
- Workflow builder
- Plugin system
- Persistence + session saving

---

## 🤝 Contributing

Pull requests are welcome!  
Titan OS is designed for community growth.

---

## ⚖️ License

**AGPL-3.0**  
Titan OS Core is free for personal and local use.

Commercial hosted versions must remain open-source under AGPL.

Titan OS Pro (paid) will be released under a proprietary license.

---

## ⭐ Support the Project

If you believe in local AI, star the repo:

👉 **https://github.com/jufa44/titan-os**

Together, we push forward the future of private, offline intelligence.

---

<div align="center">

**Built by Julius Hill & Julius Farin**

*Powered by solar energy ☀️*

</div>
