#!/bin/bash
# Titan OS v2 - Development Mode
# ===============================

set -e

echo ""
echo "========================================"
echo "  TITAN OS v2 - Development Mode"
echo "========================================"
echo ""

cd "$(dirname "$0")/../frontend/electron"

# Install dependencies if node_modules doesn't exist
if [ ! -d "node_modules" ]; then
    echo "Installing dependencies..."
    npm install
fi

# Start development mode
echo "Starting development server..."
npm run electron:dev