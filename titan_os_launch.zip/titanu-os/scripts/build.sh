#!/bin/bash
# Titan OS v2 - Unix Build Script
# ================================

set -e

echo ""
echo "========================================"
echo "  TITAN OS v2 - Unix Build"
echo "========================================"
echo ""

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python 3 not found. Please install Python 3.8+"
    exit 1
fi

# Check Node
if ! command -v node &> /dev/null; then
    echo "ERROR: Node.js not found. Please install Node.js 18+"
    exit 1
fi

# Navigate to project root
cd "$(dirname "$0")/.."

# Run build script
python3 scripts/build.py "$@"

echo ""
echo "Build completed successfully!"