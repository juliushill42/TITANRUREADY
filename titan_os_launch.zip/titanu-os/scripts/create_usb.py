#!/usr/bin/env python3
"""
Titan OS v2 - USB Deployment Creator
Creates a portable "Titan OS on a Stick" distribution
"""
import os
import sys
import shutil
import json
from pathlib import Path
from datetime import datetime

PROJECT_ROOT = Path(__file__).parent.parent
DIST_DIR = PROJECT_ROOT / "dist"

def find_drives():
    """Find available USB drives (Windows)"""
    import string
    drives = []
    
    if sys.platform == 'win32':
        import ctypes
        for letter in string.ascii_uppercase:
            drive = f"{letter}:\\"
            try:
                drive_type = ctypes.windll.kernel32.GetDriveTypeW(drive)
                if drive_type == 2:  # DRIVE_REMOVABLE
                    drives.append(drive)
            except:
                pass
    
    return drives

def create_usb_package(output_dir=None):
    """Create complete USB deployment package"""
    if output_dir is None:
        output_dir = DIST_DIR / "USB_Package"
    
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    print(f"Creating USB package at: {output_dir}")
    
    # Create TITAN_DATA structure
    titan_data = output_dir / "TITAN_DATA"
    titan_data.mkdir(exist_ok=True)
    (titan_data / "files").mkdir(exist_ok=True)
    (titan_data / "logs").mkdir(exist_ok=True)
    
    # Initialize memory.json
    memory = {
        "conversations": [],
        "metadata": {
            "version": "2.0",
            "created": datetime.now().isoformat(),
            "last_updated": datetime.now().isoformat()
        }
    }
    (titan_data / "memory.json").write_text(json.dumps(memory, indent=2))
    
    # Copy Electron app if built
    electron_dist = PROJECT_ROOT / "frontend" / "electron" / "dist-electron"
    if electron_dist.exists():
        app_dir = output_dir / "TitanOS"
        if app_dir.exists():
            shutil.rmtree(app_dir)
        shutil.copytree(electron_dist, app_dir)
        print("✅ Electron app copied")
    else:
        print("⚠️ Electron app not built - run build first")
    
    # Copy backend (for embedded Python)
    backend_dest = output_dir / "backend"
    if backend_dest.exists():
        shutil.rmtree(backend_dest)
    shutil.copytree(PROJECT_ROOT / "backend", backend_dest)
    print("✅ Backend copied")
    
    # Create launcher scripts
    (output_dir / "Start_TitanOS.bat").write_text('''@echo off
echo Starting Titan OS v2...
cd /d "%~dp0"
start "" "TitanOS\\Titan OS.exe"
''')
    
    (output_dir / "Start_TitanOS.sh").write_text('''#!/bin/bash
echo "Starting Titan OS v2..."
cd "$(dirname "$0")"
./TitanOS/titan-os-v2
''')
    
    # Create README
    (output_dir / "README.txt").write_text(f'''
╔══════════════════════════════════════════════════════════════╗
║                     TITAN OS v2.0                           ║
║              Your Portable AI Assistant                      ║
╚══════════════════════════════════════════════════════════════╝

INSTALLATION:
1. Copy this entire folder to your USB drive
2. Keep the folder structure intact

RUNNING:
• Windows: Double-click Start_TitanOS.bat
• Linux/Mac: Run ./Start_TitanOS.sh

YOUR DATA:
• All your data is stored in the TITAN_DATA folder
• This includes conversations, files, and settings
• Your data stays on YOUR device - 100% local

FEATURES:
• 🔒 Fully offline - no internet required
• 💾 Portable - runs from any USB drive
• 🧠 Persistent memory across sessions
• 📁 Built-in file management
• 🌐 Web page scraping and summarization
• 🎤 Voice transcription (optional)

Version: 2.0.0
Build: {datetime.now().strftime("%Y-%m-%d")}

LOCAL • SECURE • PRIVATE
''')
    
    # Create version info
    version_info = {
        "version": "2.0.0",
        "build_date": datetime.now().isoformat(),
        "platform": sys.platform
    }
    (output_dir / "version.json").write_text(json.dumps(version_info, indent=2))
    
    print(f"\n✅ USB package created at: {output_dir}")
    return output_dir

def deploy_to_usb(usb_path):
    """Deploy to a specific USB drive"""
    usb_path = Path(usb_path)
    
    if not usb_path.exists():
        print(f"❌ Path does not exist: {usb_path}")
        return False
    
    dest = usb_path / "TitanOS_v2"
    print(f"Deploying to: {dest}")
    
    # Create package
    pkg = create_usb_package(dest)
    
    print(f"\n✅ Titan OS v2 deployed to USB: {dest}")
    return True

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Titan OS v2 USB Deployment")
    parser.add_argument("--output", "-o", help="Output directory")
    parser.add_argument("--usb", "-u", help="Deploy to USB drive path")
    parser.add_argument("--list-drives", action="store_true", help="List removable drives")
    
    args = parser.parse_args()
    
    if args.list_drives:
        drives = find_drives()
        if drives:
            print("Removable drives found:")
            for d in drives:
                print(f"  • {d}")
        else:
            print("No removable drives found")
    elif args.usb:
        deploy_to_usb(args.usb)
    else:
        create_usb_package(args.output)