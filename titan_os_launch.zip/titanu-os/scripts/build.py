#!/usr/bin/env python3
"""
Titan OS v2 - Build Script
Builds the complete application for distribution
"""
import os
import sys
import shutil
import subprocess
import platform
from pathlib import Path

# Configuration
PROJECT_ROOT = Path(__file__).parent.parent
FRONTEND_DIR = PROJECT_ROOT / "frontend" / "electron"
BACKEND_DIR = PROJECT_ROOT / "backend"
DIST_DIR = PROJECT_ROOT / "dist"
BUILD_DIR = PROJECT_ROOT / "build"

def print_header(message):
    print(f"\n{'='*60}")
    print(f"  {message}")
    print(f"{'='*60}\n")

def run_command(cmd, cwd=None, shell=False):
    """Run a command and return success status"""
    print(f"Running: {' '.join(cmd) if isinstance(cmd, list) else cmd}")
    try:
        result = subprocess.run(
            cmd, 
            cwd=cwd, 
            shell=shell,
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            print(f"Error: {result.stderr}")
            return False
        print(result.stdout)
        return True
    except Exception as e:
        print(f"Exception: {e}")
        return False

def clean_build():
    """Clean previous build artifacts"""
    print_header("Cleaning previous builds")
    
    for dir_path in [DIST_DIR, BUILD_DIR]:
        if dir_path.exists():
            print(f"Removing: {dir_path}")
            shutil.rmtree(dir_path)
    
    # Clean frontend build
    renderer_dist = FRONTEND_DIR / "renderer" / "dist"
    if renderer_dist.exists():
        shutil.rmtree(renderer_dist)
    
    print("Clean complete!")
    return True

def install_dependencies():
    """Install all dependencies"""
    print_header("Installing dependencies")
    
    # Install Python dependencies (if requirements.txt exists)
    requirements = BACKEND_DIR / "requirements.txt"
    if requirements.exists():
        if not run_command([sys.executable, "-m", "pip", "install", "-r", str(requirements)]):
            return False
    
    # Install Node dependencies
    if not run_command(["npm", "install"], cwd=FRONTEND_DIR, shell=True):
        return False
    
    print("Dependencies installed!")
    return True

def build_frontend():
    """Build the React frontend with Vite"""
    print_header("Building frontend")
    
    if not run_command(["npm", "run", "build"], cwd=FRONTEND_DIR, shell=True):
        return False
    
    print("Frontend built successfully!")
    return True

def build_electron():
    """Package the Electron application"""
    print_header("Packaging Electron app")
    
    system = platform.system().lower()
    
    if system == "windows":
        cmd = ["npm", "run", "package:win"]
    elif system == "darwin":
        cmd = ["npm", "run", "package:mac"]
    else:
        cmd = ["npm", "run", "package:linux"]
    
    if not run_command(cmd, cwd=FRONTEND_DIR, shell=True):
        return False
    
    print("Electron packaged successfully!")
    return True

def copy_backend():
    """Copy backend files to distribution"""
    print_header("Copying backend files")
    
    dest = DIST_DIR / "backend"
    dest.mkdir(parents=True, exist_ok=True)
    
    # Copy core Python files
    core_src = BACKEND_DIR / "core"
    core_dest = dest / "core"
    shutil.copytree(core_src, core_dest, dirs_exist_ok=True)
    
    # Copy titan_data template
    data_src = BACKEND_DIR / "titan_data"
    data_dest = dest / "titan_data"
    shutil.copytree(data_src, data_dest, dirs_exist_ok=True)
    
    # Copy api_schema.json
    shutil.copy(BACKEND_DIR / "api_schema.json", dest / "api_schema.json")
    
    print("Backend copied successfully!")
    return True

def create_launcher():
    """Create launcher scripts for different platforms"""
    print_header("Creating launcher scripts")
    
    DIST_DIR.mkdir(parents=True, exist_ok=True)
    
    # Windows batch launcher
    win_launcher = DIST_DIR / "TitanOS.bat"
    win_launcher.write_text('''@echo off
echo Starting Titan OS v2...
cd /d "%~dp0"
start "" "Titan OS.exe"
''')
    
    # Unix shell launcher
    unix_launcher = DIST_DIR / "TitanOS.sh"
    unix_launcher.write_text('''#!/bin/bash
echo "Starting Titan OS v2..."
cd "$(dirname "$0")"
./titan-os-v2
''')
    
    print("Launcher scripts created!")
    return True

def create_usb_structure():
    """Create the USB deployment structure"""
    print_header("Creating USB deployment structure")
    
    usb_dir = DIST_DIR / "USB_DEPLOY"
    usb_dir.mkdir(parents=True, exist_ok=True)
    
    # Create TITAN_DATA folder structure
    titan_data = usb_dir / "TITAN_DATA"
    titan_data.mkdir(exist_ok=True)
    (titan_data / "files").mkdir(exist_ok=True)
    (titan_data / "memory.json").write_text('{"conversations": [], "metadata": {"version": "2.0"}}')
    
    # Copy application
    if (FRONTEND_DIR / "dist-electron").exists():
        shutil.copytree(
            FRONTEND_DIR / "dist-electron", 
            usb_dir / "TitanOS",
            dirs_exist_ok=True
        )
    
    # Create README for USB
    readme = usb_dir / "README.txt"
    readme.write_text('''
TITAN OS v2 - USB DEPLOYMENT
============================

1. Copy this entire folder to your USB drive
2. Run TitanOS/Titan OS.exe (Windows) or TitanOS/titan-os-v2 (Linux/Mac)
3. Your data will be stored in TITAN_DATA/

LOCAL • SECURE • PRIVATE

Version: 2.0.0
''')
    
    print(f"USB deployment structure created at: {usb_dir}")
    return True

def build_all():
    """Run complete build process"""
    print_header("TITAN OS v2 BUILD SYSTEM")
    print(f"Platform: {platform.system()}")
    print(f"Python: {sys.version}")
    
    steps = [
        ("Clean", clean_build),
        ("Install Dependencies", install_dependencies),
        ("Build Frontend", build_frontend),
        ("Copy Backend", copy_backend),
        ("Build Electron", build_electron),
        ("Create Launchers", create_launcher),
        ("Create USB Structure", create_usb_structure),
    ]
    
    for name, func in steps:
        if not func():
            print(f"\n❌ Build failed at: {name}")
            return False
    
    print_header("BUILD COMPLETE!")
    print(f"Distribution ready at: {DIST_DIR}")
    return True

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Titan OS v2 Build System")
    parser.add_argument("--clean", action="store_true", help="Clean build only")
    parser.add_argument("--frontend", action="store_true", help="Build frontend only")
    parser.add_argument("--electron", action="store_true", help="Package Electron only")
    parser.add_argument("--usb", action="store_true", help="Create USB structure only")
    
    args = parser.parse_args()
    
    if args.clean:
        clean_build()
    elif args.frontend:
        build_frontend()
    elif args.electron:
        build_electron()
    elif args.usb:
        create_usb_structure()
    else:
        success = build_all()
        sys.exit(0 if success else 1)