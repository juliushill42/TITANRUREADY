#!/usr/bin/env python3
"""
Titan OS v2 - Backend Freezer
Creates standalone Python executable using PyInstaller
"""
import os
import sys
import subprocess
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent
BACKEND_DIR = PROJECT_ROOT / "backend"
DIST_DIR = PROJECT_ROOT / "dist" / "frozen_backend"

def check_pyinstaller():
    """Check if PyInstaller is installed"""
    try:
        import PyInstaller
        return True
    except ImportError:
        print("PyInstaller not found. Installing...")
        subprocess.run([sys.executable, "-m", "pip", "install", "pyinstaller"])
        return True

def freeze_backend():
    """Freeze the Python backend into a standalone executable"""
    if not check_pyinstaller():
        return False
    
    main_script = BACKEND_DIR / "core" / "main.py"
    
    cmd = [
        sys.executable, "-m", "PyInstaller",
        "--onefile",
        "--name", "titan-core",
        "--distpath", str(DIST_DIR),
        "--workpath", str(PROJECT_ROOT / "build" / "pyinstaller"),
        "--specpath", str(PROJECT_ROOT / "build"),
        "--add-data", f"{BACKEND_DIR / 'titan_data'};titan_data",
        "--hidden-import", "json",
        str(main_script)
    ]
    
    print("Freezing backend with PyInstaller...")
    print(f"Command: {' '.join(cmd)}")
    
    result = subprocess.run(cmd, cwd=PROJECT_ROOT)
    
    if result.returncode == 0:
        print(f"\n✅ Backend frozen successfully!")
        print(f"Executable: {DIST_DIR / 'titan-core.exe'}")
        return True
    else:
        print("\n❌ Backend freeze failed!")
        return False

if __name__ == "__main__":
    success = freeze_backend()
    sys.exit(0 if success else 1)