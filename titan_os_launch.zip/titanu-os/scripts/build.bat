@echo off
REM Titan OS v2 - Windows Build Script
REM ===================================

echo.
echo ========================================
echo   TITAN OS v2 - Windows Build
echo ========================================
echo.

REM Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found. Please install Python 3.8+
    exit /b 1
)

REM Check Node
node --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Node.js not found. Please install Node.js 18+
    exit /b 1
)

REM Navigate to project root
cd /d "%~dp0\.."

REM Run build script
python scripts\build.py %*

if errorlevel 1 (
    echo.
    echo Build FAILED!
    pause
    exit /b 1
)

echo.
echo Build completed successfully!
pause