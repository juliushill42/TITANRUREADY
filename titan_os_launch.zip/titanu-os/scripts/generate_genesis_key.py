#!/usr/bin/env python3
"""
Genesis Key Generator for TitanU OS v3.0
Generates exclusive Genesis Keys for the 100 founding operators
"""

import random
import string
import sys

def generate_unique_code(length=6):
    """Generate a random alphanumeric code"""
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=length))

def generate_genesis_key(operator_number):
    """Generate a Genesis Key for a specific operator number"""
    if not 1 <= operator_number <= 100:
        raise ValueError("Operator number must be between 1 and 100")
    
    # Format operator number with leading zeros (001, 002, etc.)
    operator_str = f"{operator_number:03d}"
    
    # Generate unique 6-character code
    unique_code = generate_unique_code(6)
    
    # Construct Genesis Key
    genesis_key = f"TITANU-GENESIS-{operator_str}-{unique_code}"
    
    return genesis_key

def main():
    print("=" * 60)
    print("TitanU OS v3.0 Genesis - Key Generator")
    print("=" * 60)
    print()
    
    if len(sys.argv) > 1:
        # Generate key for specific operator number from command line
        try:
            operator_num = int(sys.argv[1])
            key = generate_genesis_key(operator_num)
            print(f"Genesis Key for Operator #{operator_num:03d}:")
            print(f"\n  {key}\n")
        except ValueError as e:
            print(f"Error: {e}")
            sys.exit(1)
    else:
        # Interactive mode
        print("Generate Genesis Keys for founding operators (1-100)")
        print()
        
        while True:
            try:
                operator_input = input("Enter operator number (1-100) or 'q' to quit: ")
                
                if operator_input.lower() == 'q':
                    break
                
                operator_num = int(operator_input)
                
                if not 1 <= operator_num <= 100:
                    print("❌ Error: Operator number must be between 1 and 100")
                    continue
                
                key = generate_genesis_key(operator_num)
                
                print(f"\n✅ Genesis Key for Operator #{operator_num:03d}:")
                print(f"\n  {key}\n")
                print("-" * 60)
                
            except ValueError:
                print("❌ Error: Please enter a valid number")
            except KeyboardInterrupt:
                print("\n\nExiting...")
                break

if __name__ == "__main__":
    main()