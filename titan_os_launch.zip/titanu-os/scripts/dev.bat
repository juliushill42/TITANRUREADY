@echo off
REM Titan OS v2 - Development Mode
REM ===============================

echo.
echo ========================================
echo   TITAN OS v2 - Development Mode
echo ========================================
echo.

cd /d "%~dp0\..\frontend\electron"

REM Install dependencies if node_modules doesn't exist
if not exist "node_modules" (
    echo Installing dependencies...
    npm install
)

REM Start development mode
echo Starting development server...
npm run electron:dev