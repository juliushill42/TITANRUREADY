# TitanU OS

> Your Portable, Private AI Desktop Assistant

```
  ████████╗██╗████████╗ █████╗ ███╗   ██╗██╗   ██╗
  ╚══██╔══╝██║╚══██╔══╝██╔══██╗████╗  ██║██║   ██║
     ██║   ██║   ██║   ███████║██╔██╗ ██║██║   ██║
     ██║   ██║   ██║   ██╔══██║██║╚██╗██║██║   ██║
     ██║   ██║   ██║   ██║  ██║██║ ╚████║╚██████╔╝
     ╚═╝   ╚═╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝
                    TitanU OS
```

## 🚀 Quick Start

### Development Mode
```bash
# Windows
scripts\dev.bat

# Linux/Mac
./scripts/dev.sh
```

### Production Build
```bash
# Windows
scripts\build.bat

# Linux/Mac
./scripts/build.sh
```

## 🎨 Design System

### Primary Colors
- **Neon Mint**: `#00FFCC`
- **Deep Mint**: `#00DDAA`
- **Cyber Yellow**: `#FFD84A`
- **Dark Graphite**: `#0A0A0A`
- **Deep Navy Black**: `#0F1115`
- **Terminal Gray**: `#1A1F24`

### Typography
- **Terminal Font**: JetBrains Mono
- **Headers**: IBM Plex Sans Condensed
- **Body**: IBM Plex Sans / Inter

## 📁 Project Structure

```
titan_os_v2/
├── backend/              # Python core
│   ├── core/            # Agent modules
│   │   ├── main.py     # Entry point
│   │   ├── boot_sequence.py
│   │   ├── file_agent.py
│   │   ├── memory_agent.py
│   │   ├── browser_agent.py
│   │   └── voice_agent.py
│   └── titan_data/      # Data storage
├── frontend/             # Electron + React
│   └── electron/
│       ├── main.js      # Electron main
│       ├── preload.js   # IPC bridge
│       └── renderer/    # React app
├── bridge/               # Protocol docs
│   ├── protocol.md
│   └── examples/
├── scripts/              # Build scripts
└── pro/                  # Pro features (upcoming)
```

## 🔧 Architecture

- **Frontend**: Electron + React + Vite
- **Backend**: Python 3.8+
- **Protocol**: STDIN/STDOUT JSON
- **Design System**: Cyberpunk Terminal UI

## 📦 Building for Distribution

```bash
python scripts/build.py
```

Creates:
- Electron app for current platform
- USB deployment package
- Portable launchers

## 🔒 Features

- ✅ 100% Local - No cloud, no tracking
- ✅ Portable - Run from USB
- ✅ File Management - Save/read files
- ✅ Memory System - Persistent conversations
- ✅ Custom AI Agents - Create specialized agents from natural language
- ✅ Web Scraping - Fetch and summarize URLs (v3.1+)
- ✅ Voice Ready - Transcription support (optional)
- ✅ TITAN Personality - Context-aware AI that knows its capabilities

## 🤖 AI Agent System

TitanU OS features a powerful agent creation system:

- **4 Built-in Templates**: Research Agent, Code Agent, Writing Agent, Data Analyst
- **Custom Agents**: Create agents from natural language descriptions
- **Specialized Prompts**: Each agent has its own system prompt and temperature
- **Easy Invocation**: Use `@agent_name` or natural language to invoke agents

## 📜 License

MIT License

---

**TitanU OS** • Local • Secure • Private