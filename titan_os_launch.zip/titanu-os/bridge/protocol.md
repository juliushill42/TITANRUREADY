# Titan OS v2 - JSON Protocol Documentation

## Overview

Titan OS v2 uses a STDIN/STDOUT JSON protocol for communication between the Electron frontend and Python backend. All messages are newline-delimited JSON objects.

## Message Format

### Request Format
```json
{
    "command": "command_name",
    "params": {
        "param1": "value1",
        "param2": "value2"
    }
}
```

### Response Format
```json
{
    "status": "success|error|ready|online",
    "message": "Human-readable message (optional)",
    "data": { ... },
    "error": "Error description (only if status is error)"
}
```

---

## System Commands

### boot
Initialize Titan Core and detect USB drive.

**Request:**
```json
{"command": "boot", "params": {}}
```

**Response:**
```json
{
    "status": "online",
    "drive_letter": "E:" or null,
    "message": "Titan Core Active. Welcome.",
    "data": {
        "system_info": {
            "platform": "Windows",
            "platform_version": "10.0.19041",
            "python_version": "3.11.0",
            "boot_time": "2024-01-15T10:30:00"
        },
        "titan_data_path": "E:\\TITAN_DATA",
        "memory_initialized": true,
        "usb_detected": true
    }
}
```

### shutdown
Gracefully shutdown Titan Core.

**Request:**
```json
{"command": "shutdown", "params": {}}
```

**Response:**
```json
{
    "status": "success",
    "message": "Titan Core shutting down. Goodbye."
}
```

---

## File Commands

### save_file
Save content to a file in Titan storage.

**Request:**
```json
{
    "command": "save_file",
    "params": {
        "filename": "notes.txt",
        "content": "My notes content here",
        "subfolder": "documents"
    }
}
```

**Parameters:**
- `filename` (required): Name of the file
- `content` (required): Content to save
- `subfolder` (optional): Subfolder within files/

**Response:**
```json
{
    "status": "success",
    "data": {
        "path": "E:\\TITAN_DATA\\files\\documents\\notes.txt",
        "size": 21,
        "saved_at": "2024-01-15T10:35:00"
    }
}
```

### read_file
Read content from a file in Titan storage.

**Request:**
```json
{
    "command": "read_file",
    "params": {
        "filename": "notes.txt",
        "subfolder": "documents"
    }
}
```

**Response:**
```json
{
    "status": "success",
    "data": {
        "content": "My notes content here",
        "size": 21,
        "path": "E:\\TITAN_DATA\\files\\documents\\notes.txt"
    }
}
```

### list_files
List files in Titan storage.

**Request:**
```json
{
    "command": "list_files",
    "params": {
        "subfolder": "",
        "recursive": true
    }
}
```

**Response:**
```json
{
    "status": "success",
    "data": {
        "files": [
            {
                "name": "notes.txt",
                "path": "documents/notes.txt",
                "size": 21,
                "modified": "2024-01-15T10:35:00"
            }
        ],
        "count": 1,
        "base_path": "E:\\TITAN_DATA\\files"
    }
}
```

---

## Memory Commands

### log_memory
Log a conversation turn to memory.

**Request:**
```json
{
    "command": "log_memory",
    "params": {
        "role": "user",
        "content": "Hello, Titan!",
        "session_id": "session_123",
        "metadata": {"source": "terminal"}
    }
}
```

**Parameters:**
- `role` (required): "user", "assistant", or "system"
- `content` (required): Message content
- `session_id` (optional): Session identifier (default: "default")
- `metadata` (optional): Additional metadata

**Response:**
```json
{
    "status": "success",
    "data": {
        "entry_id": 42,
        "total_entries": 100,
        "session_id": "session_123"
    }
}
```

### get_memory
Retrieve conversation memory.

**Request:**
```json
{
    "command": "get_memory",
    "params": {
        "session_id": null,
        "limit": 50,
        "offset": 0
    }
}
```

**Response:**
```json
{
    "status": "success",
    "data": {
        "entries": [
            {
                "id": 1,
                "timestamp": "2024-01-15T10:30:00",
                "session_id": "default",
                "role": "user",
                "content": "Hello",
                "metadata": {}
            }
        ],
        "total": 100,
        "limit": 50,
        "offset": 0,
        "metadata": {
            "version": "2.0",
            "last_updated": "2024-01-15T10:35:00"
        }
    }
}
```

### clear_memory
Clear conversation memory.

**Request:**
```json
{
    "command": "clear_memory",
    "params": {
        "session_id": null,
        "confirm": true
    }
}
```

**Response:**
```json
{
    "status": "success",
    "message": "Cleared 100 memory entries",
    "data": {
        "cleared_count": 100,
        "remaining_count": 0
    }
}
```

---

## Browser Commands

### scrape_url
Fetch and extract text from a URL.

**Request:**
```json
{
    "command": "scrape_url",
    "params": {
        "url": "https://example.com",
        "timeout": 10
    }
}
```

**Response:**
```json
{
    "status": "success",
    "data": {
        "url": "https://example.com",
        "title": "Example Domain",
        "text": "This domain is for use in illustrative examples...",
        "length": 1256,
        "truncated": false
    }
}
```

### summarize
Summarize text content.

**Request:**
```json
{
    "command": "summarize",
    "params": {
        "text": "Long text content here...",
        "max_sentences": 5
    }
}
```

**Response:**
```json
{
    "status": "success",
    "data": {
        "summary": "Extracted summary sentences here.",
        "original_length": 5000,
        "summary_length": 250,
        "sentences": 5
    }
}
```

---

## Voice Commands

### transcribe_audio
Transcribe audio file to text.

**Request:**
```json
{
    "command": "transcribe_audio",
    "params": {
        "audio_path": "C:\\temp\\recording.wav",
        "language": "en-US",
        "engine": "sphinx"
    }
}
```

**Parameters:**
- `audio_path` (required): Path to WAV audio file
- `language` (optional): Language code (default: "en-US")
- `engine` (optional): "sphinx", "google", or "whisper" (default: "sphinx")

**Response:**
```json
{
    "status": "success",
    "data": {
        "text": "Transcribed text here",
        "confidence": 0.7,
        "engine": "sphinx",
        "language": "en-US",
        "audio_path": "C:\\temp\\recording.wav"
    }
}
```

### voice_status
Check voice recognition capabilities.

**Request:**
```json
{"command": "voice_status", "params": {}}
```

**Response:**
```json
{
    "status": "success",
    "data": {
        "available": true,
        "engines": ["sphinx", "google"],
        "recommended": "sphinx",
        "install_instructions": null
    }
}
```

---

## Error Handling

All errors return with `status: "error"`:

```json
{
    "status": "error",
    "error": "Detailed error message"
}
```

Common error types:
- Missing required parameter
- File not found
- Invalid command
- Network error (for browser commands)
- Transcription failure (for voice commands)

---

## Status Codes

| Status | Description |
|--------|-------------|
| `ready` | Backend is initialized and waiting for commands |
| `online` | Boot sequence completed successfully |
| `success` | Command completed successfully |
| `error` | Command failed |
| `shutdown` | Backend is shutting down |

---

## Implementation Notes

1. All responses are newline-delimited JSON
2. Commands are processed sequentially (one at a time)
3. Memory is auto-rotated at 1000 entries
4. USB drive detection checks for TITAN_DATA folder
5. File operations include directory traversal protection