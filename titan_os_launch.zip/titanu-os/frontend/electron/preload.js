/**
 * Titan OS v2 - Preload Script
 * Exposes secure IPC methods to renderer process
 */
const { contextBridge, ipcRenderer } = require('electron');

// Expose protected methods to renderer
contextBridge.exposeInMainWorld('titanAPI', {
    // Send command to Python backend (fire and forget)
    sendCommand: (command, params = {}) => {
        ipcRenderer.send('send-command', { command, params });
    },

    // Send command and wait for response (async)
    invokeCommand: async (command, params = {}) => {
        return await ipcRenderer.invoke('invoke-command', { command, params });
    },

    // Listen for Python responses
    onResponse: (callback) => {
        const handler = (event, response) => callback(response);
        ipcRenderer.on('python-response', handler);
        
        // Return cleanup function
        return () => {
            ipcRenderer.removeListener('python-response', handler);
        };
    },

    // Platform info
    platform: process.platform,
    
    // App version
    version: '2.0.0'
});

// Log that preload is ready
console.log('[Preload] Titan API exposed to renderer');