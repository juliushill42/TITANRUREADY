/**
 * TITANU AI — TitanU OS v3.0 Genesis
 * Unified Workspace Component
 * Main TITAN Chat interface - unified workspace design
 * Preserves neon-mint cyber aesthetic with scanline and glossy effects
 */
import React, { useState, useRef, useEffect } from 'react';
import { sendCommand } from '../utils/ipc';
import UnifiedMessage from './UnifiedMessage';
import InputBar from './InputBar';

// Quick Action Button Component
const QuickActionButton = ({ icon, label, onClick }) => (
    <button
        onClick={onClick}
        className="quick-action-btn"
        style={{
            display: 'flex',
            alignItems: 'center',
            gap: '4px',
            padding: '6px 12px',
            backgroundColor: 'rgba(0, 255, 136, 0.05)',
            border: '1px solid rgba(0, 255, 136, 0.2)',
            borderRadius: '16px',
            color: '#00ff88',
            cursor: 'pointer',
            fontSize: '12px',
            fontFamily: 'var(--font-mono)',
            transition: 'all 0.2s ease'
        }}
        onMouseEnter={(e) => {
            e.target.style.backgroundColor = 'rgba(0, 255, 136, 0.15)';
            e.target.style.borderColor = 'rgba(0, 255, 136, 0.4)';
            e.target.style.boxShadow = '0 0 10px rgba(0, 255, 136, 0.2)';
        }}
        onMouseLeave={(e) => {
            e.target.style.backgroundColor = 'rgba(0, 255, 136, 0.05)';
            e.target.style.borderColor = 'rgba(0, 255, 136, 0.2)';
            e.target.style.boxShadow = 'none';
        }}
    >
        <span>{icon}</span>
        <span>{label}</span>
    </button>
);

// Quick Actions Bar Component
const QuickActions = ({ onAction }) => (
    <div style={{
        display: 'flex',
        gap: '8px',
        padding: '8px 16px',
        borderTop: '1px solid rgba(0, 255, 136, 0.1)',
        justifyContent: 'center',
        flexWrap: 'wrap',
        background: 'rgba(15, 17, 21, 0.6)'
    }}>
        <QuickActionButton
            icon="🤖"
            label="+ Agent"
            onClick={() => onAction('create agent')}
        />
    </div>
);

// Welcome banner ASCII art
const WelcomeBanner = () => (
    <div className="terminal-welcome">
        <pre className="welcome-ascii">
{`
  ████████╗██╗████████╗ █████╗ ███╗   ██╗██╗   ██╗
  ╚══██╔══╝██║╚══██╔══╝██╔══██╗████╗  ██║██║   ██║
     ██║   ██║   ██║   ███████║██╔██╗ ██║██║   ██║
     ██║   ██║   ██║   ██╔══██║██║╚██╗██║██║   ██║
     ██║   ██║   ██║   ██║  ██║██║ ╚████║╚██████╔╝
     ╚═╝   ╚═╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝
              TITAN CHAT • v3.0 Genesis
`}
        </pre>
        <div className="welcome-subtitle">
            <span className="welcome-bracket">[</span>
            <span className="welcome-text-inner">TitanU OS</span>
            <span className="welcome-bracket">]</span>
        </div>
        <p className="welcome-text">
            Welcome to TITAN. Type <code>/help</code> for available commands or just chat naturally.
        </p>
        <p className="welcome-secure text-success">
            🔒 LOCAL • SECURE • PRIVATE
        </p>
    </div>
);

/**
 * UnifiedWorkspace - Main TITAN Chat workspace component
 * @param {Object} props
 * @param {Array} props.responses - Array of backend responses
 * @param {Object} props.systemStatus - System status object
 */
function UnifiedWorkspace({
    responses,
    systemStatus
}) {
    const [messages, setMessages] = useState([]);
    const [commandHistory, setCommandHistory] = useState([]);
    const [showBanner, setShowBanner] = useState(true);
    const scrollRef = useRef(null);
    const messageIdRef = useRef(0);

    // Generate unique message ID
    const generateId = () => {
        messageIdRef.current += 1;
        return `msg-${Date.now()}-${messageIdRef.current}`;
    };

    // Process backend responses into messages
    useEffect(() => {
        if (responses.length > 0) {
            const lastResponse = responses[responses.length - 1];
            
            // Skip boot/ready responses to keep welcome screen clean
            if (lastResponse.status === 'online' || lastResponse.status === 'ready') {
                return;
            }

            // Skip panel navigation responses (they're handled by panels themselves)
            // These are background requests from panels like Memory, Files, etc.
            if (lastResponse.command) {
                const panelCommands = ['get_memory', 'list_files', 'files'];
                if (panelCommands.includes(lastResponse.command)) {
                    return;
                }
            }

            // Determine message type based on response
            let messageType = 'system-response';
            let status = lastResponse.status;
            
            if (lastResponse.error) {
                messageType = 'error';
                status = 'error';
            } else if (lastResponse.status === 'success') {
                status = 'success';
            }

            // Build content from response - ONLY show JSON for actual errors or specific commands
            let content = lastResponse.message || '';
            
            // Only show JSON data for errors or if there's no message
            if (lastResponse.error) {
                content = lastResponse.error;
                if (lastResponse.data) {
                    content += '\n' + JSON.stringify(lastResponse.data, null, 2);
                }
            } else if (!content && lastResponse.data && lastResponse.data.response) {
                // If there's a response field in data, use that instead of raw JSON
                content = lastResponse.data.response;
            }

            const newMessage = {
                id: generateId(),
                type: messageType,
                content: content,
                timestamp: new Date(),
                status: status
            };

            setMessages(prev => [...prev, newMessage]);
            setShowBanner(false);
        }
    }, [responses]);

    // Auto-scroll to bottom when new messages arrive
    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
    }, [messages]);

    // Parse and execute command
    const executeCommand = (commandStr) => {
        const trimmed = commandStr.trim();
        if (!trimmed) return;

        // Add to command history
        setCommandHistory(prev => [...prev.filter(h => h !== trimmed), trimmed]);

        // Add user message
        const userMessage = {
            id: generateId(),
            type: 'user-command',
            content: trimmed,
            timestamp: new Date()
        };
        setMessages(prev => [...prev, userMessage]);
        setShowBanner(false);

        // Parse command - handle both / prefixed and regular commands
        let command = trimmed;
        if (command.startsWith('/')) {
            command = command.slice(1);
        }
        
        const parts = command.split(/\s+/);
        const cmd = parts[0].toLowerCase();
        
        // Handle special local commands
        if (cmd === 'clear') {
            setMessages([]);
            setShowBanner(true);
            return;
        }
        
        if (cmd === 'help') {
            const helpMessage = {
                id: generateId(),
                type: 'llm-response',
                content: `Available commands:
• /help - Show this help message
• /memory - View memory entries
• /files - List files in workspace
• /upload - Upload a file (or click 📎)
• /clear - Clear terminal output
• boot - Initialize TitanU Core
• shutdown - Shutdown TitanU Core
• save <filename> <content> - Save a file
• read <filename> - Read a file
• scrape <url> - Scrape a webpage
• summarize <text> - Summarize text

You can also type natural language prompts.`,
                timestamp: new Date(),
                status: 'success'
            };
            setMessages(prev => [...prev, helpMessage]);
            return;
        }

        // Build params based on command
        let params = {};
        
        switch (cmd) {
            case 'save':
                params = { filename: parts[1], content: parts.slice(2).join(' ') };
                sendCommand('save_file', params);
                break;
            case 'read':
                params = { filename: parts[1] };
                sendCommand('read_file', params);
                break;
            case 'files':
            case 'list':
                sendCommand('list_files', { recursive: parts.includes('-r') });
                break;
            case 'memory':
                sendCommand('get_memory', { limit: parseInt(parts[1]) || 20 });
                break;
            case 'scrape':
                sendCommand('scrape_url', { url: parts[1] });
                break;
            case 'summarize':
                sendCommand('summarize', { text: parts.slice(1).join(' ') });
                break;
            case 'boot':
                sendCommand('boot', {});
                break;
            case 'shutdown':
                sendCommand('shutdown', {});
                break;
            default:
                // For natural language prompts, send to AI
                if (trimmed.length > 2) {
                    // Add a "thinking" message
                    const thinkingMessage = {
                        id: generateId(),
                        type: 'info',
                        content: 'Processing your request...',
                        timestamp: new Date()
                    };
                    setMessages(prev => [...prev, thinkingMessage]);
                    
                    // Send as prompt to backend
                    sendCommand('prompt', { text: trimmed });
                } else {
                    // Try sending as raw command
                    sendCommand(cmd, {});
                }
        }
    };

    // Handle command history navigation
    const handleHistoryNav = (direction, index) => {
        // History navigation is handled in InputBar
        // This callback can be used for additional processing if needed
    };

    // Add a message to the chat (used by InputBar for upload status)
    const addMessage = (messageData) => {
        const newMessage = {
            id: generateId(),
            type: messageData.role === 'assistant' ? 'llm-response' :
                  messageData.role === 'system' ? 'info' : 'user-command',
            content: messageData.content,
            timestamp: new Date(),
            status: messageData.role === 'assistant' ? 'success' : undefined
        };
        setMessages(prev => [...prev, newMessage]);
        setShowBanner(false);
    };

    return (
        <div className="unified-workspace">
            {/* Header */}
            <header className="workspace-header">
                <div className="header-dots">
                    <span className="dot dot--red"></span>
                    <span className="dot dot--yellow"></span>
                    <span className="dot dot--green"></span>
                </div>
                <span className="header-title">TITAN CHAT</span>
                <span className="header-status status-breathing">
                    {systemStatus.online ? '● CONNECTED' : '○ DISCONNECTED'}
                </span>
            </header>

            {/* Output Area */}
            <div className="unified-output" ref={scrollRef}>
                {showBanner && <WelcomeBanner />}
                
                {messages.map(msg => (
                    <UnifiedMessage
                        key={msg.id}
                        type={msg.type}
                        content={msg.content}
                        timestamp={msg.timestamp}
                        status={msg.status}
                    />
                ))}
            </div>

            {/* Input Bar */}
            <InputBar
                onSubmit={executeCommand}
                onHistoryNav={handleHistoryNav}
                commandHistory={commandHistory}
                onAddMessage={addMessage}
            />

            {/* Quick Actions Bar */}
            <QuickActions onAction={executeCommand} />

            {/* Inline styles for welcome banner (keeping from TerminalView) */}
            <style jsx>{`
                .terminal-welcome {
                    text-align: center;
                    padding: var(--spacing-xl);
                    color: var(--text-secondary);
                    animation: fadeIn 0.45s ease-out forwards;
                }

                @keyframes fadeIn {
                    from { 
                        opacity: 0; 
                        transform: translateY(10px);
                    }
                    to { 
                        opacity: 1; 
                        transform: translateY(0);
                    }
                }

                .welcome-ascii {
                    color: var(--neon-mint);
                    font-size: 9px;
                    line-height: 1.15;
                    margin-bottom: var(--spacing-md);
                    text-shadow: 
                        0 0 10px var(--glow-soft),
                        0 0 20px rgba(0, 255, 200, 0.1);
                    letter-spacing: 0.05em;
                }

                .welcome-subtitle {
                    margin-bottom: var(--spacing-lg);
                    font-size: 14px;
                    letter-spacing: 0.3em;
                }

                .welcome-bracket {
                    color: var(--cyber-yellow);
                    font-weight: bold;
                }

                .welcome-text-inner {
                    color: var(--text-primary);
                    margin: 0 8px;
                }

                .welcome-text {
                    margin-bottom: var(--spacing-sm);
                    color: var(--text-secondary);
                }

                .welcome-text code {
                    color: var(--neon-mint);
                    background: rgba(0, 255, 200, 0.1);
                    padding: 2px 8px;
                    border-radius: var(--radius-sm);
                    border: 1px solid rgba(0, 255, 200, 0.2);
                }

                .welcome-secure {
                    font-weight: 600;
                    letter-spacing: 0.1em;
                    text-shadow: 0 0 8px var(--glow-soft);
                }

                .text-success {
                    color: var(--success);
                }

                /* Scanline effect for workspace */
                .unified-workspace::after {
                    content: "";
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 2px;
                    background: linear-gradient(90deg, transparent, rgba(0, 255, 200, 0.15), transparent);
                    animation: scanline 4s linear infinite;
                    pointer-events: none;
                    opacity: 0.5;
                    z-index: 10;
                }

                @keyframes scanline {
                    0% { transform: translateY(-100%); }
                    100% { transform: translateY(100vh); }
                }

                /* Glossy reflection overlay */
                .unified-workspace::before {
                    content: "";
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: linear-gradient(
                        135deg,
                        rgba(255, 255, 255, 0.03) 0%,
                        rgba(0, 0, 0, 0.05) 40%,
                        rgba(255, 255, 255, 0.02) 100%
                    );
                    pointer-events: none;
                    z-index: 1;
                }

                /* Status badge styles */
                .status-badge {
                    font-family: var(--font-mono);
                    font-size: 10px;
                    font-weight: 600;
                    padding: 2px 6px;
                    border-radius: var(--radius-sm);
                    text-transform: uppercase;
                    letter-spacing: 0.05em;
                }

                .status-badge--success {
                    color: var(--success);
                    background: rgba(0, 255, 200, 0.1);
                    border: 1px solid rgba(0, 255, 200, 0.3);
                }

                .status-badge--error {
                    color: var(--error);
                    background: rgba(255, 68, 102, 0.1);
                    border: 1px solid rgba(255, 68, 102, 0.3);
                }

                .status-badge--loading {
                    color: var(--cyber-yellow);
                    background: rgba(255, 216, 74, 0.1);
                    border: 1px solid rgba(255, 216, 74, 0.3);
                    animation: pulse 1.5s ease-in-out infinite;
                }

                @keyframes pulse {
                    0%, 100% { opacity: 1; }
                    50% { opacity: 0.6; }
                }

                /* Message content styles */
                .source-label {
                    font-family: var(--font-mono);
                    font-size: 10px;
                    font-weight: 600;
                    color: var(--neon-mint);
                    text-transform: uppercase;
                    letter-spacing: 0.1em;
                }

                .message-header {
                    display: flex;
                    align-items: center;
                    gap: var(--spacing-sm);
                    margin-bottom: var(--spacing-xs);
                }

                .timestamp {
                    font-family: var(--font-mono);
                    font-size: 10px;
                    color: var(--text-muted);
                    margin-left: auto;
                }

                .info-icon {
                    color: var(--cyber-yellow);
                    margin-right: var(--spacing-xs);
                }

                /* Command suggestion description */
                .command-suggestion__cmd {
                    color: var(--neon-mint);
                    font-weight: 500;
                }

                .command-suggestion__desc {
                    color: var(--text-muted);
                    font-size: 11px;
                    margin-left: var(--spacing-sm);
                }
            `}</style>
        </div>
    );
}

export default UnifiedWorkspace;