/**
 * TITANU AI — TitanU OS v3.0 Genesis
 * Input Bar Component
 * Enhanced input with command suggestions, voice support, and file upload
 * Preserves neon-mint cyber aesthetic
 */
import React, { useState, useRef, useEffect } from 'react';
import VoiceButton from './VoiceButton';
import { uploadFile, ALLOWED_EXTENSIONS } from '../utils/ipc';

// Available commands for suggestions
const COMMANDS = [
    { command: '/help', description: 'Show available commands' },
    { command: '/memory', description: 'View memory entries' },
    { command: '/files', description: 'List files' },
    { command: '/clear', description: 'Clear terminal output' },
    { command: '/upload', description: 'Upload a file' }
];

// Convert allowed extensions to accept string for file input
const ACCEPT_STRING = ALLOWED_EXTENSIONS.join(',');

/**
 * InputBar - Enhanced input bar with command suggestions and file upload
 * @param {Object} props
 * @param {Function} props.onSubmit - Called when user submits input
 * @param {Function} props.onHistoryNav - Called for history navigation (up/down)
 * @param {string[]} props.commandHistory - Array of previous commands
 * @param {Function} props.onAddMessage - Called to add messages to chat (for upload status)
 */
function InputBar({
    onSubmit,
    onHistoryNav,
    commandHistory = [],
    onAddMessage
}) {
    const [input, setInput] = useState('');
    const [showSuggestions, setShowSuggestions] = useState(false);
    const [filteredCommands, setFilteredCommands] = useState([]);
    const [selectedSuggestion, setSelectedSuggestion] = useState(0);
    const [historyIndex, setHistoryIndex] = useState(-1);
    const [uploading, setUploading] = useState(false);
    const inputRef = useRef(null);
    const fileInputRef = useRef(null);

    // Filter commands based on input
    useEffect(() => {
        if (input.startsWith('/')) {
            const query = input.toLowerCase();
            const filtered = COMMANDS.filter(cmd => 
                cmd.command.toLowerCase().startsWith(query)
            );
            setFilteredCommands(filtered);
            setShowSuggestions(filtered.length > 0);
            setSelectedSuggestion(0);
        } else {
            setShowSuggestions(false);
            setFilteredCommands([]);
        }
    }, [input]);

    // Focus input on mount
    useEffect(() => {
        if (inputRef.current) {
            inputRef.current.focus();
        }
    }, []);

    const handleInputChange = (e) => {
        setInput(e.target.value);
        setHistoryIndex(-1);
    };

    const handleSubmit = () => {
        const trimmed = input.trim();
        if (!trimmed) return;

        // Handle /upload command
        if (trimmed.toLowerCase() === '/upload') {
            fileInputRef.current?.click();
            setInput('');
            return;
        }

        // Handle command selection from suggestions
        if (showSuggestions && filteredCommands.length > 0) {
            const selected = filteredCommands[selectedSuggestion];
            if (selected) {
                if (selected.command === '/upload') {
                    fileInputRef.current?.click();
                    setInput('');
                    setShowSuggestions(false);
                    return;
                }
                onSubmit(selected.command);
                setInput('');
                setShowSuggestions(false);
                return;
            }
        }

        onSubmit(trimmed);
        setInput('');
        setShowSuggestions(false);
        setHistoryIndex(-1);
    };

    const handleFileSelect = async (e) => {
        const file = e.target.files?.[0];
        if (!file) return;
        
        setUploading(true);
        
        try {
            const result = await uploadFile(file);
            
            if (result?.status === 'success' && result?.data?.success) {
                // Add system message about successful upload
                if (onAddMessage) {
                    onAddMessage({
                        role: 'system',
                        content: `📎 Uploaded: ${file.name}`
                    });
                    onAddMessage({
                        role: 'assistant',
                        content: `File "${result.data.filename}" uploaded successfully!\n\n` +
                            `📁 **Path:** \`${result.data.path}\`\n` +
                            `📊 **Size:** ${(result.data.size / 1024).toFixed(1)} KB\n\n` +
                            `You can now ask me to analyze or process this file.`
                    });
                }
            } else {
                const errorMsg = result?.data?.error || result?.message || 'Unknown error';
                if (onAddMessage) {
                    onAddMessage({
                        role: 'system',
                        content: `❌ Upload failed: ${errorMsg}`
                    });
                } else {
                    alert('Upload failed: ' + errorMsg);
                }
            }
        } catch (error) {
            const errorMsg = error.message || 'Upload failed';
            if (onAddMessage) {
                onAddMessage({
                    role: 'system',
                    content: `❌ Upload error: ${errorMsg}`
                });
            } else {
                alert('Upload failed: ' + errorMsg);
            }
        } finally {
            setUploading(false);
            // Reset the file input
            if (fileInputRef.current) {
                fileInputRef.current.value = '';
            }
        }
    };

    const handleUploadClick = () => {
        fileInputRef.current?.click();
    };

    const handleKeyDown = (e) => {
        // Handle suggestion navigation
        if (showSuggestions && filteredCommands.length > 0) {
            if (e.key === 'ArrowUp') {
                e.preventDefault();
                setSelectedSuggestion(prev => 
                    prev > 0 ? prev - 1 : filteredCommands.length - 1
                );
                return;
            }
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                setSelectedSuggestion(prev => 
                    prev < filteredCommands.length - 1 ? prev + 1 : 0
                );
                return;
            }
            if (e.key === 'Tab') {
                e.preventDefault();
                const selected = filteredCommands[selectedSuggestion];
                if (selected) {
                    setInput(selected.command + ' ');
                    setShowSuggestions(false);
                }
                return;
            }
            if (e.key === 'Escape') {
                e.preventDefault();
                setShowSuggestions(false);
                return;
            }
        }

        // Handle command history navigation
        if (e.key === 'ArrowUp' && !showSuggestions) {
            e.preventDefault();
            if (commandHistory.length > 0) {
                const newIndex = historyIndex < commandHistory.length - 1 
                    ? historyIndex + 1 
                    : historyIndex;
                setHistoryIndex(newIndex);
                setInput(commandHistory[commandHistory.length - 1 - newIndex] || '');
                if (onHistoryNav) onHistoryNav('up', newIndex);
            }
            return;
        }

        if (e.key === 'ArrowDown' && !showSuggestions) {
            e.preventDefault();
            if (historyIndex > 0) {
                const newIndex = historyIndex - 1;
                setHistoryIndex(newIndex);
                setInput(commandHistory[commandHistory.length - 1 - newIndex] || '');
                if (onHistoryNav) onHistoryNav('down', newIndex);
            } else {
                setHistoryIndex(-1);
                setInput('');
            }
            return;
        }

        // Handle Enter key
        if (e.key === 'Enter') {
            e.preventDefault();
            handleSubmit();
        }
    };

    const handleSuggestionClick = (command) => {
        setInput(command + ' ');
        setShowSuggestions(false);
        inputRef.current?.focus();
    };

    return (
        <div className="input-bar input-container">
            <div className="input-wrapper">
                <span className="input-bar__prompt">TITAN›</span>
                
                <input
                    ref={inputRef}
                    type="text"
                    className="input-bar__field chat-input"
                    value={input}
                    onChange={handleInputChange}
                    onKeyDown={handleKeyDown}
                    placeholder="Enter command or message..."
                    autoComplete="off"
                    spellCheck="false"
                />

            {showSuggestions && (
                <div className="command-suggestions">
                    {filteredCommands.map((cmd, index) => (
                        <div
                            key={cmd.command}
                            className={`command-suggestion ${
                                index === selectedSuggestion ? 'command-suggestion--active' : ''
                            }`}
                            onClick={() => handleSuggestionClick(cmd.command)}
                        >
                            <span className="command-suggestion__cmd">{cmd.command}</span>
                            <span className="command-suggestion__desc">{cmd.description}</span>
                        </div>
                    ))}
                </div>
            )}

            {/* Hidden file input for uploads */}
            <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileSelect}
                style={{ display: 'none' }}
                accept={ACCEPT_STRING}
            />

                {/* Upload button */}
                <button
                    className="btn btn-icon"
                    onClick={handleUploadClick}
                    disabled={uploading}
                    title="Upload file"
                >
                    {uploading ? '◌' : '⬆'}
                </button>
                
                <button
                    className="input-bar__send send-button"
                    onClick={handleSubmit}
                    disabled={!input.trim()}
                    title="Send message"
                >
                    ➤
                </button>
            </div>
        </div>
    );
}

export default InputBar;