/**
 * TITANU AI — TitanU OS (Commander Edition)
 * File Pane Component
 * File explorer for TitanU storage with directory navigation
 * Commander Edition Design System
 */
import React, { useState, useEffect, useCallback } from 'react';
import { listFilesByPath, readFileByPath } from '../utils/ipc';

// File icon helper
function getFileIcon(extension, isDir) {
    if (isDir) return '📁';
    
    const icons = {
        '.js': '📜', '.jsx': '⚛️', '.ts': '📘', '.tsx': '⚛️',
        '.py': '🐍', '.json': '📋', '.md': '📝', '.txt': '📄',
        '.css': '🎨', '.scss': '🎨', '.html': '🌐', '.xml': '📰',
        '.png': '🖼️', '.jpg': '🖼️', '.jpeg': '🖼️', '.gif': '🖼️', '.svg': '🖼️',
        '.pdf': '📕', '.doc': '📘', '.docx': '📘',
        '.zip': '📦', '.tar': '📦', '.gz': '📦', '.rar': '📦',
        '.csv': '📊', '.xlsx': '📊', '.xls': '📊',
        '.mp3': '🎵', '.wav': '🎵', '.mp4': '🎬', '.mov': '🎬',
        '.sh': '⚙️', '.bat': '⚙️', '.exe': '⚙️',
        '.env': '🔐', '.gitignore': '📋', '.log': '📋'
    };
    return icons[extension] || '📄';
}

// Format file size
function formatSize(bytes) {
    if (bytes === 0) return '—';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function FilePane() {
    const [files, setFiles] = useState([]);
    const [currentPath, setCurrentPath] = useState(null);
    const [parentPath, setParentPath] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [selectedFile, setSelectedFile] = useState(null);
    const [fileContent, setFileContent] = useState(null);
    const [loadingContent, setLoadingContent] = useState(false);

    const loadFiles = useCallback(async (path = null) => {
        setLoading(true);
        setError(null);
        setSelectedFile(null);
        setFileContent(null);
        
        try {
            const response = await listFilesByPath(path);
            console.log('[FilePane] Response:', response);
            
            if (response?.status === 'success' && response?.data) {
                setFiles(response.data.files || []);
                setCurrentPath(response.data.path || response.data.base_path || null);
                setParentPath(response.data.parent || null);
            } else if (response?.status === 'error') {
                setError(response.error || response.message || 'Failed to load files');
                setFiles([]);
            } else {
                // Handle unexpected response format
                setError('Unexpected response format');
                setFiles([]);
            }
        } catch (e) {
            console.error('[FilePane] Error loading files:', e);
            setError('Failed to load files: ' + (e.message || 'Unknown error'));
            setFiles([]);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        loadFiles();
    }, [loadFiles]);

    const handleItemClick = async (item) => {
        if (item.is_dir) {
            // Navigate into directory
            loadFiles(item.path);
        } else {
            // Read file content
            setSelectedFile(item);
            setLoadingContent(true);
            setFileContent(null);
            
            try {
                const response = await readFileByPath(item.path);
                if (response?.status === 'success' && response?.data) {
                    setFileContent(response.data.content || '');
                } else {
                    setFileContent(`Error: ${response?.error || 'Could not read file'}`);
                }
            } catch (e) {
                setFileContent(`Error reading file: ${e.message}`);
            } finally {
                setLoadingContent(false);
            }
        }
    };

    const goUp = () => {
        if (parentPath) {
            loadFiles(parentPath);
        }
    };

    const goHome = () => {
        loadFiles(null);
    };

    const closePreview = () => {
        setSelectedFile(null);
        setFileContent(null);
    };

    // Get current folder name for display
    const getCurrentFolderName = () => {
        if (!currentPath) return 'Files';
        const parts = currentPath.replace(/\\/g, '/').split('/');
        return parts[parts.length - 1] || 'Files';
    };

    return (
        <div className="file-pane">
            <div className="panel-header">
                <span className="panel-title">📁 FILES</span>
                <div className="panel-actions">
                    <button 
                        className="btn btn-icon" 
                        onClick={goHome} 
                        title="Home"
                        disabled={loading}
                    >
                        🏠
                    </button>
                    <button 
                        className="btn btn-icon" 
                        onClick={goUp} 
                        title="Go up"
                        disabled={loading || !parentPath}
                    >
                        ⬆️
                    </button>
                    <button 
                        className="btn btn-icon" 
                        onClick={() => loadFiles(currentPath)} 
                        title="Refresh"
                        disabled={loading}
                    >
                        🔄
                    </button>
                </div>
            </div>

            {/* Breadcrumb / current path */}
            <div className="file-breadcrumb">
                <span className="breadcrumb-icon">📂</span>
                <span className="breadcrumb-path" title={currentPath}>
                    {getCurrentFolderName()}
                </span>
                <span className="breadcrumb-count">
                    {files.length} items
                </span>
            </div>

            <div className="panel-content">
                {loading && (
                    <div className="loading-state">
                        <div className="loading-spinner"></div>
                        <span>Loading files...</span>
                    </div>
                )}

                {!loading && error && (
                    <div className="error-state">
                        <div className="error-icon">⚠️</div>
                        <p>{error}</p>
                        <button className="btn btn-sm" onClick={() => loadFiles()}>
                            Retry
                        </button>
                    </div>
                )}

                {!loading && !error && files.length === 0 && (
                    <div className="empty-state">
                        <div className="empty-icon">📂</div>
                        <p>Empty folder</p>
                        <p className="text-muted">No files or folders here.</p>
                    </div>
                )}

                {!loading && !error && files.length > 0 && (
                    <div className="file-list">
                        {files.map((item, index) => (
                            <div 
                                key={`${item.path}-${index}`}
                                className={`file-item ${item.is_dir ? 'folder' : 'file'} ${selectedFile?.path === item.path ? 'selected' : ''}`}
                                onClick={() => handleItemClick(item)}
                            >
                                <span className="file-icon">
                                    {getFileIcon(item.extension, item.is_dir)}
                                </span>
                                <div className="file-info">
                                    <div className="file-name">{item.name}</div>
                                    <div className="file-meta">
                                        {item.is_dir ? 'Folder' : formatSize(item.size)}
                                        {item.modified && (
                                            <span> • {new Date(item.modified).toLocaleDateString()}</span>
                                        )}
                                    </div>
                                </div>
                                {item.is_dir && (
                                    <span className="file-arrow">→</span>
                                )}
                            </div>
                        ))}
                    </div>
                )}

                {selectedFile && (
                    <div className="file-preview">
                        <div className="preview-header">
                            <span className="preview-filename">
                                {getFileIcon(selectedFile.extension, false)} {selectedFile.name}
                            </span>
                            <button 
                                className="btn btn-icon btn-close"
                                onClick={closePreview}
                            >
                                ✕
                            </button>
                        </div>
                        <div className="preview-body">
                            {loadingContent ? (
                                <div className="preview-loading">
                                    <div className="loading-spinner small"></div>
                                    <span>Loading content...</span>
                                </div>
                            ) : (
                                <pre className="preview-content">{fileContent}</pre>
                            )}
                        </div>
                    </div>
                )}
            </div>

            <style jsx>{`
                .file-pane {
                    display: flex;
                    flex-direction: column;
                    height: 100%;
                    position: relative;
                }

                .panel-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: var(--spacing-sm) var(--spacing-md);
                    background: rgba(26, 31, 36, 0.9);
                    border-bottom: 1px solid var(--border-color);
                }

                .panel-title {
                    font-family: var(--font-mono);
                    font-size: 12px;
                    font-weight: 600;
                    letter-spacing: 0.08em;
                    color: var(--neon-mint);
                }

                .panel-actions {
                    display: flex;
                    gap: var(--spacing-xs);
                }

                .panel-actions .btn {
                    padding: 4px 8px;
                    font-size: 14px;
                    background: transparent;
                    border: 1px solid transparent;
                    border-radius: 4px;
                    cursor: pointer;
                    transition: all 0.2s ease;
                }

                .panel-actions .btn:hover:not(:disabled) {
                    background: rgba(0, 255, 200, 0.1);
                    border-color: rgba(0, 255, 200, 0.3);
                }

                .panel-actions .btn:disabled {
                    opacity: 0.4;
                    cursor: not-allowed;
                }

                .file-breadcrumb {
                    display: flex;
                    align-items: center;
                    gap: var(--spacing-sm);
                    padding: var(--spacing-xs) var(--spacing-md);
                    background: rgba(15, 20, 25, 0.6);
                    border-bottom: 1px solid var(--border-color);
                    font-family: var(--font-mono);
                    font-size: 11px;
                }

                .breadcrumb-icon {
                    font-size: 14px;
                }

                .breadcrumb-path {
                    color: var(--text-primary);
                    font-weight: 500;
                    flex: 1;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }

                .breadcrumb-count {
                    color: var(--text-muted);
                    font-size: 10px;
                }

                .panel-content {
                    flex: 1;
                    overflow-y: auto;
                    padding: var(--spacing-sm);
                }

                .loading-state {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    padding: var(--spacing-xl);
                    color: var(--text-secondary);
                    gap: var(--spacing-md);
                }

                .loading-spinner {
                    width: 24px;
                    height: 24px;
                    border: 2px solid var(--border-color);
                    border-top-color: var(--neon-mint);
                    border-radius: 50%;
                    animation: spin 1s linear infinite;
                }

                .loading-spinner.small {
                    width: 16px;
                    height: 16px;
                }

                @keyframes spin {
                    to { transform: rotate(360deg); }
                }

                .error-state {
                    text-align: center;
                    padding: var(--spacing-xl);
                    color: var(--error-color, #ff6b6b);
                }

                .error-icon {
                    font-size: 36px;
                    margin-bottom: var(--spacing-md);
                }

                .error-state .btn {
                    margin-top: var(--spacing-md);
                    padding: var(--spacing-xs) var(--spacing-md);
                    background: rgba(255, 107, 107, 0.2);
                    border: 1px solid rgba(255, 107, 107, 0.5);
                    border-radius: var(--radius-sm);
                    color: var(--text-primary);
                    cursor: pointer;
                }

                .error-state .btn:hover {
                    background: rgba(255, 107, 107, 0.3);
                }

                .empty-state {
                    text-align: center;
                    padding: var(--spacing-xl);
                    color: var(--text-secondary);
                }

                .empty-icon {
                    font-size: 48px;
                    margin-bottom: var(--spacing-md);
                    opacity: 0.5;
                }

                .file-list {
                    display: flex;
                    flex-direction: column;
                    gap: 2px;
                }

                .file-item {
                    display: flex;
                    align-items: center;
                    gap: var(--spacing-sm);
                    padding: var(--spacing-sm) var(--spacing-md);
                    background: rgba(15, 20, 25, 0.6);
                    border: 1px solid transparent;
                    border-radius: var(--radius-sm);
                    cursor: pointer;
                    transition: all var(--transition-fast);
                }

                .file-item:hover {
                    background: rgba(0, 255, 200, 0.08);
                    border-color: rgba(0, 255, 200, 0.2);
                }

                .file-item.selected {
                    background: rgba(0, 255, 200, 0.12);
                    border-color: var(--neon-mint);
                }

                .file-item.folder:hover {
                    background: rgba(255, 200, 100, 0.08);
                    border-color: rgba(255, 200, 100, 0.3);
                }

                .file-icon {
                    font-size: 18px;
                    flex-shrink: 0;
                }

                .file-info {
                    flex: 1;
                    min-width: 0;
                }

                .file-name {
                    font-family: var(--font-mono);
                    font-size: 12px;
                    font-weight: 500;
                    color: var(--text-primary);
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                }

                .file-meta {
                    font-family: var(--font-mono);
                    font-size: 10px;
                    color: var(--text-muted);
                    margin-top: 1px;
                }

                .file-arrow {
                    color: var(--text-muted);
                    font-size: 12px;
                }

                .file-preview {
                    position: absolute;
                    bottom: 0;
                    left: 0;
                    right: 0;
                    max-height: 50%;
                    background: rgba(15, 20, 25, 0.98);
                    border-top: 1px solid var(--neon-mint);
                    display: flex;
                    flex-direction: column;
                    animation: slideUp 0.2s ease-out;
                }

                @keyframes slideUp {
                    from {
                        transform: translateY(100%);
                        opacity: 0;
                    }
                    to {
                        transform: translateY(0);
                        opacity: 1;
                    }
                }

                .preview-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: var(--spacing-sm) var(--spacing-md);
                    background: rgba(26, 31, 36, 0.9);
                    border-bottom: 1px solid var(--border-color);
                }

                .preview-filename {
                    font-family: var(--font-mono);
                    font-size: 11px;
                    font-weight: 600;
                    color: var(--neon-mint);
                }

                .btn-close {
                    padding: 2px 6px;
                    font-size: 12px;
                    background: transparent;
                    border: none;
                    color: var(--text-muted);
                    cursor: pointer;
                }

                .btn-close:hover {
                    color: var(--text-primary);
                    background: rgba(255, 255, 255, 0.1);
                    border-radius: 4px;
                }

                .preview-body {
                    flex: 1;
                    overflow: auto;
                }

                .preview-loading {
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    gap: var(--spacing-sm);
                    padding: var(--spacing-lg);
                    color: var(--text-muted);
                    font-size: 12px;
                }

                .preview-content {
                    padding: var(--spacing-md);
                    margin: 0;
                    font-size: 11px;
                    font-family: var(--font-mono);
                    line-height: 1.5;
                    background: rgba(10, 10, 10, 0.5);
                    color: var(--text-primary);
                    white-space: pre-wrap;
                    word-break: break-word;
                }
            `}</style>
        </div>
    );
}

export default FilePane;