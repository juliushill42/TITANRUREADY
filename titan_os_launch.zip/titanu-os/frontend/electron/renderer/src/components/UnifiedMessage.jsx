/**
 * TITANU AI — TitanU OS (Standard Mode)
 * Unified Message Component
 * Handles all message types with consistent styling
 * Preserves neon-mint cyber aesthetic
 */
import React from 'react';

/**
 * UnifiedMessage - A unified message display component
 * @param {Object} props
 * @param {'user-command'|'system-response'|'llm-response'|'error'|'info'|'processing'} props.type - Message type
 * @param {string} props.content - Message content
 * @param {Date} props.timestamp - When the message was created
 * @param {'success'|'error'|'loading'} [props.status] - Optional status for system messages
 * @param {boolean} [props.isProcessing] - Shows processing indicator
 */
function UnifiedMessage({ type, content, timestamp, status, isProcessing }) {
    // Helper function to parse and format message content
    const formatMessage = (msg) => {
        if (typeof msg !== 'string') return msg;
        
        // Try to parse JSON and extract response field
        try {
            const parsed = JSON.parse(msg);
            if (parsed.response) {
                return parsed.response;
            }
            // If it's JSON but doesn't have a response field, stringify nicely
            if (typeof parsed === 'object') {
                return JSON.stringify(parsed, null, 2);
            }
        } catch {
            // Not JSON, use as-is
        }
        return msg;
    };

    const formatTimestamp = (date) => {
        if (!date) return '';
        const d = new Date(date);
        return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    };

    const getStatusBadge = () => {
        if (!status) return null;
        
        const statusClasses = {
            success: 'status-badge--success',
            error: 'status-badge--error',
            loading: 'status-badge--loading'
        };

        const statusLabels = {
            success: 'SUCCESS',
            error: 'ERROR',
            loading: 'LOADING...'
        };

        return (
            <span className={`status-badge ${statusClasses[status] || ''}`}>
                {statusLabels[status] || status.toUpperCase()}
            </span>
        );
    };

    const getMessageClass = () => {
        const baseClass = 'unified-message';
        const typeClasses = {
            'user-command': 'unified-message--user',
            'system-response': 'unified-message--system',
            'llm-response': 'unified-message--assistant',
            'error': 'unified-message--error',
            'info': 'unified-message--info'
        };
        return `${baseClass} ${typeClasses[type] || ''}`;
    };

    // Format the content
    const formattedContent = formatMessage(content);

    // Render user command - Premium gold bubble
    if (type === 'user-command') {
        return (
            <div className="unified-message unified-message--user bubble-user">
                <span className="content">{formattedContent}</span>
                {timestamp && (
                    <span className="timestamp">{formatTimestamp(timestamp)}</span>
                )}
            </div>
        );
    }

    // Render LLM/AI response - Premium TITAN bubble
    if (type === 'llm-response') {
        return (
            <div className="unified-message unified-message--assistant bubble-titan">
                <div className="message-header">
                    <span className="message-sender source-label">TITAN AI</span>
                    {timestamp && (
                        <span className="timestamp">{formatTimestamp(timestamp)}</span>
                    )}
                </div>
                <div className="content">{formattedContent}</div>
            </div>
        );
    }

    // Render system response with status badge
    if (type === 'system-response') {
        return (
            <div className={getMessageClass()}>
                <div className="message-header">
                    {getStatusBadge()}
                    {timestamp && (
                        <span className="timestamp">{formatTimestamp(timestamp)}</span>
                    )}
                </div>
                <div className="content">{formattedContent}</div>
            </div>
        );
    }

    // Render error message
    if (type === 'error') {
        return (
            <div className={getMessageClass()}>
                <div className="message-header">
                    <span className="status-badge status-badge--error">ERROR</span>
                    {timestamp && (
                        <span className="timestamp">{formatTimestamp(timestamp)}</span>
                    )}
                </div>
                <div className="content">{formattedContent}</div>
            </div>
        );
    }

    // Render info message
    if (type === 'info') {
        return (
            <div className={getMessageClass()}>
                <span className="info-icon">ℹ</span>
                <span className="content">{formattedContent}</span>
                {timestamp && (
                    <span className="timestamp">{formatTimestamp(timestamp)}</span>
                )}
            </div>
        );
    }

    // Render processing indicator
    if (type === 'processing' || isProcessing) {
        return (
            <div className="processing-indicator">
                <div className="processing-spinner"></div>
                <span className="processing-text">TITAN is thinking...</span>
            </div>
        );
    }

    // Default fallback
    return (
        <div className={getMessageClass()}>
            <div className="content">{formattedContent}</div>
        </div>
    );
}

export default UnifiedMessage;