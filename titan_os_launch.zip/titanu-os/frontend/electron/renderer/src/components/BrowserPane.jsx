/**
 * TITANU AI — TitanU OS v3.0 Genesis
 * Browser Pane Component - DISABLED
 * Temporarily offline for security hardening
 * Coming in v3.1 with proper sandboxing
 */
import React from 'react';

function BrowserPane() {
    return (
        <div className="browser-pane">
            <div className="panel-header">
                <span className="panel-title">🌐 SECURE BROWSER</span>
                <span className="status-badge offline">🔒 OFFLINE</span>
            </div>

            <div className="browser-disabled">
                <div className="browser-disabled-overlay">
                    <div className="lock-icon">🔒</div>
                    <h3>BROWSER OFFLINE</h3>
                    <p className="disabled-reason">Disabled in v3.0 Genesis for security hardening.</p>
                    
                    <div className="coming-soon-features">
                        <div className="feature">
                            <span className="icon">⚡</span>
                            <span>Coming in v3.1 with proper sandboxing</span>
                        </div>
                        <div className="feature">
                            <span className="icon">🛡️</span>
                            <span>Enhanced isolation</span>
                        </div>
                        <div className="feature">
                            <span className="icon">🔐</span>
                            <span>Secure contexts</span>
                        </div>
                    </div>
                    
                    <div className="version-badge">v3.1 ETA: December 2025</div>
                </div>
            </div>

            <style jsx>{`
                .browser-pane {
                    display: flex;
                    flex-direction: column;
                    height: 100%;
                    background: linear-gradient(135deg, rgba(10, 15, 20, 0.95) 0%, rgba(15, 20, 25, 0.95) 100%);
                }

                .panel-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: var(--spacing-sm) var(--spacing-md);
                    background: rgba(26, 31, 36, 0.9);
                    border-bottom: 1px solid var(--border-color);
                }

                .panel-title {
                    font-family: var(--font-mono);
                    font-size: 12px;
                    font-weight: 600;
                    letter-spacing: 0.08em;
                    color: var(--text-secondary);
                    opacity: 0.6;
                }

                .status-badge {
                    font-family: var(--font-mono);
                    font-size: 10px;
                    font-weight: 600;
                    letter-spacing: 0.05em;
                    padding: 4px 10px;
                    border-radius: var(--radius-pill);
                    border: 1px solid rgba(255, 255, 255, 0.1);
                }

                .status-badge.offline {
                    color: var(--text-muted);
                    background: rgba(100, 100, 100, 0.15);
                    border: 1px solid rgba(100, 100, 100, 0.3);
                }

                .browser-disabled {
                    flex: 1;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }

                .browser-disabled-overlay {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    padding: 40px;
                    text-align: center;
                    max-width: 500px;
                }

                .lock-icon {
                    font-size: 48px;
                    margin-bottom: 20px;
                    opacity: 0.5;
                }

                .browser-disabled-overlay h3 {
                    color: var(--text-secondary-soft);
                    font-size: 18px;
                    margin-bottom: 8px;
                    font-family: var(--font-headers);
                    text-transform: uppercase;
                    letter-spacing: 0.1em;
                }

                .disabled-reason {
                    color: var(--text-dim-subtle);
                    font-size: 13px;
                    margin-bottom: 24px;
                }

                .coming-soon-features {
                    display: flex;
                    flex-direction: column;
                    gap: 12px;
                    margin-bottom: 24px;
                }

                .feature {
                    display: flex;
                    align-items: center;
                    gap: 10px;
                    color: var(--text-secondary-soft);
                    font-size: 13px;
                }

                .feature .icon {
                    font-size: 16px;
                }

                .version-badge {
                    padding: 6px 16px;
                    background: rgba(255, 215, 0, 0.1);
                    border: 1px solid var(--titan-gold-dim);
                    border-radius: 20px;
                    color: var(--titan-gold);
                    font-size: 11px;
                    letter-spacing: 0.1em;
                    font-family: var(--font-mono);
                }
            `}</style>
        </div>
    );
}

export default BrowserPane;