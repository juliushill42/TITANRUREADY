import React, { useState, useEffect } from 'react';
import { validateGenesisKey, saveGenesisKey } from '../utils/genesisKey';
import '../styles/genesisKey.css';

function GenesisKeyModal({ onValidKey }) {
  const [keyInput, setKeyInput] = useState('');
  const [error, setError] = useState('');
  const [isValidating, setIsValidating] = useState(false);

  // Auto-uppercase and format the input
  const handleKeyChange = (e) => {
    const value = e.target.value.toUpperCase();
    // Limit to 25 characters (TITANU-GENESIS-XXX-XXXXXX = 25 chars)
    if (value.length <= 25) {
      setKeyInput(value);
      setError(''); // Clear error on input change
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!keyInput.trim()) {
      setError('Please enter a Genesis Key');
      return;
    }

    setIsValidating(true);
    
    // Small delay for better UX (shows the validation is happening)
    setTimeout(() => {
      const result = saveGenesisKey(keyInput);
      
      if (result.valid) {
        // Success! Notify parent component
        onValidKey(result);
      } else {
        setError(result.error || 'Invalid Genesis Key format. Please check and try again.');
        setIsValidating(false);
      }
    }, 300);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && keyInput.length >= 20) {
      handleSubmit(e);
    }
  };

  // Check if the input length is sufficient to enable the button
  const isButtonEnabled = keyInput.length >= 20 && !isValidating;

  return (
    <div className="genesis-key-overlay">
      <div className="genesis-key-modal">
        <div className="genesis-logo">⚡</div>
        
        <h1 className="genesis-title">TITANU OS</h1>
        <p className="genesis-subtitle">Enter your Genesis Operator Key</p>
        
        <form onSubmit={handleSubmit}>
          <div className="genesis-input-container">
            <input
              type="text"
              className="genesis-input"
              value={keyInput}
              onChange={handleKeyChange}
              onKeyPress={handleKeyPress}
              placeholder="TITANU-GENESIS-XXX-XXXXXX"
              autoFocus
              disabled={isValidating}
            />
            <div className="genesis-format-hint">
              Format: TITANU-GENESIS-XXX-XXXXXX
            </div>
            {error && <div className="genesis-error">{error}</div>}
          </div>
          
          <button
            type="submit"
            className="genesis-button"
            disabled={!isButtonEnabled}
          >
            {isValidating ? 'VALIDATING...' : 'ACTIVATE GENESIS'}
          </button>
        </form>
        
        <div className="genesis-divider"></div>
        
        <div className="genesis-help-text">
          <strong>Genesis Keys</strong> are exclusive to the 100 founding operators.<br />
          This key grants permanent access to TITANU OS Genesis Edition.
        </div>
      </div>
    </div>
  );
}

export default GenesisKeyModal;