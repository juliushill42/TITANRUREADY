/**
 * TITANU AI — TitanU OS (Commander Edition)
 * Memory Pane Component v2.5
 * Shows memory entries with tags, add/delete functionality
 * Commander Edition Design System
 */
import React, { useState, useEffect, useCallback } from 'react';
import { getMemory, clearMemory, deleteMemory, logMemory } from '../utils/ipc';

function MemoryPane() {
    const [entries, setEntries] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [total, setTotal] = useState(0);
    const [showAddForm, setShowAddForm] = useState(false);
    const [newContent, setNewContent] = useState('');
    const [newTags, setNewTags] = useState('');

    const loadMemory = useCallback(async () => {
        setLoading(true);
        setError(null);
        try {
            const response = await getMemory(null, 50);
            if (response?.status === 'success' && response?.data) {
                setEntries(response.data.entries || []);
                setTotal(response.data.total || response.data.entries?.length || 0);
            } else if (response?.data?.entries) {
                setEntries(response.data.entries);
                setTotal(response.data.total || response.data.entries.length);
            } else {
                setEntries([]);
                setTotal(0);
            }
        } catch (e) {
            setError('Failed to load memories');
            console.error('Memory load error:', e);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        loadMemory();
    }, [loadMemory]);

    const handleAddMemory = async () => {
        if (!newContent.trim()) return;
        
        const tags = newTags.split(',').map(t => t.trim()).filter(t => t);
        
        try {
            const response = await logMemory(newContent, tags);
            
            if (response?.status === 'success') {
                setNewContent('');
                setNewTags('');
                setShowAddForm(false);
                loadMemory();
            } else {
                alert('Failed to save memory: ' + (response?.error || response?.message || 'Unknown error'));
            }
        } catch (e) {
            alert('Failed to save memory');
            console.error('Save memory error:', e);
        }
    };

    const handleDeleteMemory = async (id) => {
        if (!window.confirm('Delete this memory?')) return;
        
        try {
            await deleteMemory(id);
            loadMemory();
        } catch (e) {
            console.error('Delete error:', e);
        }
    };

    const handleClearAll = async () => {
        if (!window.confirm('Clear ALL memories? This cannot be undone!')) return;
        
        try {
            await clearMemory();
            loadMemory();
        } catch (e) {
            alert('Failed to clear memories');
            console.error('Clear memory error:', e);
        }
    };

    const formatTime = (timestamp) => {
        if (!timestamp) return '';
        try {
            const date = new Date(timestamp);
            return date.toLocaleString();
        } catch {
            return timestamp;
        }
    };

    const getEntryIcon = (entry) => {
        if (entry.role === 'user') return '👤';
        if (entry.role === 'assistant') return '🤖';
        if (entry.type === 'system') return '⚙️';
        return '📝';
    };

    const getEntryLabel = (entry) => {
        if (entry.role) return entry.role;
        return entry.type || 'note';
    };

    return (
        <div className="memory-pane">
            <div className="panel-header">
                <span className="panel-title">
                    🧠 MEMORY
                    {total > 0 && <span className="count-badge">{total}</span>}
                </span>
                <div className="panel-actions">
                    <button
                        className="btn btn-icon"
                        onClick={() => setShowAddForm(!showAddForm)}
                        title="Add memory"
                    >
                        +
                    </button>
                    <button className="btn btn-icon" onClick={loadMemory} title="Refresh">
                        🔄
                    </button>
                    {entries.length > 0 && (
                        <button
                            className="btn btn-icon btn-danger"
                            onClick={handleClearAll}
                            title="Clear all"
                        >
                            🗑️
                        </button>
                    )}
                </div>
            </div>

            {showAddForm && (
                <div className="add-form">
                    <textarea
                        className="add-textarea"
                        value={newContent}
                        onChange={(e) => setNewContent(e.target.value)}
                        placeholder="Enter memory content..."
                        rows={3}
                    />
                    <input
                        className="add-tags-input"
                        value={newTags}
                        onChange={(e) => setNewTags(e.target.value)}
                        placeholder="Tags (comma-separated)"
                    />
                    <button
                        className="add-button"
                        onClick={handleAddMemory}
                        disabled={!newContent.trim()}
                    >
                        💾 Save Memory
                    </button>
                </div>
            )}

            <div className="panel-content">
                {loading && (
                    <div className="loading-state">
                        <div className="loading-spinner"></div>
                        <span>Loading memories...</span>
                    </div>
                )}

                {error && !loading && (
                    <div className="error-state">
                        <p>{error}</p>
                        <button className="btn" onClick={loadMemory}>Retry</button>
                    </div>
                )}

                {!loading && !error && entries.length === 0 && (
                    <div className="empty-state">
                        <div className="empty-icon">🧠</div>
                        <p>No memories stored</p>
                        <p className="text-muted">Save important information and notes here.</p>
                        <button
                            className="btn btn-primary"
                            onClick={() => setShowAddForm(true)}
                        >
                            Add First Memory
                        </button>
                    </div>
                )}

                {!loading && !error && entries.length > 0 && (
                    <>
                        <div className="memory-stats">
                            <span className="stats-badge">
                                {entries.length} / {total}
                            </span>
                            <span className="stats-text">entries</span>
                        </div>
                        <div className="memory-list">
                            {entries.map((entry, index) => (
                                <div key={entry.id || index} className={`memory-entry ${entry.role || entry.type || ''}`}>
                                    <div className="entry-content">
                                        {entry.content}
                                    </div>
                                    <div className="entry-footer">
                                        <div className="entry-meta">
                                            {entry.tags && entry.tags.length > 0 && (
                                                <div className="entry-tags">
                                                    {entry.tags.map((tag, i) => (
                                                        <span key={i} className="tag">{tag}</span>
                                                    ))}
                                                </div>
                                            )}
                                            <span className="entry-info">
                                                <span className={`entry-role ${entry.role || entry.type || ''}`}>
                                                    {getEntryIcon(entry)} {getEntryLabel(entry)}
                                                </span>
                                                <span className="entry-time">{formatTime(entry.timestamp)}</span>
                                            </span>
                                        </div>
                                        <button
                                            className="delete-btn"
                                            onClick={() => handleDeleteMemory(entry.id)}
                                            title="Delete"
                                        >
                                            ×
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </>
                )}
            </div>

            <style jsx>{`
                .memory-pane {
                    display: flex;
                    flex-direction: column;
                    height: 100%;
                    position: relative;
                    background: var(--bg-primary);
                }

                .panel-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: var(--spacing-sm) var(--spacing-md);
                    background: rgba(26, 31, 36, 0.9);
                    border-bottom: 1px solid var(--border-color);
                }

                .panel-title {
                    font-family: var(--font-mono);
                    font-size: 12px;
                    font-weight: 600;
                    letter-spacing: 0.08em;
                    color: var(--neon-mint);
                    display: flex;
                    align-items: center;
                    gap: 8px;
                }

                .count-badge {
                    font-size: 10px;
                    font-weight: 500;
                    padding: 2px 6px;
                    background: rgba(0, 255, 200, 0.15);
                    border-radius: 10px;
                    opacity: 0.8;
                }

                .panel-actions {
                    display: flex;
                    gap: var(--spacing-xs);
                }

                .btn {
                    background: transparent;
                    border: 1px solid rgba(0, 255, 200, 0.3);
                    color: var(--neon-mint);
                    padding: 4px 8px;
                    font-size: 12px;
                    cursor: pointer;
                    border-radius: 4px;
                    transition: all 0.2s;
                }

                .btn:hover {
                    background: rgba(0, 255, 200, 0.1);
                    border-color: var(--neon-mint);
                }

                .btn-icon {
                    padding: 4px 8px;
                    min-width: 28px;
                }

                .btn-danger {
                    color: #ff4444;
                    border-color: rgba(255, 68, 68, 0.3);
                }

                .btn-danger:hover {
                    background: rgba(255, 68, 68, 0.1);
                    border-color: #ff4444;
                }

                .btn-primary {
                    background: rgba(0, 255, 200, 0.2);
                    border-color: rgba(0, 255, 200, 0.4);
                }

                .add-form {
                    padding: var(--spacing-md);
                    border-bottom: 1px solid var(--border-color);
                    background: rgba(0, 255, 200, 0.03);
                }

                .add-textarea {
                    width: 100%;
                    padding: 8px;
                    background: rgba(0, 0, 0, 0.3);
                    border: 1px solid rgba(0, 255, 200, 0.2);
                    border-radius: 4px;
                    color: var(--text-primary);
                    font-family: var(--font-mono);
                    font-size: 12px;
                    resize: vertical;
                    min-height: 60px;
                }

                .add-textarea:focus {
                    outline: none;
                    border-color: var(--neon-mint);
                }

                .add-tags-input {
                    width: 100%;
                    margin-top: 8px;
                    padding: 6px 8px;
                    background: rgba(0, 0, 0, 0.3);
                    border: 1px solid rgba(0, 255, 200, 0.2);
                    border-radius: 4px;
                    color: var(--text-primary);
                    font-family: var(--font-mono);
                    font-size: 11px;
                }

                .add-tags-input:focus {
                    outline: none;
                    border-color: var(--neon-mint);
                }

                .add-button {
                    margin-top: 8px;
                    width: 100%;
                    padding: 8px;
                    background: rgba(0, 255, 200, 0.2);
                    border: 1px solid rgba(0, 255, 200, 0.4);
                    border-radius: 4px;
                    color: var(--neon-mint);
                    cursor: pointer;
                    font-weight: 500;
                    font-family: var(--font-mono);
                    transition: all 0.2s;
                }

                .add-button:hover:not(:disabled) {
                    background: rgba(0, 255, 200, 0.3);
                }

                .add-button:disabled {
                    opacity: 0.5;
                    cursor: not-allowed;
                }

                .panel-content {
                    flex: 1;
                    overflow-y: auto;
                    padding: var(--spacing-md);
                }

                .loading-state {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    padding: var(--spacing-xl);
                    color: var(--text-secondary);
                    gap: var(--spacing-md);
                }

                .loading-spinner {
                    width: 24px;
                    height: 24px;
                    border: 2px solid var(--border-color);
                    border-top-color: var(--neon-mint);
                    border-radius: 50%;
                    animation: spin 1s linear infinite;
                }

                @keyframes spin {
                    to { transform: rotate(360deg); }
                }

                .error-state {
                    text-align: center;
                    padding: var(--spacing-xl);
                    color: #ff4444;
                }

                .empty-state {
                    text-align: center;
                    padding: var(--spacing-xl);
                    color: var(--text-secondary);
                }

                .empty-icon {
                    font-size: 36px;
                    margin-bottom: var(--spacing-md);
                    opacity: 0.5;
                }

                .memory-stats {
                    display: flex;
                    align-items: center;
                    gap: var(--spacing-xs);
                    margin-bottom: var(--spacing-sm);
                    font-family: var(--font-mono);
                }

                .stats-badge {
                    font-size: 11px;
                    font-weight: 600;
                    color: var(--neon-mint);
                    padding: 2px 8px;
                    background: rgba(0, 255, 200, 0.1);
                    border: 1px solid rgba(0, 255, 200, 0.3);
                    border-radius: var(--radius-pill);
                }

                .stats-text {
                    font-size: 11px;
                    color: var(--text-muted);
                }

                .memory-list {
                    display: flex;
                    flex-direction: column;
                    gap: var(--spacing-sm);
                }

                .memory-entry {
                    padding: 10px 12px;
                    background: rgba(15, 20, 25, 0.85);
                    border-radius: var(--radius-md);
                    border-left: 3px solid var(--border-color);
                    transition: all var(--transition-fast);
                    animation: fadeIn 0.3s ease-out;
                    position: relative;
                }

                @keyframes fadeIn {
                    from {
                        opacity: 0;
                        transform: translateX(-5px);
                    }
                    to {
                        opacity: 1;
                        transform: translateX(0);
                    }
                }

                .memory-entry:hover {
                    background: rgba(15, 20, 25, 0.95);
                    box-shadow: 0 0 10px var(--glow-soft);
                }

                .memory-entry.user {
                    border-left-color: var(--neon-mint);
                }

                .memory-entry.assistant {
                    border-left-color: var(--electric-blue);
                }

                .memory-entry.system {
                    border-left-color: var(--cyber-yellow);
                }

                .entry-content {
                    font-size: 12px;
                    line-height: 1.5;
                    color: var(--text-primary);
                    word-break: break-word;
                    white-space: pre-wrap;
                    margin-bottom: 8px;
                }

                .entry-footer {
                    display: flex;
                    justify-content: space-between;
                    align-items: flex-end;
                }

                .entry-meta {
                    display: flex;
                    flex-direction: column;
                    gap: 4px;
                }

                .entry-tags {
                    display: flex;
                    gap: 4px;
                    flex-wrap: wrap;
                }

                .tag {
                    padding: 2px 6px;
                    background: rgba(0, 255, 200, 0.15);
                    border-radius: 3px;
                    font-size: 10px;
                    font-family: var(--font-mono);
                    color: var(--neon-mint);
                }

                .entry-info {
                    display: flex;
                    align-items: center;
                    gap: 8px;
                    font-size: 10px;
                }

                .entry-role {
                    font-family: var(--font-mono);
                    font-weight: 700;
                    text-transform: uppercase;
                    letter-spacing: 0.08em;
                    color: var(--text-muted);
                }

                .entry-role.user {
                    color: var(--neon-mint);
                }

                .entry-role.assistant {
                    color: var(--electric-blue);
                }

                .entry-time {
                    font-family: var(--font-mono);
                    color: var(--text-muted);
                }

                .delete-btn {
                    background: transparent;
                    border: none;
                    color: #ff4444;
                    cursor: pointer;
                    opacity: 0.4;
                    font-size: 18px;
                    padding: 0 4px;
                    transition: opacity 0.2s;
                }

                .delete-btn:hover {
                    opacity: 1;
                }
            `}</style>
        </div>
    );
}

export default MemoryPane;