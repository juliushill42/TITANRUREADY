/**
 * TITANU AI — TitanU OS (Commander Edition)
 * Terminal View Component
 * Command input, scrollback, bubble-style messages
 * Commander Edition Aesthetic
 */
import React, { useState, useRef, useEffect } from 'react';
import { sendCommand } from '../utils/ipc';

// Message bubble component with Commander Edition styling
function MessageBubble({ message, isUser }) {
    const getStatusColor = (status) => {
        switch (status) {
            case 'success':
            case 'online':
            case 'ready':
                return 'text-success';
            case 'error':
                return 'text-error';
            case 'warning':
                return 'text-warning';
            default:
                return 'text-info';
        }
    };

    if (isUser) {
        return (
            <div className="message-bubble user">
                <div className="message-content">
                    <span className="message-prompt">›</span>
                    <span className="message-text">{message.text}</span>
                </div>
                <div className="message-time">{message.time}</div>
            </div>
        );
    }

    return (
        <div className="message-bubble system">
            <div className="message-header">
                <span className={`message-status ${getStatusColor(message.status)}`}>
                    {message.status?.toUpperCase() || 'RESPONSE'}
                </span>
                <span className="message-time">{message.time}</span>
            </div>
            <div className="message-content">
                {message.message && (
                    <div className="message-text">{message.message}</div>
                )}
                {message.error && (
                    <div className="message-error text-error">{message.error}</div>
                )}
                {message.data && (
                    <pre className="message-data">
                        {JSON.stringify(message.data, null, 2)}
                    </pre>
                )}
            </div>
        </div>
    );
}

function TerminalView({ responses, systemStatus }) {
    const [input, setInput] = useState('');
    const [history, setHistory] = useState([]);
    const [historyIndex, setHistoryIndex] = useState(-1);
    const [messages, setMessages] = useState([]);
    const inputRef = useRef(null);
    const scrollRef = useRef(null);

    // Process responses into messages (skip boot notifications)
    useEffect(() => {
        if (responses.length > 0) {
            const lastResponse = responses[responses.length - 1];
            
            // Skip boot/ready responses to keep welcome screen clean
            if (lastResponse.status === 'online' || lastResponse.status === 'ready') {
                return;
            }
            
            const newMessage = {
                ...lastResponse,
                time: new Date().toLocaleTimeString(),
                isUser: false
            };
            setMessages(prev => [...prev, newMessage]);
        }
    }, [responses]);

    // Auto-scroll to bottom
    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
    }, [messages]);

    // Parse and execute command
    const executeCommand = (commandStr) => {
        const trimmed = commandStr.trim();
        if (!trimmed) return;

        // Add to history
        setHistory(prev => [...prev.filter(h => h !== trimmed), trimmed]);
        setHistoryIndex(-1);

        // Add user message
        const userMessage = {
            text: trimmed,
            time: new Date().toLocaleTimeString(),
            isUser: true
        };
        setMessages(prev => [...prev, userMessage]);

        // Parse command
        const parts = trimmed.split(/\s+/);
        const command = parts[0].toLowerCase();
        
        // Handle special local commands
        if (command === 'clear') {
            setMessages([]);
            setInput('');
            return;
        }
        
        if (command === 'help') {
            const helpMessage = {
                status: 'info',
                message: 'Available commands:',
                data: {
                    boot: 'Initialize TitanU Core',
                    shutdown: 'Shutdown TitanU Core',
                    save: 'save <filename> <content>',
                    read: 'read <filename>',
                    files: 'List files',
                    memory: 'Show memory entries',
                    scrape: 'scrape <url>',
                    summarize: 'summarize <text>',
                    clear: 'Clear terminal',
                    help: 'Show this help'
                },
                time: new Date().toLocaleTimeString(),
                isUser: false
            };
            setMessages(prev => [...prev, helpMessage]);
            setInput('');
            return;
        }

        // Build params based on command
        let params = {};
        
        switch (command) {
            case 'save':
                params = { filename: parts[1], content: parts.slice(2).join(' ') };
                sendCommand('save_file', params);
                break;
            case 'read':
                params = { filename: parts[1] };
                sendCommand('read_file', params);
                break;
            case 'files':
            case 'list':
                sendCommand('list_files', { recursive: parts.includes('-r') });
                break;
            case 'memory':
                sendCommand('get_memory', { limit: parseInt(parts[1]) || 20 });
                break;
            case 'scrape':
                sendCommand('scrape_url', { url: parts[1] });
                break;
            case 'summarize':
                sendCommand('summarize', { text: parts.slice(1).join(' ') });
                break;
            case 'boot':
                sendCommand('boot', {});
                break;
            case 'shutdown':
                sendCommand('shutdown', {});
                break;
            default:
                // Try sending as raw command
                sendCommand(command, {});
        }

        setInput('');
    };

    // Handle key events
    const handleKeyDown = (e) => {
        if (e.key === 'Enter') {
            executeCommand(input);
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            if (history.length > 0) {
                const newIndex = historyIndex < history.length - 1 ? historyIndex + 1 : historyIndex;
                setHistoryIndex(newIndex);
                setInput(history[history.length - 1 - newIndex] || '');
            }
        } else if (e.key === 'ArrowDown') {
            e.preventDefault();
            if (historyIndex > 0) {
                const newIndex = historyIndex - 1;
                setHistoryIndex(newIndex);
                setInput(history[history.length - 1 - newIndex] || '');
            } else {
                setHistoryIndex(-1);
                setInput('');
            }
        }
    };

    return (
        <div className="terminal-view">
            {/* Terminal Header */}
            <div className="terminal-header">
                <div className="terminal-header-left">
                    <span className="terminal-dot red"></span>
                    <span className="terminal-dot yellow"></span>
                    <span className="terminal-dot green"></span>
                </div>
                <span className="terminal-title">TITANU TERMINAL</span>
                <span className="terminal-status">
                    {systemStatus.online ? '● CONNECTED' : '○ DISCONNECTED'}
                </span>
            </div>

            {/* Terminal Output */}
            <div className="terminal-output" ref={scrollRef}>
                {/* Welcome Banner */}
                {messages.length === 0 && (
                    <div className="terminal-welcome">
                        <pre className="welcome-ascii">
{`
  ████████╗██╗████████╗ █████╗ ███╗   ██╗██╗   ██╗
  ╚══██╔══╝██║╚══██╔══╝██╔══██╗████╗  ██║██║   ██║
     ██║   ██║   ██║   ███████║██╔██╗ ██║██║   ██║
     ██║   ██║   ██║   ██╔══██║██║╚██╗██║██║   ██║
     ██║   ██║   ██║   ██║  ██║██║ ╚████║╚██████╔╝
     ╚═╝   ╚═╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝ 
              TITANU AI • COMMANDER EDITION
`}
                        </pre>
                        <div className="welcome-subtitle">
                            <span className="welcome-bracket">[</span>
                            <span className="welcome-text-inner">TitanU OS</span>
                            <span className="welcome-bracket">]</span>
                        </div>
                        <p className="welcome-text">
                            Welcome to TitanU AI. Type <code>help</code> for available commands.
                        </p>
                        <p className="welcome-secure text-success">
                            🔒 LOCAL • SECURE • PRIVATE
                        </p>
                    </div>
                )}

                {/* Messages */}
                {messages.map((msg, index) => (
                    <MessageBubble 
                        key={index} 
                        message={msg} 
                        isUser={msg.isUser} 
                    />
                ))}
            </div>

            {/* Terminal Input */}
            <div className="terminal-input-container">
                <span className="input-prompt">titanu›</span>
                <input
                    ref={inputRef}
                    type="text"
                    className="terminal-input"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="Enter command..."
                    autoFocus
                />
                <span className="cursor-blink"></span>
            </div>

            <style jsx>{`
                .terminal-view {
                    display: flex;
                    flex-direction: column;
                    height: 100%;
                    background: rgba(10, 10, 10, 0.8);
                    border: 1px solid var(--neon-mint);
                    border-radius: var(--radius-md);
                    box-shadow: var(--terminal-glow);
                    backdrop-filter: blur(3px);
                    position: relative;
                    overflow: hidden;
                }

                /* Glossy reflection overlay */
                .terminal-view::before {
                    content: "";
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: linear-gradient(
                        135deg,
                        rgba(255, 255, 255, 0.03) 0%,
                        rgba(0, 0, 0, 0.05) 40%,
                        rgba(255, 255, 255, 0.02) 100%
                    );
                    pointer-events: none;
                    z-index: 1;
                }

                /* Scanline effect */
                .terminal-view::after {
                    content: "";
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 2px;
                    background: linear-gradient(90deg, transparent, rgba(0, 255, 200, 0.15), transparent);
                    animation: scanline 4s linear infinite;
                    pointer-events: none;
                    opacity: 0.5;
                    z-index: 2;
                }

                @keyframes scanline {
                    0% { transform: translateY(-100%); }
                    100% { transform: translateY(100vh); }
                }

                .terminal-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: var(--spacing-sm) var(--spacing-md);
                    background: rgba(26, 31, 36, 0.95);
                    border-bottom: 1px solid var(--border-color);
                    position: relative;
                    z-index: 3;
                }

                .terminal-header-left {
                    display: flex;
                    gap: 6px;
                }

                .terminal-dot {
                    width: 12px;
                    height: 12px;
                    border-radius: 50%;
                }

                .terminal-dot.red {
                    background: #FF5F56;
                    box-shadow: 0 0 6px rgba(255, 95, 86, 0.5);
                }

                .terminal-dot.yellow {
                    background: #FFBD2E;
                    box-shadow: 0 0 6px rgba(255, 189, 46, 0.5);
                }

                .terminal-dot.green {
                    background: var(--neon-mint);
                    box-shadow: 0 0 6px var(--glow-soft);
                }

                .terminal-title {
                    font-family: var(--font-mono);
                    font-size: 12px;
                    font-weight: 700;
                    letter-spacing: 0.15em;
                    color: var(--neon-mint);
                    text-shadow: 0 0 8px var(--glow-soft);
                }

                .terminal-status {
                    font-family: var(--font-mono);
                    font-size: 11px;
                    font-weight: 600;
                    color: var(--success);
                    letter-spacing: 0.05em;
                }

                .terminal-output {
                    flex: 1;
                    overflow-y: auto;
                    padding: var(--spacing-md);
                    font-family: var(--font-mono);
                    font-size: 13px;
                    color: #C8FFF5;
                    position: relative;
                    z-index: 3;
                }

                .terminal-welcome {
                    text-align: center;
                    padding: var(--spacing-xl);
                    color: var(--text-secondary);
                    animation: fadeIn 0.45s ease-out forwards;
                }

                @keyframes fadeIn {
                    from { 
                        opacity: 0; 
                        transform: translateY(10px);
                    }
                    to { 
                        opacity: 1; 
                        transform: translateY(0);
                    }
                }

                .welcome-ascii {
                    color: var(--neon-mint);
                    font-size: 9px;
                    line-height: 1.15;
                    margin-bottom: var(--spacing-md);
                    text-shadow: 
                        0 0 10px var(--glow-soft),
                        0 0 20px rgba(0, 255, 200, 0.1);
                    letter-spacing: 0.05em;
                }

                .welcome-subtitle {
                    margin-bottom: var(--spacing-lg);
                    font-size: 14px;
                    letter-spacing: 0.3em;
                }

                .welcome-bracket {
                    color: var(--cyber-yellow);
                    font-weight: bold;
                }

                .welcome-text-inner {
                    color: var(--text-primary);
                    margin: 0 8px;
                }

                .welcome-text {
                    margin-bottom: var(--spacing-sm);
                    color: var(--text-secondary);
                }

                .welcome-text code {
                    color: var(--neon-mint);
                    background: rgba(0, 255, 200, 0.1);
                    padding: 2px 8px;
                    border-radius: var(--radius-sm);
                    border: 1px solid rgba(0, 255, 200, 0.2);
                }

                .welcome-secure {
                    font-weight: 600;
                    letter-spacing: 0.1em;
                    text-shadow: 0 0 8px var(--glow-soft);
                }

                .message-bubble {
                    margin-bottom: var(--spacing-md);
                    animation: fadeIn 0.3s ease-out;
                }

                .message-bubble.user {
                    padding-left: var(--spacing-lg);
                }

                .message-bubble.user .message-content {
                    color: var(--neon-mint);
                    font-weight: 500;
                }

                .message-prompt {
                    color: var(--cyber-yellow);
                    margin-right: var(--spacing-sm);
                    font-weight: bold;
                }

                .message-bubble.system {
                    background: rgba(15, 20, 25, 0.85);
                    border: 1px solid var(--border-color);
                    border-radius: var(--radius-md);
                    padding: var(--spacing-sm) var(--spacing-md);
                    position: relative;
                    transition: all var(--transition-fast);
                }

                .message-bubble.system:hover {
                    border-color: var(--neon-mint);
                    box-shadow: 0 0 10px var(--glow-soft);
                }

                .message-bubble.system::before {
                    content: "";
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: linear-gradient(
                        135deg,
                        rgba(255, 255, 255, 0.03) 0%,
                        rgba(0, 0, 0, 0.05) 40%,
                        rgba(255, 255, 255, 0.02) 100%
                    );
                    pointer-events: none;
                    border-radius: var(--radius-md);
                }

                .message-header {
                    display: flex;
                    justify-content: space-between;
                    margin-bottom: var(--spacing-xs);
                }

                .message-status {
                    font-size: 10px;
                    font-weight: 700;
                    letter-spacing: 0.08em;
                    text-transform: uppercase;
                }

                .message-time {
                    font-size: 10px;
                    color: var(--text-muted);
                }

                .message-data {
                    margin-top: var(--spacing-sm);
                    padding: var(--spacing-sm);
                    background: rgba(10, 10, 10, 0.6);
                    border-radius: var(--radius-sm);
                    font-size: 11px;
                    overflow-x: auto;
                    color: var(--text-secondary);
                    border: 1px solid rgba(0, 255, 200, 0.1);
                }

                .terminal-input-container {
                    display: flex;
                    align-items: center;
                    padding: var(--spacing-md);
                    background: rgba(15, 20, 25, 0.95);
                    border-top: 1px solid var(--border-color);
                    position: relative;
                    z-index: 3;
                }

                .input-prompt {
                    color: var(--neon-mint);
                    font-family: var(--font-mono);
                    font-weight: 700;
                    margin-right: var(--spacing-sm);
                    text-shadow: 0 0 8px var(--glow-soft);
                }

                .terminal-input {
                    flex: 1;
                    background: transparent;
                    border: none;
                    outline: none;
                    color: var(--text-primary);
                    font-family: var(--font-mono);
                    font-size: 14px;
                    letter-spacing: 0.02em;
                }

                .terminal-input::placeholder {
                    color: var(--text-muted);
                }

                .cursor-blink {
                    width: 10px;
                    height: 18px;
                    background: var(--neon-mint);
                    margin-left: 2px;
                    animation: cursorPulse 1.4s infinite;
                    box-shadow: 0 0 8px var(--glow-color);
                }

                @keyframes cursorPulse {
                    0% { opacity: 0.5; }
                    50% { opacity: 1; }
                    100% { opacity: 0.5; }
                }
            `}</style>
        </div>
    );
}

export default TerminalView;