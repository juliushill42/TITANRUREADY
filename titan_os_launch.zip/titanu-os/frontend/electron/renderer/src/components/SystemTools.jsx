/**
 * TITANU AI — TitanU OS v3.0 Genesis
 * System Tools Sidebar
 * Drive status, core status, panel toggles, settings
 * Unified TITAN Chat Design
 */
import React, { useState } from 'react';
import GenesisBadge from './GenesisBadge';
import { clearGenesisKey } from '../utils/genesisKey';

function SystemTools({ status, activePanels, onTogglePanel, chatHistory = [], operatorNumber = 1 }) {
    const [expanded, setExpanded] = useState({
        status: true,
        panels: true,
        tools: false
    });
    const [showSettings, setShowSettings] = useState(false);

    const toggleSection = (section) => {
        setExpanded(prev => ({
            ...prev,
            [section]: !prev[section]
        }));
    };

    // Export chat logs to text file
    const handleExportLogs = () => {
        const logs = chatHistory.map(msg => {
            const timestamp = msg.timestamp ? new Date(msg.timestamp).toLocaleString() : 'N/A';
            const sender = msg.type === 'user-command' ? 'USER' : 'TITAN';
            return `[${timestamp}] ${sender}: ${msg.content}`;
        }).join('\n');
        
        const blob = new Blob([logs], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `titan_logs_${new Date().toISOString().split('T')[0]}.txt`;
        a.click();
        URL.revokeObjectURL(url);
    };

    // Restart the application
    const handleRestartCore = () => {
        if (confirm('Are you sure you want to restart TITAN Core?')) {
            window.location.reload();
        }
    };

    // Toggle settings panel
    const handleSettings = () => {
        setShowSettings(!showSettings);
    };

    // Handle changing Genesis Key
    const handleChangeKey = () => {
        if (confirm('Are you sure you want to change your Genesis Key? You will need to re-enter a valid key.')) {
            clearGenesisKey();
            window.location.reload();
        }
    };

    return (
        <div className="system-tools">
            {/* Status Section */}
            <div className="tools-section">
                <div 
                    className="section-header"
                    onClick={() => toggleSection('status')}
                >
                    <span className="section-icon">{expanded.status ? '▼' : '▶'}</span>
                    <span className="section-title">SYSTEM STATUS</span>
                </div>
                
                {expanded.status && (
                    <div className="section-content animate-fadeIn">
                        {/* Genesis Operator Badge */}
                        <div style={{ marginBottom: 'var(--spacing-md)' }}>
                            <GenesisBadge operatorNumber={operatorNumber} isActive={status.online} />
                        </div>
                        
                        <div className="status-item">
                            <span className="status-label">Core</span>
                            <span className={`status-value ${status.online ? 'online' : 'offline'}`}>
                                {status.online ? '● Online' : '○ Offline'}
                            </span>
                        </div>
                        
                        <div className="status-item">
                            <span className="status-label">TitanU Drive</span>
                            <span className={`status-value ${status.driveLetter ? 'online' : ''}`}>
                                {status.driveLetter || 'Not detected'}
                            </span>
                        </div>
                        
                        <div className="status-item">
                            <span className="status-label">Mode</span>
                            <span className="status-value secure">
                                🔒 Local
                            </span>
                        </div>
                    </div>
                )}
            </div>

            {/* Panels Section */}
            <div className="tools-section">
                <div 
                    className="section-header"
                    onClick={() => toggleSection('panels')}
                >
                    <span className="section-icon">{expanded.panels ? '▼' : '▶'}</span>
                    <span className="section-title">PANELS</span>
                </div>
                
                {expanded.panels && (
                    <div className="section-content animate-fadeIn">
                        <button 
                            className={`panel-toggle ${activePanels.memory ? 'active' : ''}`}
                            onClick={() => onTogglePanel('memory')}
                        >
                            <span className="toggle-icon">🧠</span>
                            <span className="toggle-label">Memory</span>
                            <span className="toggle-status">{activePanels.memory ? 'ON' : 'OFF'}</span>
                        </button>
                        
                        <button 
                            className={`panel-toggle ${activePanels.files ? 'active' : ''}`}
                            onClick={() => onTogglePanel('files')}
                        >
                            <span className="toggle-icon">📁</span>
                            <span className="toggle-label">Files</span>
                            <span className="toggle-status">{activePanels.files ? 'ON' : 'OFF'}</span>
                        </button>
                        
                        <button 
                            className={`panel-toggle ${activePanels.browser ? 'active' : ''}`}
                            onClick={() => onTogglePanel('browser')}
                        >
                            <span className="toggle-icon">🌐</span>
                            <span className="toggle-label">Browser</span>
                            <span className="toggle-status">{activePanels.browser ? 'ON' : 'OFF'}</span>
                        </button>
                    </div>
                )}
            </div>

            {/* Quick Tools Section */}
            <div className="tools-section">
                <div 
                    className="section-header"
                    onClick={() => toggleSection('tools')}
                >
                    <span className="section-icon">{expanded.tools ? '▼' : '▶'}</span>
                    <span className="section-title">QUICK TOOLS</span>
                </div>
                
                {expanded.tools && (
                    <div className="section-content animate-fadeIn">
                        <button className="tool-button" onClick={handleExportLogs}>
                            <span>📋</span> Export Logs
                        </button>
                        <button className="tool-button" onClick={handleRestartCore}>
                            <span>🔄</span> Restart Core
                        </button>
                        <button className="tool-button" onClick={handleSettings}>
                            <span>⚙️</span> Settings
                        </button>
                    </div>
                )}
            </div>

            {/* Settings Modal */}
            {showSettings && (
                <div className="settings-modal" onClick={() => setShowSettings(false)}>
                    <div className="settings-content" onClick={(e) => e.stopPropagation()}>
                        <div className="settings-header">
                            <h2>⚙️ Settings</h2>
                            <button className="close-btn" onClick={() => setShowSettings(false)}>✕</button>
                        </div>
                        <div className="settings-body">
                            <div className="setting-section">
                                <h3 className="setting-section-title">Genesis Operator</h3>
                                <div className="setting-item">
                                    <span className="setting-label">Operator Number</span>
                                    <span className="setting-value">#{String(operatorNumber).padStart(3, '0')}</span>
                                </div>
                                <button className="change-key-btn" onClick={handleChangeKey}>
                                    🔑 Change Genesis Key
                                </button>
                            </div>
                            
                            <div className="setting-section">
                                <h3 className="setting-section-title">System</h3>
                                <div className="setting-item">
                                    <span className="setting-label">Theme</span>
                                    <span className="setting-value">Cyber Mint (Default)</span>
                                </div>
                                <div className="setting-item">
                                    <span className="setting-label">Mode</span>
                                    <span className="setting-value">🔒 Local</span>
                                </div>
                                <div className="setting-item">
                                    <span className="setting-label">Version</span>
                                    <span className="setting-value">v3.0 Genesis</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* Footer */}
            <div className="tools-footer">
                <div className="footer-logo">⬡ TITANU AI</div>
                <div className="footer-edition">v3.0 Genesis</div>
            </div>

            <style jsx>{`
                .system-tools {
                    display: flex;
                    flex-direction: column;
                    height: 100%;
                    padding: var(--spacing-sm);
                    position: relative;
                    z-index: 2;
                }

                .tools-section {
                    margin-bottom: var(--spacing-sm);
                }

                .section-header {
                    display: flex;
                    align-items: center;
                    gap: var(--spacing-xs);
                    padding: var(--spacing-sm);
                    cursor: pointer;
                    border-radius: var(--radius-md);
                    transition: all var(--transition-fast);
                }

                .section-header:hover {
                    background: rgba(0, 255, 200, 0.08);
                }

                .section-icon {
                    font-size: 8px;
                    color: var(--neon-mint);
                    opacity: 0.7;
                }

                .section-title {
                    font-family: var(--font-mono);
                    font-size: 11px;
                    font-weight: 600;
                    letter-spacing: 0.08em;
                    color: var(--neon-mint);
                }

                .section-content {
                    padding: var(--spacing-xs) var(--spacing-sm);
                }

                .animate-fadeIn {
                    animation: fadeIn 0.3s ease-out;
                }

                @keyframes fadeIn {
                    from { 
                        opacity: 0; 
                        transform: translateY(-5px);
                    }
                    to { 
                        opacity: 1; 
                        transform: translateY(0);
                    }
                }

                .status-item {
                    display: flex;
                    justify-content: space-between;
                    padding: var(--spacing-xs) 0;
                    font-size: 12px;
                    font-family: var(--font-mono);
                }

                .status-label {
                    color: var(--text-secondary);
                }

                .status-value {
                    color: var(--text-primary);
                }

                .status-value.online {
                    color: var(--neon-mint);
                    text-shadow: 0 0 8px var(--glow-soft);
                }

                .status-value.offline {
                    color: var(--text-muted);
                }

                .status-value.secure {
                    color: var(--neon-mint);
                }

                .panel-toggle {
                    display: flex;
                    align-items: center;
                    width: 100%;
                    padding: var(--spacing-sm);
                    margin-bottom: var(--spacing-xs);
                    background: rgba(0, 255, 200, 0.05);
                    border: 1px solid var(--border-color);
                    border-radius: var(--radius-md);
                    cursor: pointer;
                    transition: all var(--transition-fast);
                    font-family: var(--font-mono);
                    font-size: 12px;
                    color: var(--text-primary);
                }

                .panel-toggle:hover {
                    background: rgba(0, 255, 200, 0.1);
                    border-color: var(--neon-mint);
                    transform: translateX(2px);
                }

                .panel-toggle.active {
                    border-color: var(--neon-mint);
                    background: rgba(0, 255, 200, 0.12);
                    box-shadow: 0 0 10px var(--glow-soft);
                }

                .toggle-icon {
                    margin-right: var(--spacing-sm);
                }

                .toggle-label {
                    flex: 1;
                    text-align: left;
                }

                .toggle-status {
                    font-size: 10px;
                    font-weight: 600;
                    letter-spacing: 0.05em;
                    color: var(--text-muted);
                    padding: 2px 6px;
                    background: rgba(0, 0, 0, 0.2);
                    border-radius: var(--radius-pill);
                }

                .panel-toggle.active .toggle-status {
                    color: var(--dark-graphite);
                    background: var(--neon-mint);
                    text-shadow: none;
                }

                .tool-button {
                    display: flex;
                    align-items: center;
                    gap: var(--spacing-sm);
                    width: 100%;
                    padding: var(--spacing-sm);
                    margin-bottom: var(--spacing-xs);
                    background: transparent;
                    border: none;
                    border-radius: var(--radius-md);
                    cursor: pointer;
                    font-family: var(--font-mono);
                    font-size: 12px;
                    color: var(--text-secondary);
                    transition: all var(--transition-fast);
                }

                .tool-button:hover {
                    background: rgba(0, 255, 200, 0.08);
                    color: var(--neon-mint);
                    transform: translateX(2px);
                }

                .tools-footer {
                    margin-top: auto;
                    padding: var(--spacing-md);
                    text-align: center;
                    border-top: 1px solid var(--border-color);
                }

                .footer-logo {
                    font-family: var(--font-mono);
                    font-size: 15px;
                    font-weight: 900;
                    letter-spacing: 0.15em;
                    color: var(--neon-mint);
                    margin-bottom: var(--spacing-xs);
                    text-shadow: 
                        0 0 8px var(--glow-soft),
                        1px 1px 0px #004433;
                }

                .footer-edition {
                    font-family: var(--font-mono);
                    font-size: 10px;
                    font-weight: 500;
                    letter-spacing: 0.1em;
                    color: var(--cyber-yellow);
                    padding: 2px 8px;
                    background: rgba(255, 216, 74, 0.1);
                    border: 1px solid rgba(255, 216, 74, 0.3);
                    border-radius: var(--radius-pill);
                    display: inline-block;
                }

                .settings-modal {
                    position: fixed;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background: rgba(0, 0, 0, 0.8);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    z-index: 1000;
                    animation: fadeIn 0.2s ease-out;
                }

                .settings-content {
                    background: var(--dark-graphite);
                    border: 1px solid var(--neon-mint);
                    border-radius: var(--radius-md);
                    width: 90%;
                    max-width: 400px;
                    box-shadow: 0 0 20px var(--glow-soft);
                    animation: slideIn 0.3s ease-out;
                }

                @keyframes slideIn {
                    from {
                        opacity: 0;
                        transform: translateY(-20px);
                    }
                    to {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }

                .settings-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: var(--spacing-md);
                    border-bottom: 1px solid var(--border-color);
                }

                .settings-header h2 {
                    margin: 0;
                    font-family: var(--font-mono);
                    font-size: 16px;
                    color: var(--neon-mint);
                    letter-spacing: 0.1em;
                }

                .close-btn {
                    background: transparent;
                    border: none;
                    color: var(--text-secondary);
                    font-size: 20px;
                    cursor: pointer;
                    transition: all var(--transition-fast);
                    padding: 4px 8px;
                }

                .close-btn:hover {
                    color: var(--neon-mint);
                    transform: scale(1.1);
                }

                .settings-body {
                    padding: var(--spacing-md);
                }

                .setting-section {
                    margin-bottom: var(--spacing-lg);
                }

                .setting-section:last-child {
                    margin-bottom: 0;
                }

                .setting-section-title {
                    font-family: var(--font-mono);
                    font-size: 11px;
                    font-weight: 600;
                    letter-spacing: 0.08em;
                    color: var(--cyber-yellow);
                    margin: 0 0 var(--spacing-sm) 0;
                    text-transform: uppercase;
                }

                .setting-item {
                    display: flex;
                    justify-content: space-between;
                    padding: var(--spacing-sm) 0;
                    border-bottom: 1px solid rgba(0, 255, 200, 0.1);
                    font-family: var(--font-mono);
                    font-size: 12px;
                }

                .setting-item:last-child {
                    border-bottom: none;
                }

                .setting-label {
                    color: var(--text-secondary);
                }

                .setting-value {
                    color: var(--neon-mint);
                }

                .change-key-btn {
                    width: 100%;
                    padding: var(--spacing-sm);
                    margin-top: var(--spacing-sm);
                    background: rgba(255, 215, 0, 0.1);
                    border: 1px solid rgba(255, 215, 0, 0.3);
                    border-radius: var(--radius-md);
                    color: var(--cyber-yellow);
                    font-family: var(--font-mono);
                    font-size: 11px;
                    font-weight: 600;
                    letter-spacing: 0.05em;
                    cursor: pointer;
                    transition: all var(--transition-fast);
                }

                .change-key-btn:hover {
                    background: rgba(255, 215, 0, 0.15);
                    border-color: rgba(255, 215, 0, 0.5);
                    transform: translateY(-1px);
                    box-shadow: 0 0 10px rgba(255, 215, 0, 0.2);
                }
            `}</style>
        </div>
    );
}

export default SystemTools;