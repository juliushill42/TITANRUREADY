/**
 * TitanU OS
 * Boot Sequence Component
 * Cyberpunk-style animated loading screen with smooth transitions
 */
import React, { useState, useEffect } from 'react';

const BOOT_STEPS = [
    { id: 'init', text: 'INITIALIZING CORE SYSTEMS', delay: 800 },
    { id: 'mem', text: 'LOADING MEMORY MODULES', delay: 750 },
    { id: 'neural', text: 'ESTABLISHING NEURAL LINKS', delay: 850 },
    { id: 'encrypt', text: 'ACTIVATING ENCRYPTION LAYER', delay: 800 },
    { id: 'agents', text: 'SPAWNING AI AGENTS', delay: 900 },
    { id: 'sync', text: 'SYNCHRONIZING SYSTEMS', delay: 750 },
    { id: 'ready', text: 'SYSTEM ONLINE', delay: 1000 },
];

function BootSequence({ onComplete }) {
    const [currentStep, setCurrentStep] = useState(-1); // Start at -1 for initial wake-up
    const [stepProgress, setStepProgress] = useState(0);
    const [glitchText, setGlitchText] = useState('');
    const [showFinal, setShowFinal] = useState(false);
    const [fadeOut, setFadeOut] = useState(false);
    const [staticIntensity, setStaticIntensity] = useState(0.3);

    // Initial wake-up effect
    useEffect(() => {
        // Start with high static, fade it out
        const staticTimer = setTimeout(() => {
            setCurrentStep(0);
            setStaticIntensity(0.05);
        }, 600);
        
        return () => clearTimeout(staticTimer);
    }, []);

    // Static flicker effect (continuous)
    useEffect(() => {
        const flickerInterval = setInterval(() => {
            setStaticIntensity(prev => {
                const flicker = Math.random() * 0.1;
                return prev + (Math.random() > 0.5 ? flicker : -flicker);
            });
        }, 100);
        
        return () => clearInterval(flickerInterval);
    }, []);

    // Progress through boot steps
    useEffect(() => {
        if (currentStep < 0) return; // Wait for initial wake-up
        
        if (currentStep >= BOOT_STEPS.length) {
            // All steps complete, show final screen
            setShowFinal(true);
            setTimeout(() => {
                setFadeOut(true);
                setTimeout(() => {
                    onComplete?.();
                }, 800);
            }, 1200);
            return;
        }

        const step = BOOT_STEPS[currentStep];
        setStepProgress(0);
        setGlitchText('');

        // Animate progress bar (slower)
        const progressInterval = setInterval(() => {
            setStepProgress(prev => {
                if (prev >= 100) {
                    clearInterval(progressInterval);
                    return 100;
                }
                return prev + Math.random() * 8 + 3; // Slower progress
            });
        }, step.delay / 12);

        // Subtle glitch effect
        const glitchInterval = setInterval(() => {
            if (Math.random() > 0.85) { // Less frequent
                const chars = '▓▒░█▄▀';
                const glitch = Array(2).fill(0).map(() =>
                    chars[Math.floor(Math.random() * chars.length)]
                ).join('');
                setGlitchText(glitch);
                setTimeout(() => setGlitchText(''), 60);
            }
        }, 200);

        // Move to next step
        const stepTimer = setTimeout(() => {
            clearInterval(progressInterval);
            clearInterval(glitchInterval);
            setCurrentStep(prev => prev + 1);
        }, step.delay);

        return () => {
            clearInterval(progressInterval);
            clearInterval(glitchInterval);
            clearTimeout(stepTimer);
        };
    }, [currentStep, onComplete]);

    return (
        <div className={`boot-sequence ${fadeOut ? 'fade-out' : ''}`}>
            {/* Static/CRT effect */}
            <div
                className="static-overlay"
                style={{
                    opacity: Math.max(0, Math.min(staticIntensity, 0.4)),
                    background: `repeating-linear-gradient(
                        0deg,
                        rgba(0, 0, 0, 0.15),
                        rgba(0, 0, 0, 0.15) 1px,
                        transparent 1px,
                        transparent 2px
                    )`
                }}
            ></div>
            
            {/* Scanline overlay */}
            <div className="scanlines"></div>
            
            {/* Subtle glitch overlay */}
            <div className="glitch-overlay"></div>

            {/* Main content */}
            <div className="boot-content">
                {/* Logo */}
                <div className={`boot-logo ${currentStep >= 0 ? 'wake-up' : ''}`}>
                    <div className="logo-hex">⬡</div>
                    <div className="logo-text">
                        <span className="logo-main">TitanU</span>
                        <span className="logo-sub">OS</span>
                    </div>
                </div>

                {/* Boot steps - ONE AT A TIME */}
                {!showFinal && currentStep >= 0 && currentStep < BOOT_STEPS.length && (
                    <div className="boot-steps">
                        {(() => {
                            const step = BOOT_STEPS[currentStep];
                            return (
                                <div
                                    key={step.id}
                                    className="boot-step active step-fade-in"
                                >
                                    <span className="step-marker">›</span>
                                    <span className="step-text">
                                        {step.text}
                                        {glitchText && (
                                            <span className="glitch-chars">{glitchText}</span>
                                        )}
                                    </span>
                                    <div className="step-progress">
                                        <div
                                            className="progress-bar"
                                            style={{ width: `${Math.min(stepProgress, 100)}%` }}
                                        ></div>
                                    </div>
                                </div>
                            );
                        })()}
                    </div>
                )}

                {/* Final ready screen */}
                {showFinal && (
                    <div className="boot-final">
                        <div className="final-status">
                            <span className="status-dot"></span>
                            <span className="status-text">SYSTEM ONLINE</span>
                        </div>
                        <div className="final-enter">ENTERING INTERFACE</div>
                    </div>
                )}

                {/* Bottom info */}
                <div className="boot-footer">
                    <div className="footer-left">
                    </div>
                    <div className="footer-right">
                    </div>
                </div>
            </div>

            <style jsx>{`
                .boot-sequence {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: linear-gradient(135deg, #020205 0%, #0A0E14 50%, #050508 100%);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    z-index: 9999;
                    transition: opacity 0.8s ease-out, transform 0.8s ease-out;
                }

                .boot-sequence.fade-out {
                    opacity: 0;
                    transform: scale(1.05);
                }

                .scanlines {
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: repeating-linear-gradient(
                        0deg,
                        rgba(0, 0, 0, 0.1) 0px,
                        rgba(0, 0, 0, 0.1) 1px,
                        transparent 1px,
                        transparent 2px
                    );
                    pointer-events: none;
                    z-index: 2;
                }

                .static-overlay {
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    pointer-events: none;
                    z-index: 3;
                    mix-blend-mode: overlay;
                }

                .glitch-overlay {
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: linear-gradient(
                        90deg,
                        transparent 0%,
                        rgba(0, 255, 200, 0.02) 50%,
                        transparent 100%
                    );
                    animation: glitchSweep 6s ease-in-out infinite;
                    pointer-events: none;
                    z-index: 1;
                }

                @keyframes glitchSweep {
                    0%, 100% { transform: translateX(-100%); opacity: 0; }
                    50% { transform: translateX(100%); opacity: 0.5; }
                }

                .boot-content {
                    position: relative;
                    z-index: 3;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    gap: 32px;
                    padding: 40px;
                }

                .boot-logo {
                    display: flex;
                    align-items: center;
                    gap: 16px;
                    opacity: 0;
                    filter: blur(20px);
                    transition: all 0.6s ease-out;
                }

                .boot-logo.wake-up {
                    opacity: 1;
                    filter: blur(0);
                    animation: logoWakeUp 1.2s ease-out;
                }

                @keyframes logoWakeUp {
                    0% {
                        opacity: 0;
                        filter: blur(20px) brightness(0.3);
                        transform: scale(0.95);
                    }
                    50% {
                        opacity: 0.5;
                        filter: blur(10px) brightness(0.6);
                    }
                    100% {
                        opacity: 1;
                        filter: blur(0) brightness(1);
                        transform: scale(1);
                    }
                }

                .logo-hex {
                    font-size: 64px;
                    color: #00FFCC;
                    text-shadow: 
                        0 0 20px rgba(0, 255, 200, 0.5),
                        0 0 40px rgba(0, 255, 200, 0.3),
                        0 0 60px rgba(0, 255, 200, 0.2);
                    animation: hexPulse 2s ease-in-out infinite;
                }

                @keyframes hexPulse {
                    0%, 100% { 
                        opacity: 0.8;
                        transform: scale(1);
                    }
                    50% { 
                        opacity: 1;
                        transform: scale(1.05);
                    }
                }

                .logo-text {
                    display: flex;
                    flex-direction: column;
                }

                .logo-main {
                    font-family: 'JetBrains Mono', monospace;
                    font-size: 42px;
                    font-weight: 900;
                    letter-spacing: 0.2em;
                    color: #C8FFF5;
                    text-shadow:
                        0 0 10px rgba(0, 255, 200, 0.5),
                        2px 2px 0px #004433,
                        4px 4px 0px rgba(0, 68, 51, 0.3);
                }

                .logo-sub {
                    font-family: 'JetBrains Mono', monospace;
                    font-size: 16px;
                    font-weight: 600;
                    letter-spacing: 0.5em;
                    color: #00FFCC;
                    text-align: right;
                    margin-top: -5px;
                }

                .version-badge {
                    font-family: 'JetBrains Mono', monospace;
                    font-size: 11px;
                    font-weight: 600;
                    letter-spacing: 0.15em;
                    color: #0A0A0A;
                    background: #FFD84A;
                    padding: 4px 16px;
                    border-radius: 20px;
                    box-shadow: 0 0 20px rgba(255, 216, 74, 0.4);
                    animation: badgeFadeIn 0.6s ease-out 0.4s both;
                }

                @keyframes badgeFadeIn {
                    from {
                        opacity: 0;
                        transform: translateY(10px);
                    }
                    to {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }

                .boot-steps {
                    display: flex;
                    flex-direction: column;
                    gap: 8px;
                    min-width: 380px;
                    animation: stepsFadeIn 0.5s ease-out 0.6s both;
                }

                @keyframes stepsFadeIn {
                    from {
                        opacity: 0;
                    }
                    to {
                        opacity: 1;
                    }
                }

                .boot-step {
                    display: flex;
                    align-items: center;
                    gap: 12px;
                    padding: 8px 12px;
                    background: rgba(0, 255, 200, 0.03);
                    border: 1px solid rgba(0, 255, 200, 0.1);
                    border-radius: 6px;
                    font-family: 'JetBrains Mono', monospace;
                    font-size: 11px;
                    position: relative;
                }

                .step-fade-in {
                    animation: stepFadeIn 0.6s ease-out;
                }

                @keyframes stepFadeIn {
                    0% {
                        opacity: 0;
                        transform: translateY(10px);
                        filter: blur(5px);
                    }
                    50% {
                        opacity: 0.5;
                        filter: blur(2px);
                    }
                    100% {
                        opacity: 1;
                        transform: translateY(0);
                        filter: blur(0);
                    }
                }

                .boot-step.active {
                    background: rgba(0, 255, 200, 0.08);
                    border-color: rgba(0, 255, 200, 0.3);
                    box-shadow: 0 0 15px rgba(0, 255, 200, 0.1);
                }

                .boot-step.complete {
                    opacity: 0.6;
                }

                .step-marker {
                    color: #00FFCC;
                    font-size: 12px;
                    width: 16px;
                    text-align: center;
                }

                .boot-step.active .step-marker {
                    animation: markerBlink 0.5s infinite;
                }

                @keyframes markerBlink {
                    0%, 100% { opacity: 1; }
                    50% { opacity: 0.3; }
                }

                .step-text {
                    color: #88AAA2;
                    letter-spacing: 0.1em;
                    flex: 1;
                }

                .boot-step.active .step-text {
                    color: #00FFCC;
                }

                .glitch-chars {
                    color: #00FFCC;
                    margin-left: 4px;
                    font-weight: bold;
                    opacity: 0.7;
                    text-shadow: 0 0 5px rgba(0, 255, 200, 0.5);
                }

                .step-progress {
                    position: absolute;
                    bottom: 0;
                    left: 0;
                    width: 100%;
                    height: 2px;
                    background: rgba(0, 255, 200, 0.1);
                    border-radius: 0 0 6px 6px;
                    overflow: hidden;
                }

                .progress-bar {
                    height: 100%;
                    background: linear-gradient(90deg, #00FFCC, #00DDAA);
                    box-shadow: 0 0 10px rgba(0, 255, 200, 0.5);
                    transition: width 0.1s ease-out;
                }

                .boot-final {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    gap: 16px;
                    animation: finalFadeIn 0.5s ease-out;
                }

                @keyframes finalFadeIn {
                    from {
                        opacity: 0;
                        transform: scale(0.95);
                    }
                    to {
                        opacity: 1;
                        transform: scale(1);
                    }
                }

                .final-status {
                    display: flex;
                    align-items: center;
                    gap: 12px;
                    font-family: 'JetBrains Mono', monospace;
                    font-size: 18px;
                    font-weight: 700;
                    letter-spacing: 0.2em;
                    color: #00FFCC;
                }

                .status-dot {
                    width: 12px;
                    height: 12px;
                    background: #00FFCC;
                    border-radius: 50%;
                    box-shadow: 0 0 15px rgba(0, 255, 200, 0.8);
                    animation: dotPulse 1s ease-in-out infinite;
                }

                @keyframes dotPulse {
                    0%, 100% { 
                        box-shadow: 0 0 15px rgba(0, 255, 200, 0.8);
                    }
                    50% { 
                        box-shadow: 0 0 25px rgba(0, 255, 200, 1);
                    }
                }

                .final-enter {
                    font-family: 'JetBrains Mono', monospace;
                    font-size: 12px;
                    color: #FFD84A;
                    letter-spacing: 0.15em;
                    animation: enterBlink 0.8s infinite;
                }

                @keyframes enterBlink {
                    0%, 100% { opacity: 1; }
                    50% { opacity: 0.5; }
                }

                .boot-footer {
                    position: absolute;
                    bottom: 40px;
                    left: 40px;
                    right: 40px;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    font-family: 'JetBrains Mono', monospace;
                    font-size: 10px;
                    color: #556666;
                    letter-spacing: 0.1em;
                    animation: footerFadeIn 0.5s ease-out 1s both;
                }

                @keyframes footerFadeIn {
                    from { opacity: 0; }
                    to { opacity: 1; }
                }

                .footer-left {
                    display: flex;
                    align-items: center;
                    gap: 8px;
                }

                .footer-divider {
                    color: #333;
                }

                .footer-version {
                    color: #333;
                }
            `}</style>
        </div>
    );
}

export default BootSequence;