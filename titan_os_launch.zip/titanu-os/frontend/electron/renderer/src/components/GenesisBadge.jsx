import React from 'react';
import './GenesisBadge.css';

// TITAN Logo SVG as a clean icon
const TitanLogo = () => (
    <svg
        width="32"
        height="32"
        viewBox="0 0 32 32"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="titan-logo-svg"
    >
        {/* Hexagon outline */}
        <path
            d="M16 2L28 9V23L16 30L4 23V9L16 2Z"
            stroke="#FFD94A"
            strokeWidth="1.5"
            fill="rgba(255, 217, 74, 0.1)"
        />
        {/* Inner T shape */}
        <path
            d="M10 10H22V13H17.5V24H14.5V13H10V10Z"
            fill="#FFD94A"
        />
    </svg>
);

const GenesisBadge = ({ operatorNumber = 1, isActive = true }) => {
    const paddedNumber = String(operatorNumber).padStart(3, '0');
    const memberSince = new Date().getFullYear();
    
    return (
        <div className="genesis-badge">
            <div className="badge-border"></div>
            <div className="badge-inner">
                <div className="badge-header">
                    <div className="badge-emblem">
                        <TitanLogo />
                    </div>
                    {isActive && <div className="badge-status">ACTIVE</div>}
                </div>
                <div className="badge-body">
                    <div className="badge-label">GENESIS OPERATOR</div>
                    <div className="badge-number">#{paddedNumber}</div>
                    <div className="badge-divider"></div>
                    <div className="badge-meta">
                        <span className="badge-year">Est. {memberSince}</span>
                        <span className="badge-status-dot"></span>
                        <span className="badge-access">LIFETIME</span>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default GenesisBadge;