/**
 * TITANU AI — TitanU OS (Commander Edition)
 * Voice Button Component
 * Microphone recording button for voice input
 * Commander Edition Design System
 */
import React, { useState, useRef } from 'react';

function VoiceButton() {
    const [recording, setRecording] = useState(false);
    const [supported, setSupported] = useState(true);
    const mediaRecorderRef = useRef(null);
    const chunksRef = useRef([]);

    const startRecording = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            const mediaRecorder = new MediaRecorder(stream);
            mediaRecorderRef.current = mediaRecorder;
            chunksRef.current = [];

            mediaRecorder.ondataavailable = (e) => {
                if (e.data.size > 0) {
                    chunksRef.current.push(e.data);
                }
            };

            mediaRecorder.onstop = () => {
                const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
                // TODO: Convert to WAV and send to backend
                console.log('[Voice] Recording complete:', blob.size, 'bytes');
                stream.getTracks().forEach(track => track.stop());
            };

            mediaRecorder.start();
            setRecording(true);
        } catch (err) {
            console.error('[Voice] Failed to start recording:', err);
            setSupported(false);
        }
    };

    const stopRecording = () => {
        if (mediaRecorderRef.current && recording) {
            mediaRecorderRef.current.stop();
            setRecording(false);
        }
    };

    const handleClick = () => {
        if (recording) {
            stopRecording();
        } else {
            startRecording();
        }
    };

    if (!supported) {
        return (
            <button className="voice-button disabled" title="Microphone not available">
                🎤
                <style jsx>{`
                    .voice-button.disabled {
                        opacity: 0.4;
                        cursor: not-allowed;
                        background: rgba(15, 20, 25, 0.85);
                        border: 1px solid var(--border-color);
                        border-radius: var(--radius-md);
                        padding: var(--spacing-xs) var(--spacing-sm);
                        font-size: 14px;
                        color: var(--text-muted);
                    }
                `}</style>
            </button>
        );
    }

    return (
        <button 
            className={`voice-button ${recording ? 'recording' : ''}`}
            onClick={handleClick}
            title={recording ? 'Stop recording' : 'Start recording'}
        >
            <span className="voice-icon">{recording ? '⏹️' : '🎤'}</span>
            {recording && <span className="recording-indicator"></span>}
            
            <style jsx>{`
                .voice-button {
                    position: relative;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    background: rgba(0, 255, 200, 0.08);
                    border: 1px solid var(--border-color);
                    border-radius: var(--radius-md);
                    padding: var(--spacing-xs) var(--spacing-sm);
                    min-width: 36px;
                    min-height: 28px;
                    cursor: pointer;
                    transition: all var(--transition-fast);
                }

                .voice-icon {
                    font-size: 14px;
                    position: relative;
                    z-index: 1;
                }

                .voice-button:hover {
                    background: rgba(0, 255, 200, 0.15);
                    border-color: var(--neon-mint);
                    box-shadow: 0 0 10px var(--glow-soft);
                    transform: scale(1.05);
                }

                .voice-button:active {
                    transform: scale(0.95);
                }

                .voice-button.recording {
                    background: rgba(255, 68, 102, 0.2);
                    border-color: var(--error);
                    box-shadow: 0 0 15px rgba(255, 68, 102, 0.3);
                }

                .voice-button.recording:hover {
                    background: rgba(255, 68, 102, 0.3);
                    box-shadow: 0 0 20px rgba(255, 68, 102, 0.4);
                }

                .recording-indicator {
                    position: absolute;
                    top: -4px;
                    right: -4px;
                    width: 10px;
                    height: 10px;
                    background: var(--error);
                    border-radius: 50%;
                    animation: recordPulse 1s ease-in-out infinite;
                    box-shadow: 0 0 8px rgba(255, 68, 102, 0.6);
                }

                @keyframes recordPulse {
                    0%, 100% { 
                        opacity: 1;
                        transform: scale(1);
                    }
                    50% { 
                        opacity: 0.6;
                        transform: scale(1.2);
                    }
                }
            `}</style>
        </button>
    );
}

export default VoiceButton;