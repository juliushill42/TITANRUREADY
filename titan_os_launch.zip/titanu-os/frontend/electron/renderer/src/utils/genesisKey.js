const GENESIS_KEY_STORAGE = 'titan_genesis_key';
const GENESIS_NUMBER_STORAGE = 'titan_genesis_number';

export function validateGenesisKey(key) {
  if (!key || typeof key !== 'string') return { valid: false };
  
  const parts = key.split('-');
  if (parts.length !== 4) return { valid: false };
  if (parts[0] !== 'TITANU') return { valid: false };
  if (parts[1] !== 'GENESIS') return { valid: false };
  
  const operatorNum = parseInt(parts[2], 10);
  if (isNaN(operatorNum) || operatorNum < 1 || operatorNum > 100) {
    return { valid: false };
  }
  
  if (parts[3].length !== 6) return { valid: false };
  
  return { 
    valid: true, 
    operatorNumber: operatorNum,
    edition: 'GENESIS'
  };
}

export function checkStoredKey() {
  const storedKey = localStorage.getItem(GENESIS_KEY_STORAGE);
  if (storedKey) {
    const result = validateGenesisKey(storedKey);
    if (result.valid) {
      const operatorNumber = localStorage.getItem(GENESIS_NUMBER_STORAGE);
      return { ...result, operatorNumber: parseInt(operatorNumber, 10) };
    }
  }
  return null;
}

export function saveGenesisKey(key) {
  const result = validateGenesisKey(key);
  if (result.valid) {
    localStorage.setItem(GENESIS_KEY_STORAGE, key);
    localStorage.setItem(GENESIS_NUMBER_STORAGE, result.operatorNumber.toString());
    return result;
  }
  return { valid: false, error: 'Invalid Genesis Key format' };
}

export function clearGenesisKey() {
  localStorage.removeItem(GENESIS_KEY_STORAGE);
  localStorage.removeItem(GENESIS_NUMBER_STORAGE);
}