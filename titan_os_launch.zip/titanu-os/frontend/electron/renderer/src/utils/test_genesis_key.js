/**
 * Genesis Key Validation Tests
 * Run this in browser console or Node to test validation logic
 */

import { validateGenesisKey } from './genesisKey.js';

console.log('=== Genesis Key Validation Tests ===\n');

// Test cases
const testCases = [
    // Valid keys
    { key: 'TITANU-GENESIS-001-ABC123', expected: true, desc: 'Valid key #1' },
    { key: 'TITANU-GENESIS-050-XYZ789', expected: true, desc: 'Valid key #50' },
    { key: 'TITANU-GENESIS-100-QWE456', expected: true, desc: 'Valid key #100' },
    
    // Invalid keys
    { key: 'TITAN-GENESIS-001-ABC123', expected: false, desc: 'Wrong prefix (TITAN vs TITANU)' },
    { key: 'TITANU-GENESIS-001-ABC12', expected: false, desc: 'Code too short (5 chars)' },
    { key: 'TITANU-GENESIS-001-ABC1234', expected: false, desc: 'Code too long (7 chars)' },
    { key: 'TITANU-GENESIS-000-ABC123', expected: false, desc: 'Operator #0 (invalid)' },
    { key: 'TITANU-GENESIS-101-ABC123', expected: false, desc: 'Operator #101 (too high)' },
    { key: 'TITANU-INVALID-001-ABC123', expected: false, desc: 'Wrong edition (INVALID vs GENESIS)' },
    { key: 'TITANU-GENESIS-001', expected: false, desc: 'Missing code segment' },
    { key: 'TITANU-GENESIS-ABC-123456', expected: false, desc: 'Non-numeric operator' },
    { key: '', expected: false, desc: 'Empty string' },
    { key: null, expected: false, desc: 'Null value' },
];

// Run tests
let passed = 0;
let failed = 0;

testCases.forEach((test, index) => {
    const result = validateGenesisKey(test.key);
    const isValid = result.valid === test.expected;
    
    if (isValid) {
        passed++;
        console.log(`✓ Test ${index + 1}: ${test.desc}`);
        if (result.valid) {
            console.log(`  → Operator #${result.operatorNumber}, Edition: ${result.edition}`);
        }
    } else {
        failed++;
        console.log(`✗ Test ${index + 1}: ${test.desc}`);
        console.log(`  → Expected: ${test.expected}, Got: ${result.valid}`);
    }
});

console.log(`\n=== Test Results ===`);
console.log(`Passed: ${passed}/${testCases.length}`);
console.log(`Failed: ${failed}/${testCases.length}`);
console.log(`Success Rate: ${((passed / testCases.length) * 100).toFixed(1)}%`);

// Example valid keys for testing
console.log('\n=== Example Valid Genesis Keys ===');
console.log('TITANU-GENESIS-001-ABC123');
console.log('TITANU-GENESIS-042-XYZ789');
console.log('TITANU-GENESIS-099-KEY001');
console.log('TITANU-GENESIS-100-TITAN1');