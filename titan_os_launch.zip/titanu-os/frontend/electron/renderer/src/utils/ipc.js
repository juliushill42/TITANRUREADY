/**
 * Titan OS v2 - IPC Communication Utilities
 * Wrapper for titanAPI with error handling and convenience methods
 */

/**
 * Wait for titanAPI to become available with retry logic
 * Handles race condition between preload and React initialization
 */
export const waitForTitanAPI = (timeout = 5000) => {
    return new Promise((resolve, reject) => {
        // Check if already available
        if (window.titanAPI) {
            resolve(window.titanAPI);
            return;
        }
        
        const startTime = Date.now();
        const checkInterval = setInterval(() => {
            if (window.titanAPI) {
                clearInterval(checkInterval);
                resolve(window.titanAPI);
            } else if (Date.now() - startTime > timeout) {
                clearInterval(checkInterval);
                reject(new Error('TitanAPI not available after ' + timeout + 'ms timeout'));
            }
        }, 50); // Check every 50ms
    });
};

// Check if running in Electron
export const isElectron = () => {
    return typeof window !== 'undefined' && window.titanAPI !== undefined;
};

// Get the Titan API
export const getTitanAPI = () => {
    if (!isElectron()) {
        console.warn('[IPC] Not running in Electron environment');
        return null;
    }
    return window.titanAPI;
};

/**
 * Send a command to the Python backend
 * @param {string} command - Command name
 * @param {object} params - Command parameters
 * @returns {Promise} - Resolves when command is sent
 */
export const sendCommand = async (command, params = {}) => {
    try {
        // Wait for titanAPI to be available
        const api = await waitForTitanAPI();
        
        if (!api || !api.sendCommand) {
            throw new Error('TitanAPI sendCommand not available');
        }

        api.sendCommand(command, params);
        return Promise.resolve();
    } catch (error) {
        console.error('[IPC] Command failed:', command, error);
        throw error;
    }
};

/**
 * Invoke a command and wait for response
 * @param {string} command - Command name
 * @param {object} params - Command parameters
 * @returns {Promise<object>} - Response from backend
 */
export const invokeCommand = async (command, params = {}) => {
    try {
        // Wait for titanAPI to be available
        const api = await waitForTitanAPI();
        
        if (!api || !api.invokeCommand) {
            throw new Error('TitanAPI invokeCommand not available');
        }

        const result = await api.invokeCommand(command, params);
        return result;
    } catch (error) {
        console.error('[IPC] Failed to invoke command:', error);
        return { status: 'error', error: error.message };
    }
};

/**
 * Subscribe to backend responses
 * @param {function} callback - Callback function for responses
 * @returns {function} - Cleanup function
 */
export const onResponse = async (callback) => {
    try {
        const api = await waitForTitanAPI();
        if (!api || !api.onResponse) {
            console.warn('[IPC] Cannot subscribe - API not available');
            return () => {};
        }
        
        return api.onResponse(callback);
    } catch (error) {
        console.warn('[IPC] Cannot subscribe - API not available:', error);
        return () => {};
    }
};

// Convenience methods for specific commands

export const boot = () => sendCommand('boot');
export const shutdown = () => sendCommand('shutdown');

// Allowed file extensions for uploads
export const ALLOWED_EXTENSIONS = [
    '.txt', '.md', '.json', '.csv', '.xml', '.yaml', '.yml',
    '.py', '.js', '.jsx', '.ts', '.tsx', '.html', '.css',
    '.java', '.c', '.cpp', '.h', '.go', '.rs', '.rb',
    '.pdf', '.doc', '.docx', '.xls', '.xlsx',
    '.png', '.jpg', '.jpeg', '.gif', '.svg', '.webp',
    '.zip', '.tar', '.gz'
];

export const getAllowedExtensions = () => ALLOWED_EXTENSIONS;

/**
 * Upload a file to the backend
 * @param {File} file - File object from input or drag/drop
 * @returns {Promise<object>} - Upload result from backend
 */
export const uploadFile = (file) => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = async () => {
            const base64 = reader.result.split(',')[1]; // Remove data URL prefix
            try {
                const result = await invokeCommand('upload_file', {
                    filename: file.name,
                    content: base64,
                    content_type: file.type
                });
                resolve(result);
            } catch (error) {
                reject(error);
            }
        };
        reader.onerror = () => reject(new Error('Failed to read file'));
        reader.readAsDataURL(file);
    });
};

// File operations
export const saveFile = (filename, content, subfolder = '') =>
    invokeCommand('save_file', { filename, content, subfolder });

export const readFile = (filename, subfolder = '') =>
    invokeCommand('read_file', { filename, subfolder });

export const readFileByPath = (path) =>
    invokeCommand('read_file', { path });

export const listFiles = (subfolder = '', recursive = false) =>
    invokeCommand('list_files', { subfolder, recursive });

export const listFilesByPath = (path = null) =>
    invokeCommand('list_files', { path });

// Memory operations
export const logMemory = (content, tags = [], sessionId = 'default', role = null) =>
    invokeCommand('log_memory', {
        content,
        tags,
        session_id: sessionId,
        ...(role && { role })
    });

export const getMemory = (sessionId = null, limit = 50, tags = null, search = null) =>
    invokeCommand('get_memory', {
        session_id: sessionId,
        limit,
        ...(tags && { tags }),
        ...(search && { search })
    });

export const clearMemory = (sessionId = null) =>
    invokeCommand('clear_memory', { session_id: sessionId, confirm: true });

export const deleteMemory = (id) =>
    invokeCommand('delete_memory', { id });

export const searchMemory = (query, limit = 100) =>
    invokeCommand('search_memory', { query, limit });

export const memoryStats = () =>
    invokeCommand('memory_stats', {});

// Browser operations (legacy)
export const scrapeUrl = (url, timeout = 10) =>
    invokeCommand('scrape_url', { url, timeout });

export const summarize = (text, maxSentences = 5) =>
    invokeCommand('summarize', { text, max_sentences: maxSentences });

// Secure Browser operations (quarantined)
export const browserFetch = (url, extractText = true) =>
    invokeCommand('browser', { action: 'fetch', url, extract_text: extractText });

export const browserSearch = (query) =>
    invokeCommand('browser', { action: 'search', query });

export const browserStatus = () =>
    invokeCommand('browser', { action: 'status' });

export const browserValidate = (url) =>
    invokeCommand('browser', { action: 'validate', url });

// Voice operations
export const transcribeAudio = (audioPath, language = 'en-US', engine = 'sphinx') =>
    invokeCommand('transcribe_audio', { audio_path: audioPath, language, engine });

export const voiceStatus = () =>
    invokeCommand('voice_status', {});

// Agent operations
export const listAgents = () =>
    invokeCommand('agents', { action: 'list' });

export const getAgent = (agentId) =>
    invokeCommand('agents', { action: 'get', agent_id: agentId });

export const createAgent = (name, role, systemPrompt, capabilities = [], temperature = 0.7) =>
    invokeCommand('agents', {
        action: 'create',
        name,
        role,
        system_prompt: systemPrompt,
        capabilities,
        temperature
    });

export const createAgentFromDescription = (description) =>
    invokeCommand('create_agent', { description });

export const getAgentTemplates = () =>
    invokeCommand('agents', { action: 'templates' });

export const deleteAgent = (agentId) =>
    invokeCommand('agents', { action: 'delete', agent_id: agentId });

export const invokeAgent = (agentId, message, context = {}) =>
    invokeCommand('agents', { action: 'invoke', agent_id: agentId, message, context });

// Platform info
export const getPlatform = () => {
    const api = getTitanAPI();
    return api?.platform || 'unknown';
};

export const getVersion = () => {
    const api = getTitanAPI();
    return api?.version || '0.0.0';
};

export default {
    waitForTitanAPI,
    isElectron,
    getTitanAPI,
    sendCommand,
    invokeCommand,
    onResponse,
    boot,
    shutdown,
    uploadFile,
    getAllowedExtensions,
    ALLOWED_EXTENSIONS,
    saveFile,
    readFile,
    listFiles,
    logMemory,
    getMemory,
    clearMemory,
    deleteMemory,
    searchMemory,
    memoryStats,
    scrapeUrl,
    summarize,
    browserFetch,
    browserSearch,
    browserStatus,
    browserValidate,
    transcribeAudio,
    voiceStatus,
    listAgents,
    getAgent,
    createAgent,
    createAgentFromDescription,
    getAgentTemplates,
    deleteAgent,
    invokeAgent,
    getPlatform,
    getVersion
};