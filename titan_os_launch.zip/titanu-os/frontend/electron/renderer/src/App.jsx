/**
 * TITANU AI — TitanU OS v3.0 Genesis
 * Main Application Component
 * Unified TITAN Chat Interface
 * Terminal-OS aesthetic with multi-pane layout
 */
import React, { useState, useEffect } from 'react';
import UnifiedWorkspace from './components/UnifiedWorkspace';
import MemoryPane from './components/MemoryPane';
import FilePane from './components/FilePane';
import BrowserPane from './components/BrowserPane';
import SystemTools from './components/SystemTools';
import BootSequence from './components/BootSequence';
import GenesisKeyModal from './components/GenesisKeyModal';
import { waitForTitanAPI } from './utils/ipc';
import { checkStoredKey } from './utils/genesisKey';

// Default panel configuration
const DEFAULT_PANELS = {
    terminal: true,
    memory: false,
    files: false,
    browser: false,
    system: true
};

function App() {
    const [genesisKey, setGenesisKey] = useState(null);
    const [isCheckingKey, setIsCheckingKey] = useState(true);
    const [isBooting, setIsBooting] = useState(true);
    const [isAppReady, setIsAppReady] = useState(false);
    const [systemStatus, setSystemStatus] = useState({
        online: false,
        driveLetter: null,
        message: 'Initializing...'
    });
    const [activePanels, setActivePanels] = useState(DEFAULT_PANELS);
    const [responses, setResponses] = useState([]);

    // Check for stored Genesis Key on mount
    useEffect(() => {
        const storedKey = checkStoredKey();
        if (storedKey) {
            setGenesisKey(storedKey);
        }
        setIsCheckingKey(false);
    }, []);

    // Handle valid Genesis Key entry
    const handleValidKey = (keyData) => {
        setGenesisKey(keyData);
    };

    // Handle boot sequence completion
    const handleBootComplete = () => {
        setIsBooting(false);
        // Add a small delay for smooth transition
        setTimeout(() => {
            setIsAppReady(true);
        }, 100);
    };

    // Listen for Python backend responses and initiate boot
    useEffect(() => {
        let cleanup = () => {};
        
        // Wait for titanAPI to be available before using it
        waitForTitanAPI()
            .then((api) => {
                console.log('[App] TitanAPI ready, setting up listeners');
                
                cleanup = api.onResponse((response) => {
                    console.log('[App] Received response:', response);
                    
                    // Handle boot response
                    if (response.status === 'online') {
                        setSystemStatus({
                            online: true,
                            driveLetter: response.drive_letter,
                            message: response.message
                        });
                    }
                    
                    // Handle ready signal
                    if (response.status === 'ready') {
                        setSystemStatus(prev => ({
                            ...prev,
                            message: response.message || 'Ready'
                        }));
                    }
                    
                    // Add to responses for terminal/components
                    setResponses(prev => [...prev.slice(-99), response]);
                });
                
                // Request boot immediately after setting up listener
                // Boot command is idempotent and returns the current online status
                api.sendCommand('boot', {});
            })
            .catch((error) => {
                console.error('[App] TitanAPI not available:', error);
                setSystemStatus({
                    online: false,
                    driveLetter: null,
                    message: 'TitanAPI initialization failed: ' + error.message
                });
            });

        return () => cleanup();
    }, []);

    // Toggle panel visibility
    const togglePanel = (panel) => {
        setActivePanels(prev => ({
            ...prev,
            [panel]: !prev[panel]
        }));
    };

    // Show loading state while checking for key
    if (isCheckingKey) {
        return (
            <div style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                height: '100vh',
                background: '#050505',
                color: '#00FFC8',
                fontFamily: 'monospace',
                fontSize: '14px'
            }}>
                Initializing TITAN OS...
            </div>
        );
    }

    // Show Genesis Key modal if no valid key
    if (!genesisKey) {
        return <GenesisKeyModal onValidKey={handleValidKey} />;
    }

    // Show boot sequence
    if (isBooting) {
        return <BootSequence onComplete={handleBootComplete} />;
    }

    return (
        <div className={`app-container ${isAppReady ? 'ready' : 'entering'}`}>
            {/* Title Bar */}
            <header className="title-bar">
                <div className="title-bar-drag">
                    <span className="title-logo">⬡</span>
                    <span className="title-text">TITANU OS</span>
                    <span className="title-version">v3.0 Genesis</span>
                </div>
                <div className="title-controls">
                    <span className={`status-indicator ${systemStatus.online ? 'online' : 'offline'}`}>
                        {systemStatus.online ? '● ONLINE' : '○ OFFLINE'}
                    </span>
                    {systemStatus.driveLetter && (
                        <span className="drive-indicator">
                            USB: {systemStatus.driveLetter}
                        </span>
                    )}
                </div>
            </header>

            {/* Main Content */}
            <main className="main-content">
                {/* Left Sidebar - System Tools */}
                {activePanels.system && (
                    <aside className="sidebar-left">
                        <SystemTools
                            status={systemStatus}
                            activePanels={activePanels}
                            onTogglePanel={togglePanel}
                            chatHistory={responses}
                            operatorNumber={genesisKey?.operatorNumber || 1}
                        />
                    </aside>
                )}

                {/* Center - Unified TITAN Chat */}
                <section className="content-center">
                    <UnifiedWorkspace
                        responses={responses}
                        systemStatus={systemStatus}
                    />
                </section>

                {/* Right Sidebar - Secondary Panels */}
                <aside className="sidebar-right">
                    {activePanels.memory && (
                        <div className="panel-container animate-fadeIn">
                            <MemoryPane />
                        </div>
                    )}
                    {activePanels.files && (
                        <div className="panel-container animate-fadeIn">
                            <FilePane />
                        </div>
                    )}
                    {activePanels.browser && (
                        <div className="panel-container animate-fadeIn">
                            <BrowserPane />
                        </div>
                    )}
                </aside>
            </main>

            {/* Bottom Status Bar */}
            <footer className="status-bar">
                <div className="status-left">
                    <span className="status-secure">🔒 LOCAL • SECURE</span>
                </div>
                <div className="status-center">
                    {systemStatus.message}
                </div>
                <div className="status-right">
                    <span className="status-version">v3.0 Genesis</span>
                </div>
            </footer>

            <style jsx>{`
                .app-container.entering {
                    animation: appEnter 0.6s ease-out;
                }

                .app-container.ready {
                    animation: none;
                }

                @keyframes appEnter {
                    from {
                        opacity: 0;
                        transform: scale(0.98);
                    }
                    to {
                        opacity: 1;
                        transform: scale(1);
                    }
                }

                .sidebar-left,
                .content-center,
                .sidebar-right {
                    animation: panelSlideIn 0.5s ease-out;
                }

                .sidebar-left {
                    animation-delay: 0.1s;
                    animation-fill-mode: both;
                }

                .content-center {
                    animation-delay: 0.2s;
                    animation-fill-mode: both;
                }

                .sidebar-right {
                    animation-delay: 0.3s;
                    animation-fill-mode: both;
                }

                @keyframes panelSlideIn {
                    from {
                        opacity: 0;
                        transform: translateY(15px);
                    }
                    to {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }

                .title-bar {
                    animation: headerSlideIn 0.4s ease-out;
                }

                @keyframes headerSlideIn {
                    from {
                        opacity: 0;
                        transform: translateY(-10px);
                    }
                    to {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }

                .status-bar {
                    animation: footerSlideIn 0.4s ease-out 0.3s both;
                }

                @keyframes footerSlideIn {
                    from {
                        opacity: 0;
                        transform: translateY(10px);
                    }
                    to {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }
            `}</style>
        </div>
    );
}

export default App;