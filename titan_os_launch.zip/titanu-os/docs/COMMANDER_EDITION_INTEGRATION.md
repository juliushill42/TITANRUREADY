# Titan OS v2 - Commander Edition Integration Plan

## Quick Start: How to Run Commander Edition in v2

```
1. Launch Titan OS v2
2. Look at the left sidebar → EDITIONS section
3. Click "⚔️ Commander" button
4. Titan v2 launches Commander backend automatically
5. Commander UI appears inside v2 (WebView)
6. Submit tasks to the AI agent swarm!
7. Click ✕ or switch back to "Standard" when done
```

**Requirements:**
- Ollama must be running locally (`ollama serve`)
- Model must be installed (`ollama pull phi3:mini`)

---

## Executive Summary

This document outlines the strategy for integrating Titan OS v1.5 (the "Commander Edition") into Titan OS v2 as an accessible mode from the main menu. The Commander Edition brings multi-agent AI capabilities with local LLM integration via Ollama.

---

## Architecture Overview

### Titan OS v1.5 (Commander Edition)

```mermaid
graph TB
    subgraph Frontend
        UI[Web UI - HTML/CSS/JS]
        WS[WebSocket Client]
    end
    
    subgraph Backend - FastAPI
        API[FastAPI Server :8000]
        AM[AgentManager]
        SM[SharedMemory]
        CH[ChatHistory]
    end
    
    subgraph Agents
        COORD[Coordinator]
        ANAL[Analyzer]
        EXEC[Executor]
        RES[Researcher]
        OPT[Optimizer]
    end
    
    subgraph LLM Layer
        TLLM[titan_llm.py]
        OLLAMA[Ollama API :11434]
    end
    
    UI --> API
    WS --> API
    API --> AM
    AM --> SM
    AM --> CH
    AM --> COORD
    COORD --> ANAL
    COORD --> EXEC
    COORD --> RES
    COORD --> OPT
    ANAL --> TLLM
    EXEC --> TLLM
    RES --> TLLM
    OPT --> TLLM
    TLLM --> OLLAMA
```

**Key Components:**
- **FastAPI Server** - HTTP/WebSocket server on port 8000
- **AgentManager** - Orchestrates multi-agent task routing
- **5 Specialist Agents** - Coordinator, Analyzer, Executor, Researcher, Optimizer
- **titan_llm.py** - Ollama client using OpenAI-compatible API
- **SharedMemory** - Cross-agent knowledge store with 1000 entry limit
- **ChatHistory** - Conversation log with 400 message limit

**Endpoints:**
| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/` | GET | Main UI (Jinja2 template) |
| `/api/agents` | GET | List all agents with status |
| `/api/chat` | GET | Retrieve chat history |
| `/api/tasks` | POST | Submit task to agent swarm |
| `/api/status` | GET | System + Ollama connectivity |
| `/ws` | WebSocket | Real-time state updates |

---

### Titan OS v2

```mermaid
graph TB
    subgraph Electron App
        MW[Main Window]
        IPC[IPC Main]
        PL[Preload Script]
    end
    
    subgraph React Frontend
        APP[App.jsx]
        TERM[TerminalView]
        MEM[MemoryPane]
        FILE[FilePane]
        BROW[BrowserPane]
        SYS[SystemTools]
    end
    
    subgraph Python Backend
        MAIN[main.py - STDIN/STDOUT]
        BOOT[boot_sequence.py]
        FA[file_agent.py]
        MA[memory_agent.py]
        BA[browser_agent.py]
        VA[voice_agent.py]
    end
    
    MW --> IPC
    IPC --> PL
    PL --> APP
    APP --> TERM
    APP --> MEM
    APP --> FILE
    APP --> BROW
    APP --> SYS
    
    IPC -->|JSON Protocol| MAIN
    MAIN --> BOOT
    MAIN --> FA
    MAIN --> MA
    MAIN --> BA
    MAIN --> VA
```

**Key Components:**
- **Electron Main Process** - Window management, Python process spawning
- **React Frontend** - Vite-bundled SPA with panel-based UI
- **Python Backend** - STDIN/STDOUT JSON protocol handler
- **Modular Agents** - File, Memory, Browser, Voice operations
- **IPC Bridge** - Electron IPC for frontend-backend communication

**Current Commands:**
| Command | Agent | Purpose |
|---------|-------|---------|
| `boot` | boot_sequence | Initialize system |
| `save_file`, `read_file`, `list_files` | file_agent | File operations |
| `log_memory`, `get_memory`, `clear_memory` | memory_agent | Memory management |
| `scrape_url`, `summarize` | browser_agent | Web scraping |
| `transcribe_audio` | voice_agent | Speech-to-text |

---

## Integration Strategy

### Recommended Approach: Hybrid Architecture

The recommended integration uses a **WebView-based embedding** with **shared backend services**:

```mermaid
graph TB
    subgraph Electron Shell
        MW[Main Window]
        MENU[Mode Selector Menu]
    end
    
    subgraph Mode: Standard v2
        V2UI[v2 React UI]
        V2BE[v2 Python Backend]
    end
    
    subgraph Mode: Commander Edition
        WV[WebView Panel]
        CE_API[Commander FastAPI :8001]
        OLLAMA[Ollama :11434]
    end
    
    subgraph Shared Services
        SHARED_MEM[Unified Memory]
        SHARED_FILES[Unified File Storage]
    end
    
    MW --> MENU
    MENU -->|Standard| V2UI
    MENU -->|Commander| WV
    V2UI --> V2BE
    WV --> CE_API
    CE_API --> OLLAMA
    V2BE --> SHARED_MEM
    CE_API --> SHARED_MEM
    V2BE --> SHARED_FILES
    CE_API --> SHARED_FILES
```

### Why This Approach?

| Approach | Pros | Cons |
|----------|------|------|
| **WebView Embedding** ✓ | Minimal code changes, clean separation, preserves v1.5 functionality | Separate server process, slight overhead |
| Full Port to v2 Backend | Deep integration, single codebase | Significant rewrite, risk of breaking v1.5 |
| Subprocess IPC | Direct communication | Complex IPC management |

---

## Detailed Implementation Plan

### Phase 1: Project Structure Setup

**1.1 Create Commander Edition Directory**
```
titan_os_v2/
├── backend/
│   ├── core/           # Existing v2 backend
│   └── commander/      # NEW: Commander Edition backend
│       ├── __init__.py
│       ├── titan_os.py      # From v1.5 (modified)
│       ├── titan_llm.py     # From v1.5
│       ├── agents/
│       │   ├── __init__.py
│       │   ├── coordinator.py
│       │   ├── analyzer.py
│       │   ├── executor.py
│       │   ├── researcher.py
│       │   └── optimizer.py
│       ├── templates/
│       │   └── index.html
│       └── static/
│           ├── style.css
│           └── script.js
├── frontend/
│   └── electron/
│       └── renderer/
│           └── src/
│               └── components/
│                   └── CommanderPane.jsx  # NEW: WebView panel
```

**1.2 Dependencies Update**

Add to `backend/requirements.txt`:
```txt
# Commander Edition dependencies
fastapi>=0.104.1
uvicorn[standard]>=0.24.0
websockets>=12.0
openai>=1.0.0
python-dotenv>=1.0.0
jinja2>=3.1.0
aiofiles>=23.0.0
```

---

### Phase 2: Backend Integration

**2.1 Modify Commander Edition for Coexistence**

Changes to `titan_os.py`:

```python
# titan_os_v2/backend/commander/titan_os.py

# Change 1: Configurable port (default 8001 to avoid conflicts)
COMMANDER_PORT = int(os.getenv("COMMANDER_PORT", "8001"))

# Change 2: CORS for Electron WebView
from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow Electron webview
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Change 3: Shared data path with v2
DATA_DIR = Path(os.getenv("TITAN_DATA_PATH", Path.home() / "titan_os" / "data"))

# Change 4: Health check endpoint for main process
@app.get("/api/health")
async def health_check():
    return {"status": "ok", "edition": "commander", "version": "1.5"}
```

**2.2 Commander Process Manager**

Create `backend/core/commander_manager.py`:

```python
"""
Commander Edition Process Manager
Spawns and manages the Commander FastAPI server as a subprocess
"""
import subprocess
import sys
import os
from pathlib import Path

class CommanderManager:
    def __init__(self):
        self.process = None
        self.port = int(os.getenv("COMMANDER_PORT", "8001"))
        
    def start(self):
        commander_path = Path(__file__).parent.parent / "commander" / "titan_os.py"
        self.process = subprocess.Popen(
            [sys.executable, "-m", "uvicorn", 
             "titan_os:app", 
             "--host", "127.0.0.1", 
             "--port", str(self.port)],
            cwd=commander_path.parent,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        return {"status": "started", "port": self.port}
    
    def stop(self):
        if self.process:
            self.process.terminate()
            self.process.wait(timeout=5)
            self.process = None
        return {"status": "stopped"}
    
    def is_running(self):
        return self.process is not None and self.process.poll() is None
```

**2.3 Add Commander Commands to Main Protocol**

Update `backend/core/main.py`:

```python
from commander_manager import CommanderManager

commander = CommanderManager()

COMMAND_HANDLERS = {
    # ... existing handlers ...
    
    # Commander Edition commands
    "commander_start": lambda params: commander.start(),
    "commander_stop": lambda params: commander.stop(),
    "commander_status": lambda params: {
        "status": "success",
        "data": {
            "running": commander.is_running(),
            "port": commander.port,
            "url": f"http://127.0.0.1:{commander.port}"
        }
    },
}
```

---

### Phase 3: Frontend Integration

**3.1 Create Commander Panel Component**

Create `frontend/electron/renderer/src/components/CommanderPane.jsx`:

```jsx
/**
 * Commander Edition Panel
 * Embeds the v1.5 Commander UI in a WebView
 */
import React, { useState, useEffect } from 'react';

function CommanderPane({ onClose }) {
    const [status, setStatus] = useState('loading');
    const [url, setUrl] = useState(null);
    const [error, setError] = useState(null);
    
    useEffect(() => {
        startCommander();
        return () => stopCommander();
    }, []);
    
    const startCommander = async () => {
        try {
            setStatus('starting');
            const response = await window.titanAPI.invoke('commander_start', {});
            if (response.status === 'started') {
                setUrl(`http://127.0.0.1:${response.port}`);
                // Wait for server to be ready
                await waitForServer(response.port);
                setStatus('ready');
            }
        } catch (err) {
            setError(err.message);
            setStatus('error');
        }
    };
    
    const stopCommander = async () => {
        await window.titanAPI.invoke('commander_stop', {});
    };
    
    const waitForServer = async (port, maxAttempts = 20) => {
        for (let i = 0; i < maxAttempts; i++) {
            try {
                const res = await fetch(`http://127.0.0.1:${port}/api/health`);
                if (res.ok) return;
            } catch {}
            await new Promise(r => setTimeout(r, 500));
        }
        throw new Error('Commander server failed to start');
    };
    
    return (
        <div className="commander-pane">
            <div className="commander-header">
                <span className="commander-title">⚔️ COMMANDER EDITION</span>
                <span className={`commander-status ${status}`}>
                    {status === 'ready' ? '● ACTIVE' : '○ ' + status.toUpperCase()}
                </span>
                <button className="commander-close" onClick={onClose}>✕</button>
            </div>
            
            {status === 'ready' && url && (
                <webview 
                    src={url}
                    className="commander-webview"
                    allowpopups="true"
                />
            )}
            
            {status === 'loading' && (
                <div className="commander-loading">
                    <div className="loading-spinner" />
                    <p>Initializing Commander Edition...</p>
                </div>
            )}
            
            {status === 'error' && (
                <div className="commander-error">
                    <p>⚠️ Failed to start Commander Edition</p>
                    <p className="error-detail">{error}</p>
                    <button onClick={startCommander}>Retry</button>
                </div>
            )}
            
            <style jsx>{`
                .commander-pane {
                    display: flex;
                    flex-direction: column;
                    height: 100%;
                    background: #0a0a0a;
                }
                
                .commander-header {
                    display: flex;
                    align-items: center;
                    padding: 8px 12px;
                    background: linear-gradient(135deg, #1a1a2e, #16213e);
                    border-bottom: 1px solid #ffd700;
                }
                
                .commander-title {
                    font-family: 'IBM Plex Mono', monospace;
                    font-size: 12px;
                    color: #ffd700;
                    letter-spacing: 0.1em;
                }
                
                .commander-status {
                    margin-left: auto;
                    margin-right: 12px;
                    font-size: 10px;
                }
                
                .commander-status.ready { color: #6aff89; }
                .commander-status.loading { color: #ffdd66; }
                .commander-status.error { color: #ff7c7c; }
                
                .commander-close {
                    background: transparent;
                    border: none;
                    color: #888;
                    cursor: pointer;
                    font-size: 14px;
                }
                
                .commander-close:hover { color: #fff; }
                
                .commander-webview {
                    flex: 1;
                    width: 100%;
                    border: none;
                }
                
                .commander-loading,
                .commander-error {
                    flex: 1;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    color: #888;
                }
            `}</style>
        </div>
    );
}

export default CommanderPane;
```

**3.2 Add Mode Selector to SystemTools**

Update `frontend/electron/renderer/src/components/SystemTools.jsx`:

```jsx
// Add to imports
import CommanderPane from './CommanderPane';

// Add new state
const [commanderMode, setCommanderMode] = useState(false);

// Add Modes section to the JSX (after PANELS section)
<div className="tools-section">
    <div 
        className="section-header"
        onClick={() => toggleSection('modes')}
    >
        <span className="section-icon">{expanded.modes ? '▼' : '▶'}</span>
        <span className="section-title">EDITIONS</span>
    </div>
    
    {expanded.modes && (
        <div className="section-content">
            <button 
                className={`mode-button ${!commanderMode ? 'active' : ''}`}
                onClick={() => setCommanderMode(false)}
            >
                <span className="mode-icon">⬡</span>
                <span className="mode-label">Standard</span>
                <span className="mode-desc">Core tools & terminal</span>
            </button>
            
            <button 
                className={`mode-button ${commanderMode ? 'active' : ''}`}
                onClick={() => setCommanderMode(true)}
            >
                <span className="mode-icon">⚔️</span>
                <span className="mode-label">Commander</span>
                <span className="mode-desc">AI Agent Swarm</span>
            </button>
        </div>
    )}
</div>
```

**3.3 Update App.jsx for Mode Switching**

```jsx
// Add Commander mode state
const [currentMode, setCurrentMode] = useState('standard'); // 'standard' | 'commander'

// Conditional rendering in main content
<section className="content-center">
    {currentMode === 'standard' && (
        <TerminalView 
            responses={responses}
            systemStatus={systemStatus}
        />
    )}
    {currentMode === 'commander' && (
        <CommanderPane 
            onClose={() => setCurrentMode('standard')}
        />
    )}
</section>
```

---

### Phase 4: Shared Services Integration

**4.1 Unified Memory Bridge**

Create shared memory access between v2's memory_agent and Commander's SharedMemory:

```python
# backend/commander/shared_bridge.py

import json
from pathlib import Path

SHARED_MEMORY_PATH = Path.home() / "titan_os" / "data" / "shared_memory.json"

def sync_to_shared(entries: list):
    """Sync Commander memory entries to shared storage"""
    existing = load_shared()
    existing["commander_entries"] = entries[-100]  # Last 100 entries
    save_shared(existing)

def sync_from_shared() -> dict:
    """Load shared memory from v2"""
    return load_shared().get("v2_entries", [])

def load_shared():
    if SHARED_MEMORY_PATH.exists():
        return json.loads(SHARED_MEMORY_PATH.read_text())
    return {}

def save_shared(data):
    SHARED_MEMORY_PATH.parent.mkdir(parents=True, exist_ok=True)
    SHARED_MEMORY_PATH.write_text(json.dumps(data, indent=2))
```

**4.2 Ollama Health Check in v2**

Add Ollama status to v2's boot sequence:

```python
# backend/core/boot_sequence.py - add to handle_boot()

import aiohttp

async def check_ollama():
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get("http://localhost:11434/api/tags", timeout=2) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return {"available": True, "models": [m["name"] for m in data.get("models", [])]}
    except:
        pass
    return {"available": False, "models": []}
```

---

### Phase 5: Configuration & Settings

**5.1 Environment Configuration**

Create `.env.example`:

```bash
# Commander Edition Settings
COMMANDER_PORT=8001
COMMANDER_AUTO_START=false

# LLM Settings (for Commander Edition)
LLM_BASE_URL=http://localhost:11434/v1
LLM_API_KEY=ollama
LLM_MODEL=phi3:mini

# Shared Storage
TITAN_DATA_PATH=~/.titan_os/data
```

**5.2 Settings Panel (Future)**

Add Commander Edition settings to the UI:
- Toggle auto-start on boot
- Configure default LLM model
- Set performance mode (FAST/BALANCED/QUALITY)
- View Ollama connection status

---

## File Changes Summary

### New Files to Create

| File | Purpose |
|------|---------|
| `backend/commander/` | Entire Commander Edition backend (copy from v1.5) |
| `backend/core/commander_manager.py` | Process manager for Commander |
| `frontend/.../CommanderPane.jsx` | WebView panel component |
| `docs/COMMANDER_EDITION.md` | User documentation |

### Files to Modify

| File | Changes |
|------|---------|
| `backend/core/main.py` | Add commander_* commands |
| `backend/requirements.txt` | Add Commander dependencies |
| `frontend/.../App.jsx` | Add mode switching logic |
| `frontend/.../SystemTools.jsx` | Add Editions section |
| `frontend/electron/main.js` | Add webview permissions |

---

## Implementation Checklist

### Phase 1: Setup (Day 1)
- [ ] Create `backend/commander/` directory structure
- [ ] Copy v1.5 files with modifications
- [ ] Update requirements.txt
- [ ] Test Commander standalone on port 8001

### Phase 2: Backend Integration (Day 2)
- [ ] Implement CommanderManager class
- [ ] Add commander commands to main.py
- [ ] Test start/stop/status commands
- [ ] Verify process isolation

### Phase 3: Frontend Integration (Day 2-3)
- [ ] Create CommanderPane.jsx component
- [ ] Add Editions section to SystemTools
- [ ] Implement mode switching in App.jsx
- [ ] Enable webview in Electron config
- [ ] Style to match v2 aesthetic

### Phase 4: Testing (Day 3-4)
- [ ] Test Commander start/stop lifecycle
- [ ] Verify WebSocket connections through WebView
- [ ] Test LLM functionality with Ollama
- [ ] Cross-platform testing (Windows/Mac/Linux)

### Phase 5: Polish (Day 4-5)
- [ ] Add loading states and error handling
- [ ] Implement graceful shutdown
- [ ] Add settings persistence
- [ ] Update documentation

---

## Potential Challenges & Solutions

### Challenge 1: WebView Security
**Issue:** Electron's webview requires explicit permissions.
**Solution:** Add to `main.js`:
```javascript
webPreferences: {
    webviewTag: true,
    nodeIntegration: false,
    contextIsolation: true
}
```

### Challenge 2: Port Conflicts
**Issue:** Port 8001 might be in use.
**Solution:** Implement dynamic port allocation:
```python
import socket
def find_free_port():
    with socket.socket() as s:
        s.bind(('', 0))
        return s.getsockname()[1]
```

### Challenge 3: Ollama Not Installed
**Issue:** Users may not have Ollama installed.
**Solution:** 
- Add graceful degradation with clear error messages
- Provide one-click Ollama installer link
- Show "Install Ollama" prompt on first launch

### Challenge 4: Resource Usage
**Issue:** Running two Python backends may use memory.
**Solution:**
- Lazy-load Commander only when activated
- Stop Commander backend when switching back to Standard mode
- Add memory usage monitoring to status display

### Challenge 5: Shared State Sync
**Issue:** Memory/files may conflict between editions.
**Solution:**
- Use namespaced storage (v2/* vs commander/*)
- Implement sync points at mode switch
- Add conflict resolution UI

---

## Future Enhancements

### v2.1 - Deep Integration
- Port Commander agents to native v2 backend commands
- Unified chat interface that can switch between standard and AI modes
- Shared agent pool across both editions

### v2.2 - Enhanced AI Features
- Add more LLM providers (OpenAI, Anthropic, local models)
- Implement agent customization UI
- Add prompt template editor

### v2.3 - Workflow Automation
- Enable agent chains (v2 commands triggered by Commander)
- Create saved workflows
- Add scheduling for recurring agent tasks

---

## Appendix: API Reference

### Commander Edition API (Port 8001)

| Endpoint | Method | Description |
|----------|--------|-------------|
| `GET /` | GET | Commander UI |
| `GET /api/health` | GET | Health check |
| `GET /api/agents` | GET | List agents |
| `GET /api/chat` | GET | Chat history |
| `POST /api/tasks` | POST | Submit task |
| `GET /api/status` | GET | System status |
| `WS /ws` | WebSocket | Real-time updates |

### v2 Commander Commands

| Command | Params | Response |
|---------|--------|----------|
| `commander_start` | `{}` | `{status: "started", port: 8001}` |
| `commander_stop` | `{}` | `{status: "stopped"}` |
| `commander_status` | `{}` | `{running: bool, port: int, url: string}` |

---

*Document Version: 1.0*
*Last Updated: 2024*
*Author: Titan OS Architecture Team*