# TitanU OS Frontend: Demo Mode Integration Architecture

## Executive Summary

This document provides a comprehensive analysis of the TitanU OS frontend architecture and outlines a minimally invasive strategy for integrating a cinematic demo mode.

---

## 1. Current Architecture Overview

### 1.1 Application Structure

```
frontend/electron/renderer/src/
├── App.jsx                    # Root component, mode switching, panel management
├── main.jsx                   # React entry point
├── components/
│   ├── UnifiedWorkspace.jsx   # Main terminal view (STANDARD mode)
│   ├── CommanderPane.jsx      # Commander edition UI (COMMANDER mode)
│   ├── InputBar.jsx           # Command input with suggestions
│   ├── UnifiedMessage.jsx     # Message rendering
│   ├── BootSequence.jsx       # Boot animation
│   ├── SystemTools.jsx        # Left sidebar tools
│   ├── MemoryPane.jsx         # Memory panel
│   ├── FilePane.jsx           # File browser panel
│   ├── BrowserPane.jsx        # Browser panel
│   └── VoiceButton.jsx        # Voice input control
├── styles/
│   └── global.css             # Commander Edition design system
└── utils/
    └── ipc.js                 # Electron IPC communication
```

### 1.2 Component Hierarchy

```mermaid
graph TD
    A[App.jsx] --> B[BootSequence]
    A --> C[UnifiedWorkspace]
    A --> D[CommanderPane]
    A --> E[SystemTools]
    A --> F[Sidebar Panels]
    
    C --> G[WelcomeBanner]
    C --> H[UnifiedMessage list]
    C --> I[InputBar]
    
    I --> J[VoiceButton]
    
    F --> K[MemoryPane]
    F --> L[FilePane]
    F --> M[BrowserPane]
```

---

## 2. State Management Analysis

### 2.1 Approach
**Pattern:** Local `useState` hooks (no external state management library)

### 2.2 State Locations

#### App.jsx (Root Level)
```javascript
const [isBooting, setIsBooting] = useState(true);           // Boot sequence active
const [isAppReady, setIsAppReady] = useState(false);        // App ready for interaction
const [systemStatus, setSystemStatus] = useState({...});    // Backend status
const [activePanels, setActivePanels] = useState({...});    // Panel visibility
const [responses, setResponses] = useState([]);              // Backend responses
const [currentMode, setCurrentMode] = useState(MODES.STANDARD); // STANDARD|COMMANDER
```

#### UnifiedWorkspace.jsx (Terminal State)
```javascript
const [messages, setMessages] = useState([]);               // Chat/terminal messages
const [commandHistory, setCommandHistory] = useState([]);   // Command history
const [showBanner, setShowBanner] = useState(true);         // Welcome banner visibility
```

#### InputBar.jsx (Input State)
```javascript
const [input, setInput] = useState('');                     // Current input text
const [showSuggestions, setShowSuggestions] = useState(false);
const [filteredCommands, setFilteredCommands] = useState([]);
const [selectedSuggestion, setSelectedSuggestion] = useState(0);
const [historyIndex, setHistoryIndex] = useState(-1);
```

### 2.3 State Flow Diagram

```mermaid
graph LR
    subgraph App.jsx
        A1[responses]
        A2[currentMode]
        A3[systemStatus]
    end
    
    subgraph UnifiedWorkspace.jsx
        U1[messages]
        U2[commandHistory]
    end
    
    subgraph InputBar.jsx
        I1[input]
    end
    
    A1 -->|props| U1
    I1 -->|onSubmit callback| U1
    U1 -->|executeCommand| Backend
    Backend -->|titanAPI.onResponse| A1
```

---

## 3. Message Flow Analysis

### 3.1 Message Injection Points

#### Primary: `setMessages()` in UnifiedWorkspace.jsx

**Location:** [`UnifiedWorkspace.jsx:97`](../frontend/electron/renderer/src/components/UnifiedWorkspace.jsx:97)

```javascript
setMessages(prev => [...prev, newMessage]);
```

**Message Structure:**
```javascript
{
    id: string,           // Unique ID: `msg-${Date.now()}-${counter}`
    type: string,         // 'user-command' | 'system-response' | 'llm-response' | 'info' | 'error'
    content: string,      // Message text
    timestamp: Date,      // JavaScript Date object
    status?: string       // 'success' | 'error' | undefined
}
```

### 3.2 Message Types

| Type | Source | Visual Style |
|------|--------|--------------|
| `user-command` | User input | Cyan prompt style |
| `system-response` | Backend response | Mint terminal style |
| `llm-response` | AI response | Full-width AI bubble |
| `info` | System info | Yellow info indicator |
| `error` | Error state | Red error styling |

### 3.3 Command Processing Flow

```mermaid
sequenceDiagram
    participant User
    participant InputBar
    participant UnifiedWorkspace
    participant Backend
    
    User->>InputBar: Types command
    InputBar->>InputBar: handleSubmit()
    InputBar->>UnifiedWorkspace: onSubmit(command)
    UnifiedWorkspace->>UnifiedWorkspace: executeCommand(command)
    UnifiedWorkspace->>UnifiedWorkspace: setMessages(userMessage)
    UnifiedWorkspace->>Backend: sendCommand(cmd, params)
    Backend->>App: titanAPI.onResponse()
    App->>App: setResponses([...prev, response])
    App->>UnifiedWorkspace: responses prop
    UnifiedWorkspace->>UnifiedWorkspace: useEffect detects new response
    UnifiedWorkspace->>UnifiedWorkspace: setMessages(systemMessage)
```

---

## 4. Commander Mode Activation

### 4.1 Mode Switching Mechanism

**Location:** [`App.jsx:100`](../frontend/electron/renderer/src/App.jsx:100)

```javascript
const switchMode = (mode) => {
    setCurrentMode(mode);
    setSystemStatus(prev => ({
        ...prev,
        message: mode === MODES.COMMANDER
            ? 'Commander Edition Active'
            : prev.online ? 'Ready' : 'Initializing...'
    }));
};
```

### 4.2 Mode Constants

```javascript
const MODES = {
    STANDARD: 'standard',
    COMMANDER: 'commander'
};
```

### 4.3 Trigger Points

1. **SystemTools component** - "COMMANDER" button
2. **CommanderPane onClose** - Returns to STANDARD mode

### 4.4 Mode-Dependent Rendering

```javascript
{currentMode === MODES.STANDARD && <UnifiedWorkspace ... />}
{currentMode === MODES.COMMANDER && <CommanderPane ... />}
```

---

## 5. Input Handling Analysis

### 5.1 InputBar Component

**Props Interface:**
```javascript
{
    onSubmit: (command: string) => void,  // Submit handler
    onHistoryNav: (direction, index) => void,  // History navigation
    commandHistory: string[]  // Previous commands
}
```

### 5.2 Submit Flow

**Location:** [`InputBar.jsx:61`](../frontend/electron/renderer/src/components/InputBar.jsx:61)

```javascript
const handleSubmit = () => {
    const trimmed = input.trim();
    if (!trimmed) return;
    // ... suggestion handling ...
    onSubmit(trimmed);  // ← Calls UnifiedWorkspace.executeCommand
    setInput('');
};
```

### 5.3 Keyboard Handling

- **Enter** → Submit
- **ArrowUp/Down** → History navigation (no suggestions)
- **ArrowUp/Down** → Suggestion navigation (with suggestions)
- **Tab** → Complete suggestion
- **Escape** → Close suggestions

---

## 6. Integration Points for Demo Mode

### 6.1 Recommended Integration Points

| Priority | Location | Purpose | Invasiveness |
|----------|----------|---------|--------------|
| **1** | `UnifiedWorkspace.jsx` | Inject demo messages, intercept commands | Low |
| **2** | `App.jsx` | Add demoModeActive flag, expose demo controls | Low |
| **3** | `InputBar.jsx` | Auto-type simulation | Medium |
| **4** | `global.css` | Demo-specific overlays/badges | Low |

### 6.2 Detailed Integration Strategy

#### 6.2.1 App.jsx Modifications (Minimal)

**Add state:**
```javascript
const [demoModeActive, setDemoModeActive] = useState(false);
```

**Pass to UnifiedWorkspace:**
```javascript
<UnifiedWorkspace
    responses={responses}
    systemStatus={systemStatus}
    demoModeActive={demoModeActive}
    onDemoControl={setDemoModeActive}
/>
```

#### 6.2.2 UnifiedWorkspace.jsx Integration

**Wrap executeCommand:**
```javascript
const executeCommand = async (commandStr) => {
    if (demoModeActive && demoController) {
        // Let demo controller handle the command
        return demoController.handleCommand(commandStr);
    }
    // ... existing logic ...
};
```

**Add demo message injection:**
```javascript
// Expose message injection for demo scripts
const injectMessage = (message) => {
    setMessages(prev => [...prev, {
        ...message,
        id: generateId()
    }]);
};
```

#### 6.2.3 Demo Script Architecture

**Location:** `/demoScripts/` (new directory)

```
demoScripts/
├── index.js              # Demo controller
├── scenarios/
│   ├── welcome.js        # Welcome demo
│   ├── fileOps.js        # File operations demo
│   └── aiChat.js         # AI conversation demo
└── utils/
    ├── typewriter.js     # Typing animation
    └── delays.js         # Timing utilities
```

---

## 7. Recommended Integration Strategy

### 7.1 Design Principles

1. **Single Flag Control:** All demo behavior controlled by `demoModeActive`
2. **Separation of Concerns:** Demo logic isolated in `/demoScripts/`
3. **Non-Invasive Hooks:** Wrap existing handlers, don't modify them
4. **Graceful Degradation:** Demo mode can be interrupted without breaking app

### 7.2 Implementation Architecture

```mermaid
graph TD
    subgraph "Existing Code (Unchanged)"
        A[App.jsx]
        B[UnifiedWorkspace.jsx]
        C[InputBar.jsx]
    end
    
    subgraph "New Demo Layer"
        D[DemoProvider Context]
        E[useDemoMode Hook]
        F[demoScripts/controller.js]
        G[Scenario Scripts]
    end
    
    A -.->|demoModeActive prop| D
    D -->|injectMessage| B
    D -->|simulateInput| C
    E -->|controls| F
    F -->|executes| G
```

### 7.3 Non-Invasive Hook Points

#### A. Message Injection Hook
```javascript
// In UnifiedWorkspace.jsx, add after existing useEffect
useEffect(() => {
    if (!demoModeActive || !demoController) return;
    
    demoController.setMessageInjector(injectMessage);
    demoController.setCommandExecutor(executeCommand);
    
    return () => demoController.cleanup();
}, [demoModeActive]);
```

#### B. Input Simulation Hook
```javascript
// In InputBar.jsx, add ref exposure
useImperativeHandle(ref, () => ({
    simulateType: async (text, speed = 50) => {
        for (const char of text) {
            setInput(prev => prev + char);
            await delay(speed);
        }
    },
    simulateSubmit: () => handleSubmit()
}));
```

### 7.4 Demo Controller Interface

```javascript
// demoScripts/controller.js
class DemoController {
    setMessageInjector(fn) {}
    setCommandExecutor(fn) {}
    setInputSimulator(fn) {}
    
    async runScenario(scenarioName) {}
    pause() {}
    resume() {}
    stop() {}
    
    // Message injection
    async showUserMessage(text) {}
    async showAIResponse(text, typingSpeed) {}
    async showSystemMessage(text, type) {}
    
    // Input simulation
    async typeInput(text, speed) {}
    async submitInput() {}
}
```

---

## 8. File Modification Summary

### 8.1 Files to Modify (Minimal)

| File | Changes | Lines Affected |
|------|---------|----------------|
| `App.jsx` | Add demoModeActive state, pass props | ~5 lines |
| `UnifiedWorkspace.jsx` | Add demo hook integration | ~15 lines |
| `InputBar.jsx` | Add ref forwarding (optional) | ~10 lines |

### 8.2 Files to Create

| File | Purpose |
|------|---------|
| `demoScripts/index.js` | Main demo controller export |
| `demoScripts/DemoController.js` | Controller class |
| `demoScripts/scenarios/*.js` | Individual demo scenarios |
| `demoScripts/utils/*.js` | Helper utilities |
| `components/DemoOverlay.jsx` | Demo controls UI (optional) |

---

## 9. Risk Assessment

### 9.1 Low Risk
- Demo mode is purely additive
- Core logic remains unchanged
- Single boolean flag controls all demo behavior
- Demo scripts are isolated

### 9.2 Considerations
- InputBar ref forwarding may require `forwardRef`
- Demo timing must account for async operations
- Commander mode should disable demo mode automatically

---

## 10. Next Steps

1. **Phase 1:** Add `demoModeActive` state to App.jsx (~5 minutes)
2. **Phase 2:** Create `/demoScripts/` structure (~30 minutes)
3. **Phase 3:** Implement message injection in UnifiedWorkspace (~15 minutes)
4. **Phase 4:** Create first demo scenario (~1 hour)
5. **Phase 5:** Add optional demo controls UI (~30 minutes)

---

*Document created: November 26, 2025*
*Analysis performed on TitanU OS Commander Edition frontend*