"""
Titan OS Pro - License Management
Validates and manages Pro licenses
"""
import os
import json
import hashlib
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, Any

# License file location
LICENSE_FILE = Path(__file__).parent.parent.parent / "backend" / "titan_data" / "pro_license.json"

class ProLicense:
    def __init__(self):
        self.license_key: Optional[str] = None
        self.activated: bool = False
        self.expires: Optional[str] = None
        self.features: Dict[str, bool] = {}
        self.tier: str = "free"  # free, pro, enterprise
        
    def load(self) -> bool:
        """Load license from file"""
        if not LICENSE_FILE.exists():
            return False
        
        try:
            data = json.loads(LICENSE_FILE.read_text())
            self.license_key = data.get("license_key")
            self.activated = data.get("activated", False)
            self.expires = data.get("expires")
            self.features = data.get("features", {})
            self.tier = data.get("tier", "free")
            return self.activated
        except Exception:
            return False
    
    def save(self) -> bool:
        """Save license to file"""
        try:
            LICENSE_FILE.parent.mkdir(parents=True, exist_ok=True)
            data = {
                "license_key": self.license_key,
                "activated": self.activated,
                "expires": self.expires,
                "features": self.features,
                "tier": self.tier,
                "last_validated": datetime.now().isoformat()
            }
            LICENSE_FILE.write_text(json.dumps(data, indent=2))
            return True
        except Exception:
            return False
    
    def validate_key(self, key: str) -> bool:
        """
        Validate a license key.
        
        In production, this would:
        1. Check key format
        2. Verify with license server
        3. Check expiration
        4. Validate hardware fingerprint
        """
        # Placeholder validation
        # Real implementation would contact license server
        if not key:
            return False
        
        # Check key format (example: TITAN-PRO-XXXX-XXXX-XXXX)
        if not key.startswith("TITAN-"):
            return False
        
        parts = key.split("-")
        if len(parts) != 5:
            return False
        
        return True
    
    def get_hardware_id(self) -> str:
        """Generate unique hardware identifier"""
        import platform
        import uuid
        
        components = [
            platform.node(),
            platform.machine(),
            str(uuid.getnode())
        ]
        combined = "-".join(components)
        return hashlib.sha256(combined.encode()).hexdigest()[:16]

# Global license instance
_license = ProLicense()

def check_license() -> bool:
    """Check if Pro license is valid"""
    return _license.load() and _license.activated

def activate_pro(license_key: str) -> Dict[str, Any]:
    """
    Activate Pro features with a license key.
    
    Returns:
        {"success": bool, "message": str, "features": dict}
    """
    if not license_key:
        return {"success": False, "message": "No license key provided", "features": {}}
    
    if not _license.validate_key(license_key):
        return {"success": False, "message": "Invalid license key format", "features": {}}
    
    # TODO: Verify with license server
    # This is scaffolding - real implementation would contact server
    
    _license.license_key = license_key
    _license.activated = True
    _license.tier = "pro"
    _license.features = {
        "hardware_acceleration": True,
        "enterprise_encryption": True,
        "advanced_browser": True,
        "cloud_llm": True,
        "wake_word": True,
        "analytics": True
    }
    _license.save()
    
    return {
        "success": True,
        "message": "Pro features activated!",
        "features": _license.features,
        "tier": _license.tier
    }

def deactivate_pro() -> Dict[str, Any]:
    """Deactivate Pro features"""
    _license.activated = False
    _license.tier = "free"
    _license.features = {}
    _license.save()
    
    return {"success": True, "message": "Pro features deactivated"}

def get_license_info() -> Dict[str, Any]:
    """Get current license information"""
    _license.load()
    return {
        "activated": _license.activated,
        "tier": _license.tier,
        "features": _license.features,
        "expires": _license.expires,
        "hardware_id": _license.get_hardware_id()
    }