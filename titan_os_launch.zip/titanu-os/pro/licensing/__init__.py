"""Pro licensing module"""
from .license import check_license, activate_pro, deactivate_pro