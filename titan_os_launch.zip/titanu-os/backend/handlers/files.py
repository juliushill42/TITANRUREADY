import os
import shutil
from pathlib import Path
from datetime import datetime
from typing import Optional
import base64

# Base directory for file operations (sandboxed)
TITAN_DATA_DIR = Path(__file__).parent.parent / "titan_data"
UPLOADS_DIR = TITAN_DATA_DIR / "uploads"
WORKSPACE_DIR = TITAN_DATA_DIR / "workspace"
FILES_DIR = TITAN_DATA_DIR / "files"

# Allowed file extensions for uploads
ALLOWED_EXTENSIONS = [
    '.txt', '.md', '.json', '.csv', '.xml', '.yaml', '.yml',
    '.py', '.js', '.jsx', '.ts', '.tsx', '.html', '.css',
    '.java', '.c', '.cpp', '.h', '.go', '.rs', '.rb',
    '.pdf', '.doc', '.docx', '.xls', '.xlsx',
    '.png', '.jpg', '.jpeg', '.gif', '.svg', '.webp',
    '.zip', '.tar', '.gz'
]

MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB

# Ensure directories exist
def ensure_dirs():
    TITAN_DATA_DIR.mkdir(parents=True, exist_ok=True)
    UPLOADS_DIR.mkdir(parents=True, exist_ok=True)
    WORKSPACE_DIR.mkdir(parents=True, exist_ok=True)
    FILES_DIR.mkdir(parents=True, exist_ok=True)

ensure_dirs()

def handle_files(action: str, params: dict) -> dict:
    """Handle all file operations."""
    try:
        if action == "list":
            return list_files(params.get("path", str(TITAN_DATA_DIR)))
        elif action == "read":
            return read_file(params.get("path"))
        elif action == "write":
            return write_file(params.get("path"), params.get("content", ""))
        elif action == "delete":
            return delete_file(params.get("path"))
        elif action == "upload":
            return handle_upload(params.get("filename"), params.get("content"))
        elif action == "search":
            return search_files(params.get("query", ""))
        elif action == "mkdir":
            return make_directory(params.get("path"))
        else:
            return {"success": False, "error": f"Unknown action: {action}"}
    except Exception as e:
        return {"success": False, "error": str(e)}

def list_files(path: str = None) -> dict:
    """List files in a directory."""
    if path is None:
        target = TITAN_DATA_DIR
    else:
        target = Path(path).resolve()
    
    # Security: Ensure path is within allowed directories
    allowed_roots = [TITAN_DATA_DIR.resolve(), Path.home().resolve()]
    
    if not any(str(target).startswith(str(root)) for root in allowed_roots):
        return {"success": False, "error": "Access denied: Path outside allowed directories"}
    
    if not target.exists():
        # Create the directory if it doesn't exist
        target.mkdir(parents=True, exist_ok=True)
    
    if not target.is_dir():
        return {"success": False, "error": f"Not a directory: {path}"}
    
    items = []
    try:
        for entry in target.iterdir():
            # Skip hidden files
            if entry.name.startswith('.'):
                continue
            
            stat = entry.stat()
            items.append({
                "name": entry.name,
                "path": str(entry),
                "is_dir": entry.is_dir(),
                "size": stat.st_size if entry.is_file() else 0,
                "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                "extension": entry.suffix.lower() if entry.is_file() else None
            })
        
        # Sort: directories first, then by name
        items.sort(key=lambda x: (not x["is_dir"], x["name"].lower()))
        
        return {
            "success": True,
            "path": str(target),
            "parent": str(target.parent) if target != target.parent else None,
            "files": items,
            "count": len(items)
        }
    
    except PermissionError:
        return {"success": False, "error": "Permission denied"}

def read_file(path: str) -> dict:
    """Read file contents."""
    if not path:
        return {"success": False, "error": "Path required"}
    
    target = Path(path)
    
    if not target.exists():
        return {"success": False, "error": "File not found"}
    
    if not target.is_file():
        return {"success": False, "error": "Not a file"}
    
    # Check file size (limit to 10MB for text)
    if target.stat().st_size > 10 * 1024 * 1024:
        return {"success": False, "error": "File too large (max 10MB)"}
    
    try:
        content = target.read_text(encoding='utf-8')
        return {
            "success": True,
            "path": str(target),
            "content": content,
            "size": len(content),
            "lines": content.count('\n') + 1
        }
    except UnicodeDecodeError:
        return {"success": False, "error": "Binary file - cannot read as text"}

def write_file(path: str, content: str) -> dict:
    """Write content to file."""
    if not path:
        return {"success": False, "error": "Path required"}
    
    target = Path(path)
    
    # Security: Only allow writing within titan_data
    if not str(target.resolve()).startswith(str(TITAN_DATA_DIR.resolve())):
        return {"success": False, "error": "Can only write to titan_data directory"}
    
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding='utf-8')
        return {
            "success": True,
            "path": str(target),
            "size": len(content)
        }
    except Exception as e:
        return {"success": False, "error": str(e)}

def delete_file(path: str) -> dict:
    """Delete a file or directory."""
    if not path:
        return {"success": False, "error": "Path required"}
    
    target = Path(path)
    
    # Security: Only allow deleting within titan_data
    if not str(target.resolve()).startswith(str(TITAN_DATA_DIR.resolve())):
        return {"success": False, "error": "Can only delete from titan_data directory"}
    
    if not target.exists():
        return {"success": False, "error": "File not found"}
    
    try:
        if target.is_dir():
            shutil.rmtree(target)
        else:
            target.unlink()
        return {"success": True, "deleted": str(target)}
    except Exception as e:
        return {"success": False, "error": str(e)}

def handle_upload(filename: str, content: str, content_type: str = None) -> dict:
    """
    Handle file upload with base64 encoded content.
    
    Args:
        filename: Original filename
        content: Base64 encoded file content
        content_type: MIME type (optional)
    
    Returns:
        Dict with success status and file info or error
    """
    if not filename:
        return {"success": False, "error": "Filename required"}
    if not content:
        return {"success": False, "error": "Content required"}
    
    # Check extension
    ext = Path(filename).suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        return {
            "success": False,
            "error": f"File type not allowed: {ext}. Allowed: {', '.join(ALLOWED_EXTENSIONS[:10])}..."
        }
    
    try:
        # Decode base64 content
        file_bytes = base64.b64decode(content)
        
        # Check size
        if len(file_bytes) > MAX_FILE_SIZE:
            return {
                "success": False,
                "error": f"File too large. Max size: {MAX_FILE_SIZE // (1024*1024)}MB"
            }
        
        # Sanitize filename (remove path traversal attempts)
        safe_filename = Path(filename).name
        
        # Ensure unique filename if exists
        target = UPLOADS_DIR / safe_filename
        if target.exists():
            stem = target.stem
            suffix = target.suffix
            counter = 1
            while target.exists():
                target = UPLOADS_DIR / f"{stem}_{counter}{suffix}"
                counter += 1
        
        # Write file
        target.write_bytes(file_bytes)
        
        return {
            "success": True,
            "filename": target.name,
            "path": str(target),
            "size": len(file_bytes),
            "extension": ext,
            "message": f"File '{target.name}' uploaded successfully"
        }
    
    except Exception as e:
        return {"success": False, "error": f"Upload failed: {str(e)}"}

def search_files(query: str, path: str = None) -> dict:
    """Search for files by name."""
    search_root = Path(path) if path else TITAN_DATA_DIR
    
    results = []
    query_lower = query.lower()
    
    try:
        for file_path in search_root.rglob("*"):
            if query_lower in file_path.name.lower():
                results.append({
                    "name": file_path.name,
                    "path": str(file_path),
                    "is_dir": file_path.is_dir()
                })
            
            if len(results) >= 50:  # Limit results
                break
    except Exception:
        pass
    
    return {
        "success": True,
        "query": query,
        "results": results,
        "count": len(results)
    }

def make_directory(path: str) -> dict:
    """Create a new directory."""
    if not path:
        return {"success": False, "error": "Path required"}
    
    target = Path(path)
    
    # Security: Only allow within titan_data
    if not str(target.resolve()).startswith(str(TITAN_DATA_DIR.resolve())):
        return {"success": False, "error": "Can only create directories in titan_data"}
    
    try:
        target.mkdir(parents=True, exist_ok=True)
        return {"success": True, "path": str(target)}
    except Exception as e:
        return {"success": False, "error": str(e)}