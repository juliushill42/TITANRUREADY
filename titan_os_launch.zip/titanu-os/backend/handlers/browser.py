"""
TitanU Browser Handler - Secure Quarantined Web Access
======================================================
Security Principles:
- No cookie persistence
- No local storage access
- Block localhost, private IPs
- Strip scripts, tracking pixels, iframes
- Timeout: 30 seconds max
- Size limit: 5MB max
- Complete quarantine from TITAN data
"""

import re
from urllib.parse import urlparse, quote_plus
from datetime import datetime
import hashlib
import urllib.request
import urllib.error
import ssl

BROWSER_CONFIG = {
    "timeout": 30,
    "max_size": 5 * 1024 * 1024,  # 5MB
    "user_agent": "TitanU-Browser/2.5 (Secure; Quarantined)",
    "allowed_schemes": ["http", "https"],
    "blocked_domains": [
        "localhost", "127.0.0.1", "0.0.0.0", "192.168.", "10.", 
        "172.16.", "172.17.", "172.18.", "172.19.", "172.20.",
        "172.21.", "172.22.", "172.23.", "172.24.", "172.25.",
        "172.26.", "172.27.", "172.28.", "172.29.", "172.30.", "172.31.",
        ".local", "169.254.",
    ],
}

# Request log for auditing (in-memory only, no persistence)
REQUEST_LOG = []


def is_url_allowed(url):
    """
    Validate URL against security rules.
    Blocks private IPs, localhost, and non-http(s) schemes.
    """
    try:
        parsed = urlparse(url)
        
        # Check scheme
        if parsed.scheme not in BROWSER_CONFIG["allowed_schemes"]:
            return False, f"Scheme not allowed: {parsed.scheme}"
        
        # Check for valid host
        if not parsed.netloc:
            return False, "Invalid URL: no host"
        
        # Extract domain without port
        domain = parsed.netloc.lower().split(":")[0]
        
        # Check against blocked domains
        for blocked in BROWSER_CONFIG["blocked_domains"]:
            if blocked.startswith("."):
                # Suffix match for TLDs like .local
                if domain.endswith(blocked) or domain == blocked[1:]:
                    return False, f"Domain blocked: {domain}"
            elif domain == blocked or domain.startswith(blocked):
                return False, f"Domain blocked: {domain}"
        
        return True, "OK"
    except Exception as e:
        return False, f"Invalid URL: {str(e)}"


def sanitize_html(html):
    """
    Remove potentially dangerous HTML elements.
    Strips scripts, styles, iframes, objects, embeds, and event handlers.
    """
    if not html:
        return ""
    
    # Remove script tags and content
    html = re.sub(r'<script[^>]*>.*?</script>', '', html, flags=re.DOTALL | re.IGNORECASE)
    
    # Remove style tags and content
    html = re.sub(r'<style[^>]*>.*?</style>', '', html, flags=re.DOTALL | re.IGNORECASE)
    
    # Remove event handlers (onclick, onload, etc.)
    html = re.sub(r'\s+on\w+\s*=\s*["\'][^"\']*["\']', '', html, flags=re.IGNORECASE)
    
    # Remove javascript: URLs
    html = re.sub(r'href\s*=\s*["\']javascript:[^"\']*["\']', 'href="#"', html, flags=re.IGNORECASE)
    
    # Remove iframes
    html = re.sub(r'<iframe[^>]*>.*?</iframe>', '', html, flags=re.DOTALL | re.IGNORECASE)
    
    # Remove object tags
    html = re.sub(r'<object[^>]*>.*?</object>', '', html, flags=re.DOTALL | re.IGNORECASE)
    
    # Remove embed tags
    html = re.sub(r'<embed[^>]*/?>', '', html, flags=re.IGNORECASE)
    
    # Remove tracking pixels (1x1 images)
    html = re.sub(r'<img[^>]*(?:width|height)\s*=\s*["\']?1["\']?[^>]*(?:width|height)\s*=\s*["\']?1["\']?[^>]*/?\s*>', '', html, flags=re.IGNORECASE)
    
    # Remove base64 embedded content (potential malicious payloads)
    html = re.sub(r'src\s*=\s*["\']data:[^"\']*["\']', 'src=""', html, flags=re.IGNORECASE)
    
    return html


def extract_text(html):
    """
    Extract readable text content from HTML.
    Removes all tags and normalizes whitespace.
    """
    if not html:
        return ""
    
    # First sanitize
    html = sanitize_html(html)
    
    # Remove all HTML tags
    text = re.sub(r'<[^>]+>', ' ', html)
    
    # Normalize whitespace
    text = re.sub(r'\s+', ' ', text)
    
    # Decode common HTML entities
    entities = {
        '&nbsp;': ' ',
        '&amp;': '&',
        '&lt;': '<',
        '&gt;': '>',
        '&quot;': '"',
        '&#39;': "'",
        '&apos;': "'",
        '&ndash;': '-',
        '&mdash;': '--',
        '&copy;': '©',
        '&reg;': '®',
        '&trade;': '™',
    }
    for ent, char in entities.items():
        text = text.replace(ent, char)
    
    return text.strip()


def fetch_url_sync(url, extract_text_content=True):
    """
    Fetch URL content with security measures.
    - No cookies stored
    - Content sanitized
    - Size limited
    - Timeout enforced
    """
    # Generate request ID for tracking
    request_id = hashlib.md5(f"{url}{datetime.now().isoformat()}".encode()).hexdigest()[:8]
    
    # Validate URL
    allowed, reason = is_url_allowed(url)
    if not allowed:
        return {
            "success": False,
            "error": f"URL blocked: {reason}",
            "request_id": request_id,
            "quarantined": True
        }
    
    try:
        # Prepare request headers (no cookies)
        headers = {
            "User-Agent": BROWSER_CONFIG["user_agent"],
            "DNT": "1",  # Do Not Track
            "Accept": "text/html,application/json,text/plain,*/*",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
        }
        
        req = urllib.request.Request(url, headers=headers)
        
        # Create SSL context (verify certificates)
        ctx = ssl.create_default_context()
        
        with urllib.request.urlopen(req, timeout=BROWSER_CONFIG["timeout"], context=ctx) as response:
            # Check content length before reading
            content_length = response.headers.get('Content-Length', 0)
            if int(content_length or 0) > BROWSER_CONFIG["max_size"]:
                return {
                    "success": False,
                    "error": "Content exceeds 5MB limit",
                    "request_id": request_id,
                    "quarantined": True
                }
            
            # Read content with size limit
            content = response.read()
            if len(content) > BROWSER_CONFIG["max_size"]:
                return {
                    "success": False,
                    "error": "Content exceeds 5MB limit",
                    "request_id": request_id,
                    "quarantined": True
                }
            
            # Decode content
            charset = response.headers.get_content_charset() or 'utf-8'
            try:
                content_str = content.decode(charset)
            except:
                content_str = content.decode('utf-8', errors='replace')
            
            # Get content type
            content_type = response.headers.get('Content-Type', '')
            
            # Process based on content type
            if 'text/html' in content_type:
                sanitized = sanitize_html(content_str)
                if extract_text_content:
                    text_content = extract_text(sanitized)
                else:
                    text_content = sanitized
            else:
                text_content = content_str
            
            # Log request (in-memory only)
            REQUEST_LOG.append({
                "id": request_id,
                "url": url,
                "status": "success",
                "timestamp": datetime.now().isoformat()
            })
            
            # Keep log size bounded
            if len(REQUEST_LOG) > 100:
                REQUEST_LOG.pop(0)
            
            return {
                "success": True,
                "request_id": request_id,
                "url": response.url,  # Final URL after redirects
                "status_code": response.status,
                "content_type": content_type,
                "content": text_content[:50000],  # Limit content in response
                "size": len(content),
                "quarantined": True,
                "security": {
                    "cookies": "disabled",
                    "scripts": "removed",
                    "tracking": "blocked",
                    "iframes": "removed"
                }
            }
            
    except urllib.error.HTTPError as e:
        return {
            "success": False,
            "error": f"HTTP {e.code}: {e.reason}",
            "request_id": request_id,
            "quarantined": True
        }
    except urllib.error.URLError as e:
        return {
            "success": False,
            "error": f"URL Error: {e.reason}",
            "request_id": request_id,
            "quarantined": True
        }
    except TimeoutError:
        return {
            "success": False,
            "error": "Request timed out (30s limit)",
            "request_id": request_id,
            "quarantined": True
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e),
            "request_id": request_id,
            "quarantined": True
        }


def search_web(query):
    """
    Search the web using DuckDuckGo HTML interface.
    No JavaScript required, privacy-focused.
    """
    if not query or not query.strip():
        return {"success": False, "error": "Search query required"}
    
    # Use DuckDuckGo HTML-only version
    search_url = f"https://html.duckduckgo.com/html/?q={quote_plus(query.strip())}"
    
    result = fetch_url_sync(search_url, extract_text_content=True)
    
    if result["success"]:
        return {
            "success": True,
            "query": query,
            "engine": "duckduckgo",
            "results": result["content"][:10000],
            "quarantined": True,
            "request_id": result["request_id"]
        }
    
    return result


def handle_browser(action, params):
    """
    Main browser handler dispatcher.
    
    Actions:
    - fetch/get: Fetch a URL
    - search: Search the web via DuckDuckGo
    - status: Get browser status info
    - validate: Check if URL is allowed
    """
    if action == "fetch" or action == "get":
        url = params.get("url")
        if not url:
            return {"success": False, "error": "URL required"}
        return fetch_url_sync(url, params.get("extract_text", True))
    
    elif action == "search":
        query = params.get("query")
        if not query:
            return {"success": False, "error": "Search query required"}
        return search_web(query)
    
    elif action == "status":
        return {
            "success": True,
            "status": "quarantined",
            "config": {
                "timeout": 30,
                "max_size_mb": 5,
                "cookies": "disabled",
                "scripts": "removed",
                "tracking": "blocked",
                "iframes": "removed",
                "private_ips": "blocked"
            },
            "requests_logged": len(REQUEST_LOG)
        }
    
    elif action == "validate":
        url = params.get("url")
        if not url:
            return {"success": False, "error": "URL required"}
        allowed, reason = is_url_allowed(url)
        return {
            "success": True,
            "url": url,
            "allowed": allowed,
            "reason": reason
        }
    
    else:
        return {
            "success": False,
            "error": f"Unknown action: {action}. Valid actions: fetch, search, status, validate"
        }