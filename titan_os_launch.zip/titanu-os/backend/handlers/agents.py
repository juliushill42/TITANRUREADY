import json
from pathlib import Path
from datetime import datetime
import hashlib
import re

TITAN_DATA_DIR = Path(__file__).parent.parent / "titan_data"
AGENTS_DIR = TITAN_DATA_DIR / "agents"

def ensure_agents_dir():
    AGENTS_DIR.mkdir(parents=True, exist_ok=True)

ensure_agents_dir()

# Predefined agent templates
AGENT_TEMPLATES = {
    "researcher": {
        "display_name": "Research Agent",
        "role": "Conducts research and summarizes information",
        "system_prompt": "You are a research assistant. Your job is to find, analyze, and summarize information clearly and concisely. Always cite sources when possible and provide balanced perspectives.",
        "capabilities": ["search", "summarize", "analyze"],
        "temperature": 0.7
    },
    "coder": {
        "display_name": "Code Agent", 
        "role": "Writes and reviews code",
        "system_prompt": "You are an expert programmer. Write clean, efficient, well-documented code. Explain your approach and suggest improvements. Follow best practices for the relevant language.",
        "capabilities": ["code", "debug", "review"],
        "temperature": 0.3
    },
    "writer": {
        "display_name": "Writing Agent",
        "role": "Creates and edits written content",
        "system_prompt": "You are a skilled writer and editor. Create engaging, clear, and well-structured content. Adapt your style to the audience and purpose. Provide constructive feedback on writing.",
        "capabilities": ["write", "edit", "proofread"],
        "temperature": 0.8
    },
    "analyst": {
        "display_name": "Data Analyst",
        "role": "Analyzes data and provides insights",
        "system_prompt": "You are a data analyst. Examine data carefully, identify patterns and trends, and provide actionable insights. Present findings clearly with supporting evidence.",
        "capabilities": ["analyze", "visualize", "report"],
        "temperature": 0.5
    }
}

def handle_agents(action: str, params: dict) -> dict:
    """Handle all agent operations."""
    ensure_agents_dir()
    
    try:
        if action == "list":
            return list_agents()
        
        elif action == "get":
            return get_agent(params.get("agent_id"))
        
        elif action == "create":
            return create_agent(
                name=params.get("name", ""),
                role=params.get("role", ""),
                system_prompt=params.get("system_prompt", ""),
                capabilities=params.get("capabilities", []),
                temperature=params.get("temperature", 0.7),
                template=params.get("template")
            )
        
        elif action == "create_from_description":
            return create_agent_from_description(params.get("description", ""))
        
        elif action == "delete":
            return delete_agent(params.get("agent_id"))
        
        elif action == "templates":
            return get_templates()
        
        elif action == "invoke":
            return invoke_agent(
                params.get("agent_id"),
                params.get("message", ""),
                params.get("context", {})
            )
        
        else:
            return {"success": False, "error": f"Unknown action: {action}"}
    
    except Exception as e:
        return {"success": False, "error": str(e)}


def list_agents() -> dict:
    """List all available agents."""
    agents = []
    
    # List custom agents
    for agent_file in AGENTS_DIR.glob("*.json"):
        try:
            agent_data = json.loads(agent_file.read_text())
            agents.append({
                "agent_id": agent_data.get("agent_id"),
                "display_name": agent_data.get("display_name"),
                "role": agent_data.get("role"),
                "type": "custom",
                "created": agent_data.get("created")
            })
        except:
            pass
    
    # Add built-in templates
    for template_id, template in AGENT_TEMPLATES.items():
        agents.append({
            "agent_id": f"template_{template_id}",
            "display_name": template["display_name"],
            "role": template["role"],
            "type": "template"
        })
    
    return {
        "success": True,
        "agents": agents,
        "count": len(agents)
    }


def get_agent(agent_id: str) -> dict:
    """Get a specific agent by ID."""
    if not agent_id:
        return {"success": False, "error": "Agent ID required"}
    
    # Check if it's a template
    if agent_id.startswith("template_"):
        template_id = agent_id.replace("template_", "")
        if template_id in AGENT_TEMPLATES:
            return {
                "success": True,
                "agent": {
                    "agent_id": agent_id,
                    **AGENT_TEMPLATES[template_id],
                    "type": "template"
                }
            }
        return {"success": False, "error": "Template not found"}
    
    # Check custom agents
    agent_file = AGENTS_DIR / f"{agent_id}.json"
    if agent_file.exists():
        agent_data = json.loads(agent_file.read_text())
        return {"success": True, "agent": agent_data}
    
    return {"success": False, "error": "Agent not found"}


def create_agent(name: str, role: str, system_prompt: str, 
                 capabilities: list = None, temperature: float = 0.7,
                 template: str = None) -> dict:
    """Create a new custom agent."""
    
    # If template specified, use it as base
    if template and template in AGENT_TEMPLATES:
        base = AGENT_TEMPLATES[template].copy()
        if name:
            base["display_name"] = name
        if role:
            base["role"] = role
        if system_prompt:
            base["system_prompt"] = system_prompt
        if capabilities:
            base["capabilities"] = capabilities
        name = base.get("display_name", name)
        role = base.get("role", role)
        system_prompt = base.get("system_prompt", system_prompt)
        capabilities = base.get("capabilities", capabilities)
    
    if not name:
        return {"success": False, "error": "Agent name required"}
    
    # Generate agent ID
    agent_id = re.sub(r'[^a-z0-9_]', '_', name.lower())
    agent_id = re.sub(r'_+', '_', agent_id).strip('_')
    
    # Ensure unique
    if (AGENTS_DIR / f"{agent_id}.json").exists():
        agent_id = f"{agent_id}_{hashlib.md5(datetime.now().isoformat().encode()).hexdigest()[:6]}"
    
    agent = {
        "agent_id": agent_id,
        "display_name": name,
        "role": role or f"Custom agent: {name}",
        "system_prompt": system_prompt or f"You are {name}, a helpful assistant.",
        "capabilities": capabilities or [],
        "temperature": temperature,
        "type": "custom",
        "created": datetime.now().isoformat(),
        "version": "2.5"
    }
    
    # Save agent
    agent_file = AGENTS_DIR / f"{agent_id}.json"
    agent_file.write_text(json.dumps(agent, indent=2))
    
    return {
        "success": True,
        "agent": agent,
        "message": f"Agent '{name}' created successfully!",
        "agent_id": agent_id
    }


def create_agent_from_description(description: str) -> dict:
    """Create an agent from a natural language description.
    
    This parses the description to extract agent details.
    In a full implementation, this would use the LLM to generate the config.
    """
    if not description:
        return {"success": False, "error": "Description required"}
    
    desc_lower = description.lower()
    
    # Try to extract agent name from description
    name = None
    name_patterns = [
        r"(?:create|make|build)(?:\s+an?)?\s+(?:agent|assistant|bot)(?:\s+(?:called|named))?\s+[\"']?([^\"'\.,]+)[\"']?",
        r"[\"']([^\"']+)[\"']\s+(?:agent|assistant)",
        r"(?:agent|assistant)\s+(?:called|named)\s+[\"']?([^\"'\.,]+)[\"']?"
    ]
    
    for pattern in name_patterns:
        match = re.search(pattern, description, re.IGNORECASE)
        if match:
            name = match.group(1).strip()
            break
    
    if not name:
        # Generate name from description
        words = description.split()[:3]
        name = " ".join(w.capitalize() for w in words) + " Agent"
    
    # Try to identify role/purpose
    role = None
    role_keywords = {
        "research": "Conducts research and analysis",
        "code": "Writes and reviews code",
        "write": "Creates written content",
        "analyze": "Analyzes data and provides insights",
        "help": "Provides helpful assistance",
        "chat": "Engages in conversation",
        "translate": "Translates between languages",
        "summarize": "Summarizes content",
        "teach": "Teaches and explains concepts",
        "creative": "Generates creative content"
    }
    
    for keyword, desc_role in role_keywords.items():
        if keyword in desc_lower:
            role = desc_role
            break
    
    if not role:
        role = "Custom assistant created from description"
    
    # Generate system prompt from description
    system_prompt = f"""You are {name}. {role}.

Your purpose based on how you were created:
{description}

Always be helpful, accurate, and professional in your responses."""

    # Identify capabilities
    capabilities = []
    cap_keywords = {
        "search": ["search", "find", "look up", "research"],
        "code": ["code", "program", "develop", "script"],
        "write": ["write", "compose", "draft", "create content"],
        "analyze": ["analyze", "examine", "evaluate", "assess"],
        "summarize": ["summarize", "condense", "brief"],
        "translate": ["translate", "convert language"],
        "chat": ["chat", "converse", "discuss"]
    }
    
    for cap, keywords in cap_keywords.items():
        if any(kw in desc_lower for kw in keywords):
            capabilities.append(cap)
    
    if not capabilities:
        capabilities = ["chat", "help"]
    
    # Determine temperature based on task type
    temperature = 0.7
    if any(w in desc_lower for w in ["creative", "story", "brainstorm"]):
        temperature = 0.9
    elif any(w in desc_lower for w in ["code", "precise", "accurate", "factual"]):
        temperature = 0.3
    
    return create_agent(
        name=name,
        role=role,
        system_prompt=system_prompt,
        capabilities=capabilities,
        temperature=temperature
    )


def delete_agent(agent_id: str) -> dict:
    """Delete a custom agent."""
    if not agent_id:
        return {"success": False, "error": "Agent ID required"}
    
    if agent_id.startswith("template_"):
        return {"success": False, "error": "Cannot delete built-in templates"}
    
    agent_file = AGENTS_DIR / f"{agent_id}.json"
    if not agent_file.exists():
        return {"success": False, "error": "Agent not found"}
    
    agent_file.unlink()
    return {"success": True, "deleted": agent_id}


def get_templates() -> dict:
    """Get available agent templates."""
    templates = []
    for template_id, template in AGENT_TEMPLATES.items():
        templates.append({
            "template_id": template_id,
            **template
        })
    return {
        "success": True,
        "templates": templates,
        "count": len(templates)
    }


def invoke_agent(agent_id: str, message: str, context: dict = None) -> dict:
    """Invoke an agent with a message.
    
    This returns the agent's system prompt and context for the LLM call.
    The actual LLM call is handled by the main prompt handler.
    """
    if not agent_id:
        return {"success": False, "error": "Agent ID required"}
    if not message:
        return {"success": False, "error": "Message required"}
    
    # Get the agent
    result = get_agent(agent_id)
    if not result.get("success"):
        return result
    
    agent = result["agent"]
    
    return {
        "success": True,
        "agent_id": agent_id,
        "agent_name": agent.get("display_name"),
        "system_prompt": agent.get("system_prompt"),
        "temperature": agent.get("temperature", 0.7),
        "message": message,
        "context": context or {},
        "ready_for_llm": True
    }


# Helper function to detect agent creation intent in user messages
def detect_agent_intent(message: str) -> dict:
    """Detect if a message is requesting agent creation/management."""
    msg_lower = message.lower().strip()
    
    # Agent creation triggers
    create_triggers = [
        "create agent", "create an agent", "make agent", "make an agent",
        "build agent", "build an agent", "new agent",
        "/agent create", "/create agent", "/newagent"
    ]
    
    if any(trigger in msg_lower for trigger in create_triggers):
        return {
            "intent": "create",
            "description": message
        }
    
    # List agents
    list_triggers = ["/agents", "/list agents", "list agents", "show agents", "my agents"]
    if any(trigger in msg_lower for trigger in list_triggers):
        return {"intent": "list"}
    
    # Templates
    if "/templates" in msg_lower or "agent templates" in msg_lower:
        return {"intent": "templates"}
    
    # Invoke agent (e.g., "ask Research Agent to...")
    invoke_patterns = [
        r"ask\s+([^\s]+(?:\s+[^\s]+)?)\s+(?:agent\s+)?to\s+(.+)",
        r"use\s+([^\s]+(?:\s+[^\s]+)?)\s+(?:agent\s+)?(?:to|for)\s+(.+)",
        r"@([^\s]+)\s+(.+)"
    ]
    
    for pattern in invoke_patterns:
        match = re.search(pattern, message, re.IGNORECASE)
        if match:
            return {
                "intent": "invoke",
                "agent_name": match.group(1),
                "message": match.group(2)
            }
    
    return {"intent": None}