"""
Titan OS Commander Edition - AI Agent Swarm Backend
Ported from Titan OS v1.5 for integration with v2 desktop app
"""
__version__ = "1.5.1"
__edition__ = "Commander"