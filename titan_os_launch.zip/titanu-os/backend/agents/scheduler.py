"""
TitanU OS v3.0 Genesis - Scheduled Tasks System
Allows TITAN to run tasks at scheduled times automatically.

Features:
- No external dependencies (uses asyncio only)
- Saves task configs to titan_data/config/schedules.json
- Outputs task results to titan_data/scheduled_output/
- Processes tasks through LLM callback
- Sends notifications via callback
- Checks for scheduled tasks every 30 seconds
- Supports "daily" and "once" repeat patterns
- Uses "HH:MM" time format (24-hour)
"""

import json
import asyncio
import os
from pathlib import Path
from datetime import datetime, time
from typing import Dict, Any, Optional, Callable, List
import uuid


class SimpleScheduler:
    """Simple scheduler for scheduled tasks"""
    
    def __init__(self):
        self.tasks: Dict[str, Dict] = {}
        self.last_run: Dict[str, str] = {}  # task_id -> "YYYY-MM-DD HH:MM"
        self.running = False
        self.loop_task: Optional[asyncio.Task] = None
        self.llm_callback: Optional[Callable] = None
        self.notify_callback: Optional[Callable] = None
        
        # Setup paths
        base_path = Path(__file__).parent.parent / "titan_data"
        self.config_dir = base_path / "config"
        self.output_dir = base_path / "scheduled_output"
        self.schedules_file = self.config_dir / "schedules.json"
        
        # Create directories
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # Load existing schedules
        self._load_schedules()
    
    def set_callbacks(self, llm_callback: Callable, notify_callback: Optional[Callable] = None):
        """Set callbacks for LLM processing and notifications"""
        self.llm_callback = llm_callback
        self.notify_callback = notify_callback
    
    def _load_schedules(self):
        """Load schedules from JSON file"""
        if self.schedules_file.exists():
            try:
                with open(self.schedules_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.tasks = data.get('tasks', {})
                    self.last_run = data.get('last_run', {})
            except Exception as e:
                print(f"Error loading schedules: {e}")
                self.tasks = {}
                self.last_run = {}
    
    def _save_schedules(self):
        """Save schedules to JSON file"""
        try:
            data = {
                'tasks': self.tasks,
                'last_run': self.last_run
            }
            with open(self.schedules_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"Error saving schedules: {e}")
    
    def create_task(self, name: str, prompt: str, time_str: str, repeat: str = "once") -> Dict:
        """
        Create a new scheduled task
        
        Args:
            name: Task name
            prompt: Prompt to execute
            time_str: Time in HH:MM format (24-hour)
            repeat: "daily" or "once"
        
        Returns:
            Dict with task info or error
        """
        # Validate time format
        try:
            hour, minute = map(int, time_str.split(':'))
            if not (0 <= hour <= 23 and 0 <= minute <= 59):
                raise ValueError("Invalid time range")
        except Exception:
            return {"success": False, "error": "Invalid time format. Use HH:MM (24-hour)"}
        
        # Validate repeat
        if repeat not in ["daily", "once"]:
            return {"success": False, "error": "Repeat must be 'daily' or 'once'"}
        
        # Create task
        task_id = f"task_{uuid.uuid4().hex[:8]}"
        task = {
            "id": task_id,
            "name": name,
            "prompt": prompt,
            "time": time_str,
            "repeat": repeat,
            "created": datetime.now().isoformat(),
            "enabled": True
        }
        
        self.tasks[task_id] = task
        self._save_schedules()
        
        return {
            "success": True,
            "task": task,
            "message": f"Task '{name}' scheduled for {time_str} ({repeat})"
        }
    
    def delete_task(self, task_id: str) -> Dict:
        """Delete a scheduled task"""
        if task_id not in self.tasks:
            return {"success": False, "error": f"Task {task_id} not found"}
        
        task_name = self.tasks[task_id].get('name', task_id)
        del self.tasks[task_id]
        if task_id in self.last_run:
            del self.last_run[task_id]
        
        self._save_schedules()
        
        return {
            "success": True,
            "message": f"Task '{task_name}' deleted"
        }
    
    def list_tasks(self) -> Dict:
        """List all scheduled tasks"""
        tasks_list = []
        now = datetime.now()
        
        for task_id, task in self.tasks.items():
            task_info = task.copy()
            last_run = self.last_run.get(task_id)
            task_info['last_run'] = last_run
            
            # Calculate next run
            if task['repeat'] == 'daily' or (task['repeat'] == 'once' and not last_run):
                hour, minute = map(int, task['time'].split(':'))
                next_run = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
                if next_run <= now:
                    # If time has passed today, next run is tomorrow (for daily) or done (for once)
                    if task['repeat'] == 'daily':
                        next_run = next_run.replace(day=next_run.day + 1)
                    else:
                        next_run = None
                task_info['next_run'] = next_run.isoformat() if next_run else "Completed"
            else:
                task_info['next_run'] = "Completed"
            
            tasks_list.append(task_info)
        
        return {
            "success": True,
            "tasks": tasks_list,
            "count": len(tasks_list)
        }
    
    async def run_task_now(self, task_id: str) -> Dict:
        """Run a task immediately (async)"""
        if task_id not in self.tasks:
            return {"success": False, "error": f"Task {task_id} not found"}
        
        task = self.tasks[task_id]
        
        if not self.llm_callback:
            return {"success": False, "error": "LLM callback not set"}
        
        try:
            # Execute task through LLM
            result = await self.llm_callback(task['prompt'])
            
            # Save output
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_file = self.output_dir / f"{task['name'].replace(' ', '_')}_{timestamp}.txt"
            
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(f"Task: {task['name']}\n")
                f.write(f"Prompt: {task['prompt']}\n")
                f.write(f"Executed: {datetime.now().isoformat()}\n")
                f.write(f"\n{'='*60}\n\n")
                f.write(result)
            
            # Update last run
            self.last_run[task_id] = datetime.now().strftime("%Y-%m-%d %H:%M")
            self._save_schedules()
            
            # Send notification if callback available
            if self.notify_callback:
                try:
                    await self.notify_callback(f"Scheduled task '{task['name']}' completed")
                except Exception:
                    pass
            
            return {
                "success": True,
                "result": result,
                "output_file": str(output_file),
                "message": f"Task '{task['name']}' executed successfully"
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": f"Task execution failed: {str(e)}"
            }
    
    def run_task_now_sync(self, task_id: str) -> Dict:
        """Synchronous wrapper for run_task_now"""
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(self.run_task_now(task_id))
    
    async def _check_schedules(self):
        """Check if any tasks should run now"""
        now = datetime.now()
        current_time = now.strftime("%H:%M")
        current_minute = now.strftime("%Y-%m-%d %H:%M")
        
        for task_id, task in list(self.tasks.items()):
            if not task.get('enabled', True):
                continue
            
            # Check if it's time to run
            if task['time'] != current_time:
                continue
            
            # Prevent duplicate runs in the same minute
            if self.last_run.get(task_id) == current_minute:
                continue
            
            # For "once" tasks, skip if already run
            if task['repeat'] == 'once' and task_id in self.last_run:
                continue
            
            # Run the task
            print(f"[Scheduler] Running task: {task['name']}")
            try:
                await self.run_task_now(task_id)
            except Exception as e:
                print(f"[Scheduler] Error running task {task['name']}: {e}")
    
    async def _scheduler_loop(self):
        """Main scheduler loop - checks every 30 seconds"""
        print("[Scheduler] Started")
        while self.running:
            try:
                await self._check_schedules()
            except Exception as e:
                print(f"[Scheduler] Error in check: {e}")
            
            # Wait 30 seconds
            await asyncio.sleep(30)
        
        print("[Scheduler] Stopped")
    
    def start(self):
        """Start the scheduler"""
        if self.running:
            return
        
        self.running = True
        # Create task in the current event loop
        try:
            loop = asyncio.get_event_loop()
            self.loop_task = loop.create_task(self._scheduler_loop())
        except RuntimeError:
            # No event loop running, will start later
            pass
    
    def stop(self):
        """Stop the scheduler"""
        self.running = False
        if self.loop_task:
            self.loop_task.cancel()
            self.loop_task = None


# Global scheduler instance
scheduler = SimpleScheduler()


def handle_schedule_command(action: str, data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Handle schedule command routing
    
    Args:
        action: Action to perform (list, create, run, delete)
        data: Command data
    
    Returns:
        Response dict
    """
    try:
        if action == "list":
            return scheduler.list_tasks()
        
        elif action == "create":
            name = data.get('name')
            prompt = data.get('prompt')
            time_str = data.get('time')
            repeat = data.get('repeat', 'once')
            
            if not all([name, prompt, time_str]):
                return {
                    "success": False,
                    "error": "Missing required fields: name, prompt, time"
                }
            
            return scheduler.create_task(name, prompt, time_str, repeat)
        
        elif action == "run":
            task_id = data.get('id')
            if not task_id:
                return {"success": False, "error": "Missing task id"}
            
            # Use sync wrapper for immediate execution
            return scheduler.run_task_now_sync(task_id)
        
        elif action == "delete":
            task_id = data.get('id')
            if not task_id:
                return {"success": False, "error": "Missing task id"}
            
            return scheduler.delete_task(task_id)
        
        else:
            return {
                "success": False,
                "error": f"Unknown action: {action}. Use: list, create, run, delete"
            }
    
    except Exception as e:
        return {
            "success": False,
            "error": f"Scheduler error: {str(e)}"
        }