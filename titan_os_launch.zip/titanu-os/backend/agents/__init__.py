"""
TitanU OS Agents Module
Background agents for file watching and automation
"""

from .file_watcher import handle_watcher_command, watcher_manager

__all__ = ['handle_watcher_command', 'watcher_manager']