"""
Background File Watcher System for TitanU OS v3.0 Genesis
Monitors folders and automatically processes new files through TITAN's LLM.
"""

import os
import json
import time
import threading
from pathlib import Path
from typing import Dict, List, Optional, Callable, Any

# Try to import watchdog, but gracefully handle if not installed
try:
    from watchdog.observers import Observer
    from watchdog.events import FileSystemEventHandler
    WATCHDOG_AVAILABLE = True
except ImportError:
    WATCHDOG_AVAILABLE = False
    Observer = None
    FileSystemEventHandler = None


class FileWatcherHandler(FileSystemEventHandler):
    """Handles file system events for a specific watcher."""
    
    def __init__(self, watcher_id: str, manager: 'FileWatcherManager', file_types: List[str]):
        """
        Initialize the file watcher handler.
        
        Args:
            watcher_id: Unique identifier for this watcher
            manager: Reference to the FileWatcherManager
            file_types: List of file extensions to watch (e.g., ['.pdf', '.txt'])
        """
        super().__init__()
        self.watcher_id = watcher_id
        self.manager = manager
        self.file_types = [ft.lower() for ft in file_types]
        self.processed_files = set()
    
    def on_created(self, event):
        """Handle file creation events."""
        if event.is_directory:
            return
        
        file_path = event.src_path
        file_ext = os.path.splitext(file_path)[1].lower()
        
        # Check if file type matches
        if self.file_types and file_ext not in self.file_types:
            return
        
        # Avoid processing the same file multiple times
        if file_path in self.processed_files:
            return
        
        self.processed_files.add(file_path)
        
        # Wait a moment to ensure file is fully written
        time.sleep(0.5)
        
        # Process the file
        self.manager._process_file(self.watcher_id, file_path)


class FileWatcherManager:
    """Manages multiple file watchers for background monitoring."""
    
    def __init__(self):
        """Initialize the file watcher manager."""
        self.watchers: Dict[str, Dict[str, Any]] = {}
        self.observers: Dict[str, Any] = {}
        self.config_dir = Path("titan_data/config")
        self.config_file = self.config_dir / "watchers.json"
        self.llm_callback: Optional[Callable] = None
        self.notify_callback: Optional[Callable] = None
        self._lock = threading.Lock()
        
        # Create config directory if it doesn't exist
        self.config_dir.mkdir(parents=True, exist_ok=True)
        
        # Load existing watchers
        self._load_watchers()
    
    def set_callbacks(self, llm_callback: Callable, notify_callback: Optional[Callable] = None):
        """
        Set callbacks for LLM processing and notifications.
        
        Args:
            llm_callback: Async function to process prompts through LLM
            notify_callback: Optional function to send notifications
        """
        self.llm_callback = llm_callback
        self.notify_callback = notify_callback
    
    def create_watcher(self, path: str, file_types: Optional[List[str]] = None, 
                      prompt_template: Optional[str] = None) -> Dict[str, Any]:
        """
        Create a new file watcher.
        
        Args:
            path: Directory path to watch
            file_types: List of file extensions to watch (e.g., ['.pdf', '.txt'])
            prompt_template: Optional custom prompt template for processing files
        
        Returns:
            Dict with watcher info and status
        """
        if not WATCHDOG_AVAILABLE:
            return {
                "success": False,
                "error": "watchdog library not installed. Run: pip install watchdog"
            }
        
        # Expand user path
        expanded_path = os.path.expanduser(path)
        
        # Check if path exists
        if not os.path.exists(expanded_path):
            return {
                "success": False,
                "error": f"Path does not exist: {expanded_path}"
            }
        
        if not os.path.isdir(expanded_path):
            return {
                "success": False,
                "error": f"Path is not a directory: {expanded_path}"
            }
        
        # Generate unique ID
        watcher_id = f"watcher_{int(time.time() * 1000)}"
        
        # Default prompt template
        if not prompt_template:
            prompt_template = "A new file has been detected: {filename}\n\nPlease analyze this file and provide insights."
        
        # Store watcher config
        watcher_config = {
            "id": watcher_id,
            "path": expanded_path,
            "original_path": path,
            "file_types": file_types or [],
            "prompt_template": prompt_template,
            "created_at": time.time(),
            "active": True
        }
        
        with self._lock:
            self.watchers[watcher_id] = watcher_config
            self._save_watchers()
        
        # Start the watcher
        self._start_watcher(watcher_id, watcher_config)
        
        return {
            "success": True,
            "watcher_id": watcher_id,
            "watcher": watcher_config
        }
    
    def stop_watcher(self, watcher_id: str) -> Dict[str, Any]:
        """
        Stop a running watcher.
        
        Args:
            watcher_id: ID of the watcher to stop
        
        Returns:
            Dict with success status
        """
        with self._lock:
            if watcher_id not in self.watchers:
                return {"success": False, "error": "Watcher not found"}
            
            if watcher_id in self.observers:
                observer = self.observers[watcher_id]
                observer.stop()
                observer.join(timeout=2)
                del self.observers[watcher_id]
            
            self.watchers[watcher_id]["active"] = False
            self._save_watchers()
        
        return {"success": True, "watcher_id": watcher_id}
    
    def delete_watcher(self, watcher_id: str) -> Dict[str, Any]:
        """
        Delete a watcher permanently.
        
        Args:
            watcher_id: ID of the watcher to delete
        
        Returns:
            Dict with success status
        """
        # First stop it
        self.stop_watcher(watcher_id)
        
        with self._lock:
            if watcher_id in self.watchers:
                del self.watchers[watcher_id]
                self._save_watchers()
        
        return {"success": True, "watcher_id": watcher_id}
    
    def list_watchers(self) -> Dict[str, Any]:
        """
        Get list of all watchers.
        
        Returns:
            Dict with list of watchers
        """
        return {
            "success": True,
            "watchers": list(self.watchers.values()),
            "watchdog_available": WATCHDOG_AVAILABLE
        }
    
    def start_all(self) -> Dict[str, Any]:
        """
        Start all saved watchers.
        
        Returns:
            Dict with success status
        """
        if not WATCHDOG_AVAILABLE:
            return {
                "success": False,
                "error": "watchdog library not installed"
            }
        
        started = []
        for watcher_id, config in self.watchers.items():
            if config.get("active", True):
                self._start_watcher(watcher_id, config)
                started.append(watcher_id)
        
        return {
            "success": True,
            "started": started
        }
    
    def stop_all(self) -> Dict[str, Any]:
        """
        Stop all running watchers.
        
        Returns:
            Dict with success status
        """
        stopped = []
        with self._lock:
            for watcher_id in list(self.observers.keys()):
                observer = self.observers[watcher_id]
                observer.stop()
                observer.join(timeout=2)
                stopped.append(watcher_id)
            
            self.observers.clear()
        
        return {
            "success": True,
            "stopped": stopped
        }
    
    def _start_watcher(self, watcher_id: str, config: Dict[str, Any]):
        """
        Internal method to start a watcher.
        
        Args:
            watcher_id: ID of the watcher
            config: Watcher configuration
        """
        if not WATCHDOG_AVAILABLE:
            return
        
        if watcher_id in self.observers:
            # Already running
            return
        
        path = config["path"]
        file_types = config.get("file_types", [])
        
        # Create event handler
        event_handler = FileWatcherHandler(watcher_id, self, file_types)
        
        # Create observer
        observer = Observer()
        observer.schedule(event_handler, path, recursive=False)
        observer.start()
        
        self.observers[watcher_id] = observer
    
    def _process_file(self, watcher_id: str, file_path: str):
        """
        Process a detected file through LLM.
        
        Args:
            watcher_id: ID of the watcher that detected the file
            file_path: Path to the detected file
        """
        if watcher_id not in self.watchers:
            return
        
        config = self.watchers[watcher_id]
        filename = os.path.basename(file_path)
        
        # Format prompt
        prompt = config["prompt_template"].format(
            filename=filename,
            filepath=file_path,
            directory=config["path"]
        )
        
        # Send notification if callback exists
        if self.notify_callback:
            try:
                self.notify_callback({
                    "type": "file_detected",
                    "watcher_id": watcher_id,
                    "file": filename,
                    "path": file_path
                })
            except Exception as e:
                print(f"Notification error: {e}")
        
        # Process through LLM if callback exists
        if self.llm_callback:
            try:
                # Run async callback in thread-safe way
                import asyncio
                try:
                    loop = asyncio.get_event_loop()
                except RuntimeError:
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                
                response = loop.run_until_complete(self.llm_callback(prompt))
                
                # Send result notification
                if self.notify_callback:
                    self.notify_callback({
                        "type": "file_processed",
                        "watcher_id": watcher_id,
                        "file": filename,
                        "response": response
                    })
            except Exception as e:
                print(f"LLM processing error: {e}")
    
    def _load_watchers(self):
        """Load watchers from config file."""
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r') as f:
                    data = json.load(f)
                    self.watchers = data.get("watchers", {})
            except Exception as e:
                print(f"Error loading watchers: {e}")
                self.watchers = {}
        else:
            self.watchers = {}
    
    def _save_watchers(self):
        """Save watchers to config file."""
        try:
            with open(self.config_file, 'w') as f:
                json.dump({"watchers": self.watchers}, f, indent=2)
        except Exception as e:
            print(f"Error saving watchers: {e}")


# Global instance
watcher_manager = FileWatcherManager()


def handle_watcher_command(action: str, data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Handle file watcher commands.
    
    Args:
        action: The action to perform (create, stop, delete, list)
        data: Command data
    
    Returns:
        Dict with command result
    """
    if action == "create":
        path = data.get("path")
        if not path:
            return {"success": False, "error": "path is required"}
        
        file_types = data.get("types") or data.get("file_types")
        prompt_template = data.get("prompt_template")
        
        return watcher_manager.create_watcher(path, file_types, prompt_template)
    
    elif action == "stop":
        watcher_id = data.get("watcher_id") or data.get("id")
        if not watcher_id:
            return {"success": False, "error": "watcher_id is required"}
        
        return watcher_manager.stop_watcher(watcher_id)
    
    elif action == "delete":
        watcher_id = data.get("watcher_id") or data.get("id")
        if not watcher_id:
            return {"success": False, "error": "watcher_id is required"}
        
        return watcher_manager.delete_watcher(watcher_id)
    
    elif action == "list":
        return watcher_manager.list_watchers()
    
    elif action == "start_all":
        return watcher_manager.start_all()
    
    elif action == "stop_all":
        return watcher_manager.stop_all()
    
    else:
        return {
            "success": False,
            "error": f"Unknown action: {action}",
            "available_actions": ["create", "stop", "delete", "list", "start_all", "stop_all"]
        }