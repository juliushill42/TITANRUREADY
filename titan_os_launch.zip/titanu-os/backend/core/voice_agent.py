"""
Titan OS v2 - Voice Agent
Handles voice transcription (stub ready for Whisper/Vosk integration)
"""
import os
from pathlib import Path
from typing import Dict, Any, Optional

from utils import format_response

# Flag to check if speech recognition is available
SPEECH_AVAILABLE = False
try:
    import speech_recognition as sr
    SPEECH_AVAILABLE = True
except ImportError:
    pass

def handle_transcribe_audio(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Transcribe audio file to text.
    
    Input params:
        - audio_path: str (required) - Path to audio file (WAV format)
        - language: str (optional) - Language code (default: "en-US")
        - engine: str (optional) - Transcription engine: "google", "sphinx", "whisper" (default: "sphinx")
    
    Output: {"status": "success", "data": {"text": ..., "confidence": ...}}
    
    NOTE: This is a stub implementation. For production:
    - Install: pip install SpeechRecognition pocketsphinx
    - Or integrate with OpenAI Whisper for better accuracy
    """
    audio_path = params.get("audio_path")
    language = params.get("language", "en-US")
    engine = params.get("engine", "sphinx")
    
    if not audio_path:
        return format_response("error", error="Missing required parameter: audio_path")
    
    # Check if file exists
    if not os.path.exists(audio_path):
        return format_response("error", error=f"Audio file not found: {audio_path}")
    
    # Check file extension
    if not audio_path.lower().endswith('.wav'):
        return format_response("error", error="Only WAV format is supported")
    
    if not SPEECH_AVAILABLE:
        # Return stub response when speech recognition is not installed
        return format_response("success", data={
            "text": "[Speech recognition not available - install SpeechRecognition package]",
            "confidence": 0.0,
            "engine": "stub",
            "note": "Install 'pip install SpeechRecognition pocketsphinx' for offline transcription"
        }, message="Voice transcription stub - dependencies not installed")
    
    try:
        recognizer = sr.Recognizer()
        
        with sr.AudioFile(audio_path) as source:
            audio = recognizer.record(source)
        
        text = ""
        confidence = 0.0
        
        if engine == "sphinx":
            # Offline recognition with PocketSphinx
            try:
                text = recognizer.recognize_sphinx(audio, language=language)
                confidence = 0.7  # Sphinx doesn't provide confidence
            except sr.UnknownValueError:
                return format_response("error", error="Could not understand audio")
            except sr.RequestError as e:
                return format_response("error", error=f"Sphinx error: {e}")
                
        elif engine == "google":
            # Online recognition (requires internet)
            try:
                text = recognizer.recognize_google(audio, language=language)
                confidence = 0.9
            except sr.UnknownValueError:
                return format_response("error", error="Could not understand audio")
            except sr.RequestError as e:
                return format_response("error", error=f"Google API error: {e}")
        
        elif engine == "whisper":
            # Whisper integration (requires openai-whisper package)
            return format_response("error", error="Whisper engine not yet implemented. Use 'sphinx' or 'google'.")
        
        else:
            return format_response("error", error=f"Unknown engine: {engine}. Use 'sphinx', 'google', or 'whisper'.")
        
        return format_response("success", data={
            "text": text,
            "confidence": confidence,
            "engine": engine,
            "language": language,
            "audio_path": audio_path
        })
        
    except Exception as e:
        return format_response("error", error=f"Transcription failed: {str(e)}")

def handle_voice_status(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Check voice recognition capabilities.
    
    Output: {"status": "success", "data": {"available": ..., "engines": [...]}}
    """
    engines = []
    
    if SPEECH_AVAILABLE:
        engines.append("sphinx")  # Offline, always available with package
        engines.append("google")  # Online, requires internet
    
    return format_response("success", data={
        "available": SPEECH_AVAILABLE,
        "engines": engines,
        "recommended": "sphinx" if SPEECH_AVAILABLE else None,
        "install_instructions": "pip install SpeechRecognition pocketsphinx" if not SPEECH_AVAILABLE else None
    })

def handle_voice_command(command: str, params: Dict[str, Any]) -> Dict[str, Any]:
    """Route voice commands to appropriate handler"""
    handlers = {
        "transcribe_audio": handle_transcribe_audio,
        "voice_status": handle_voice_status,
    }
    
    handler = handlers.get(command)
    if not handler:
        return format_response("error", error=f"Unknown voice command: {command}")
    
    return handler(params)