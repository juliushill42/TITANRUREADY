"""
Titan OS v2 - File Agent
Handles file operations: save, read, list files
"""
import os
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List

from utils import (
    format_response,
    get_titan_data_path,
    safe_path_join,
    ensure_directory,
    detect_titan_drive
)

def get_storage_base() -> Path:
    """Get the base storage path (USB drive or local titan_data)"""
    drive = detect_titan_drive()
    if drive:
        return Path(f"{drive}\\TITAN_DATA\\files")
    return get_titan_data_path() / "files"

def handle_save_file(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Save a file to Titan storage.
    
    Input params:
        - filename: str (required) - Name of the file
        - content: str (required) - Content to save
        - subfolder: str (optional) - Subfolder within files/
    
    Output: {"status": "success", "data": {"path": "...", "size": ...}}
    """
    filename = params.get("filename")
    content = params.get("content")
    subfolder = params.get("subfolder", "")
    
    if not filename:
        return format_response("error", error="Missing required parameter: filename")
    if content is None:
        return format_response("error", error="Missing required parameter: content")
    
    # Build safe path
    base = get_storage_base()
    if subfolder:
        target_dir = base / subfolder
    else:
        target_dir = base
    
    # Ensure directory exists
    target_dir.mkdir(parents=True, exist_ok=True)
    
    # Validate filename (prevent directory traversal)
    safe_filename = os.path.basename(filename)
    if not safe_filename:
        return format_response("error", error="Invalid filename")
    
    filepath = target_dir / safe_filename
    
    try:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        
        return format_response("success", data={
            "path": str(filepath),
            "size": len(content),
            "saved_at": datetime.now().isoformat()
        })
    except Exception as e:
        return format_response("error", error=f"Failed to save file: {e}")

def handle_read_file(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Read a file from Titan storage.
    
    Input params:
        - path: str (optional) - Absolute path to file (if provided, overrides filename)
        - filename: str (optional) - Name of the file
        - subfolder: str (optional) - Subfolder within files/
    
    Output: {"status": "success", "data": {"content": "...", "size": ...}}
    """
    path = params.get("path")
    filename = params.get("filename")
    subfolder = params.get("subfolder", "")
    
    if path:
        # Use absolute path with security check
        filepath = Path(path)
        titan_data = get_titan_data_path().resolve()
        try:
            filepath_resolved = filepath.resolve()
            if not str(filepath_resolved).startswith(str(titan_data)):
                return format_response("error", error="Access denied: File outside allowed directories")
        except Exception:
            return format_response("error", error="Invalid path")
    elif filename:
        base = get_storage_base()
        if subfolder:
            target_dir = base / subfolder
        else:
            target_dir = base
        
        safe_filename = os.path.basename(filename)
        filepath = target_dir / safe_filename
    else:
        return format_response("error", error="Missing required parameter: path or filename")
    
    if not filepath.exists():
        return format_response("error", error=f"File not found: {filepath.name}")
    
    if not filepath.is_file():
        return format_response("error", error=f"Not a file: {filepath.name}")
    
    # Check file size limit (10MB for text)
    file_size = filepath.stat().st_size
    if file_size > 10 * 1024 * 1024:
        return format_response("error", error="File too large (max 10MB)")
    
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        return format_response("success", data={
            "content": content,
            "size": len(content),
            "path": str(filepath),
            "lines": content.count('\n') + 1
        })
    except UnicodeDecodeError:
        return format_response("error", error="Binary file - cannot read as text")
    except Exception as e:
        return format_response("error", error=f"Failed to read file: {e}")

def handle_list_files(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    List files and directories in Titan storage.
    
    Input params:
        - path: str (optional) - Absolute path to list (if provided, overrides subfolder)
        - subfolder: str (optional) - Subfolder within files/
        - recursive: bool (optional) - List recursively (default: False)
    
    Output: {"status": "success", "data": {"files": [...], "count": ..., "path": ...}}
    """
    path = params.get("path")
    subfolder = params.get("subfolder", "")
    recursive = params.get("recursive", False)
    
    base = get_storage_base()
    
    # If absolute path provided, use it (with security check)
    if path:
        target_dir = Path(path)
        # Security: ensure path is within allowed directories
        titan_data = get_titan_data_path().resolve()
        try:
            target_resolved = target_dir.resolve()
            # Allow titan_data directory and subdirectories
            if not str(target_resolved).startswith(str(titan_data)):
                return format_response("error", error="Access denied: Path outside allowed directories")
        except Exception:
            return format_response("error", error="Invalid path")
    elif subfolder:
        target_dir = base / subfolder
    else:
        target_dir = base
    
    # Create directory if it doesn't exist
    target_dir.mkdir(parents=True, exist_ok=True)
    
    items: List[Dict[str, Any]] = []
    
    try:
        if recursive:
            for root, dirs, filenames in os.walk(target_dir):
                # Add directories
                for dname in dirs:
                    if dname.startswith('.'):
                        continue
                    dpath = Path(root) / dname
                    stat = dpath.stat()
                    items.append({
                        "name": dname,
                        "path": str(dpath),
                        "is_dir": True,
                        "size": 0,
                        "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                        "extension": None
                    })
                # Add files
                for fname in filenames:
                    if fname.startswith('.'):
                        continue
                    fpath = Path(root) / fname
                    stat = fpath.stat()
                    items.append({
                        "name": fname,
                        "path": str(fpath),
                        "is_dir": False,
                        "size": stat.st_size,
                        "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                        "extension": fpath.suffix.lower() if fpath.suffix else None
                    })
        else:
            for item in target_dir.iterdir():
                # Skip hidden files
                if item.name.startswith('.'):
                    continue
                stat = item.stat()
                items.append({
                    "name": item.name,
                    "path": str(item),
                    "is_dir": item.is_dir(),
                    "size": stat.st_size if item.is_file() else 0,
                    "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                    "extension": item.suffix.lower() if item.is_file() and item.suffix else None
                })
        
        # Sort: directories first, then by name
        items.sort(key=lambda x: (not x["is_dir"], x["name"].lower()))
        
        return format_response("success", data={
            "files": items,
            "count": len(items),
            "path": str(target_dir),
            "parent": str(target_dir.parent) if target_dir.parent != target_dir else None,
            "base_path": str(base)
        })
    except Exception as e:
        return format_response("error", error=f"Failed to list files: {e}")

def handle_file_command(command: str, params: Dict[str, Any]) -> Dict[str, Any]:
    """Route file commands to appropriate handler"""
    handlers = {
        "save_file": handle_save_file,
        "read_file": handle_read_file,
        "list_files": handle_list_files,
    }
    
    handler = handlers.get(command)
    if not handler:
        return format_response("error", error=f"Unknown file command: {command}")
    
    return handler(params)