"""
Titan OS v3.0 - Simple Notification System
Collects notifications from background tasks and makes them accessible to the UI.
"""
import json
import os
from collections import deque
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any
from utils import format_response, log_error


class NotificationManager:
    """
    Manages notifications from background tasks.
    
    Features:
    - Auto-limiting deque (max 100 notifications)
    - Persistent storage in titan_data/notifications.json
    - Unique ID generation using timestamps
    - Read/unread status tracking
    - Type categorization (file_watcher, scheduled_task, system)
    """
    
    def __init__(self, max_notifications: int = 100):
        """
        Initialize notification manager.
        
        Args:
            max_notifications: Maximum number of notifications to keep (default: 100)
        """
        self.max_notifications = max_notifications
        self.notifications = deque(maxlen=max_notifications)
        self.data_dir = Path(__file__).parent.parent / "titan_data"
        self.notif_file = self.data_dir / "notifications.json"
        self._load_notifications()
    
    def _load_notifications(self):
        """Load notifications from disk."""
        try:
            if self.notif_file.exists():
                with open(self.notif_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    # Load into deque (will auto-limit to maxlen)
                    for notif in data.get("notifications", []):
                        self.notifications.append(notif)
                log_error(f"Loaded {len(self.notifications)} notifications", "NotificationManager")
        except Exception as e:
            log_error(f"Failed to load notifications: {e}", "NotificationManager")
            self.notifications = deque(maxlen=self.max_notifications)
    
    def _save_notifications(self):
        """Save notifications to disk."""
        try:
            # Ensure directory exists
            self.data_dir.mkdir(parents=True, exist_ok=True)
            
            # Save to file
            with open(self.notif_file, 'w', encoding='utf-8') as f:
                json.dump({
                    "notifications": list(self.notifications),
                    "last_updated": datetime.now().isoformat()
                }, f, indent=2)
        except Exception as e:
            log_error(f"Failed to save notifications: {e}", "NotificationManager")
    
    async def add(self, notification: Dict[str, Any]):
        """
        Add a new notification.
        
        Args:
            notification: Dict with keys:
                - type: "file_watcher" | "scheduled_task" | "system"
                - title: Short title
                - message: Longer message content
                - metadata: Optional additional data
        """
        try:
            # Generate unique ID using timestamp
            notif_id = f"n_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}"
            
            # Create complete notification object
            complete_notif = {
                "id": notif_id,
                "timestamp": datetime.now().isoformat(),
                "type": notification.get("type", "system"),
                "title": notification.get("title", "Notification"),
                "message": notification.get("message", ""),
                "metadata": notification.get("metadata", {}),
                "read": False
            }
            
            # Add to deque (auto-limits to maxlen)
            self.notifications.append(complete_notif)
            
            # Save to disk
            self._save_notifications()
            
            log_error(f"Added notification: {complete_notif['title']}", "NotificationManager")
        except Exception as e:
            log_error(f"Failed to add notification: {e}", "NotificationManager")
    
    def get_unread(self) -> List[Dict[str, Any]]:
        """
        Get unread notifications.
        
        Returns:
            List of unread notifications (newest first)
        """
        unread = [n for n in self.notifications if not n.get("read", False)]
        return list(reversed(unread))  # Newest first
    
    def get_all(self, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Get all notifications.
        
        Args:
            limit: Optional limit on number of notifications to return
        
        Returns:
            List of all notifications (newest first)
        """
        all_notifs = list(reversed(list(self.notifications)))  # Newest first
        if limit:
            return all_notifs[:limit]
        return all_notifs
    
    def mark_read(self, notif_id: str) -> bool:
        """
        Mark a notification as read.
        
        Args:
            notif_id: Notification ID
        
        Returns:
            True if notification was found and marked read, False otherwise
        """
        try:
            for notif in self.notifications:
                if notif.get("id") == notif_id:
                    notif["read"] = True
                    self._save_notifications()
                    return True
            return False
        except Exception as e:
            log_error(f"Failed to mark notification as read: {e}", "NotificationManager")
            return False
    
    def mark_all_read(self) -> int:
        """
        Mark all notifications as read.
        
        Returns:
            Number of notifications marked as read
        """
        try:
            count = 0
            for notif in self.notifications:
                if not notif.get("read", False):
                    notif["read"] = True
                    count += 1
            
            if count > 0:
                self._save_notifications()
            
            return count
        except Exception as e:
            log_error(f"Failed to mark all as read: {e}", "NotificationManager")
            return 0
    
    def clear(self) -> int:
        """
        Clear all notifications.
        
        Returns:
            Number of notifications cleared
        """
        try:
            count = len(self.notifications)
            self.notifications.clear()
            self._save_notifications()
            return count
        except Exception as e:
            log_error(f"Failed to clear notifications: {e}", "NotificationManager")
            return 0


# Global notification manager instance
notifications = NotificationManager()


def handle_notifications_command(action: str, params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Route notifications commands.
    
    Args:
        action: Action to perform (list, all, read, read_all, clear)
        params: Command parameters
    
    Returns:
        Response dict
    """
    try:
        if action == "list":
            # Get unread notifications
            unread = notifications.get_unread()
            return format_response("success", data={
                "notifications": unread,
                "count": len(unread),
                "filter": "unread"
            })
        
        elif action == "all":
            # Get all notifications (with optional limit)
            limit = params.get("limit")
            all_notifs = notifications.get_all(limit)
            return format_response("success", data={
                "notifications": all_notifs,
                "count": len(all_notifs),
                "filter": "all"
            })
        
        elif action == "read":
            # Mark specific notification as read
            notif_id = params.get("id")
            if not notif_id:
                return format_response("error", error="Notification ID required")
            
            success = notifications.mark_read(notif_id)
            if success:
                return format_response("success", message=f"Notification {notif_id} marked as read")
            else:
                return format_response("error", error=f"Notification {notif_id} not found")
        
        elif action == "read_all":
            # Mark all notifications as read
            count = notifications.mark_all_read()
            return format_response("success", message=f"Marked {count} notifications as read")
        
        elif action == "clear":
            # Clear all notifications
            count = notifications.clear()
            return format_response("success", message=f"Cleared {count} notifications")
        
        else:
            return format_response("error", error=f"Unknown action: {action}")
    
    except Exception as e:
        log_error(f"Error handling notifications command: {e}", "handle_notifications_command")
        return format_response("error", error=str(e))