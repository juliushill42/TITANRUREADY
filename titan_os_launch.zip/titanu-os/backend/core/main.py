"""
Titan OS v2.5 Core - Main Entry Point
STDIN/STDOUT JSON Protocol Handler

Unified command router for TitanU OS. All handlers are consolidated here
with proper fallbacks for optional features.
"""
import sys
import json
import os
import requests
from typing import Dict, Any
from pathlib import Path
from datetime import datetime

# Core utilities (required)
from utils import format_response, send_response, log_error
from boot_sequence import handle_boot

# Core agents (local - backwards compatible)
from file_agent import handle_file_command
from memory_agent import handle_memory_command
from browser_agent import handle_browser_command
from voice_agent import handle_voice_command
from personality import get_titan_prompt, format_titan_response
from notifications import handle_notifications_command, notifications

# Add handlers directory to path
sys.path.insert(0, str(Path(__file__).parent.parent / "handlers"))

# Optional handlers from handlers/ directory with graceful fallbacks
# These provide enhanced functionality when available

# File handler (enhanced file operations)
try:
    from files import handle_files, handle_upload, ALLOWED_EXTENSIONS
    HAS_FILES_HANDLER = True
except ImportError:
    HAS_FILES_HANDLER = False
    handle_upload = None
    ALLOWED_EXTENSIONS = []

# Browser handler (secure quarantined browser)
try:
    from browser import handle_browser
    HAS_BROWSER_HANDLER = True
except ImportError:
    HAS_BROWSER_HANDLER = False
    handle_browser = None

# Agents handler (custom agents system)
try:
    from agents import handle_agents, detect_agent_intent
    HAS_AGENTS_HANDLER = True
except ImportError:
    HAS_AGENTS_HANDLER = False
    handle_agents = None
    detect_agent_intent = lambda x: {"intent": None}

# File watcher handler (background file monitoring)
try:
    from agents.file_watcher import handle_watcher_command, watcher_manager
    HAS_WATCHER_HANDLER = True
except ImportError:
    HAS_WATCHER_HANDLER = False
    handle_watcher_command = None
    watcher_manager = None

# Scheduler handler (scheduled tasks)
try:
    from agents.scheduler import handle_schedule_command, scheduler
    HAS_SCHEDULER_HANDLER = True
except ImportError:
    HAS_SCHEDULER_HANDLER = False
    handle_schedule_command = None
    scheduler = None

# Load environment variables from .env file
env_path = Path(__file__).resolve().parents[3] / ".env"
if env_path.exists():
    with open(env_path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, value = line.split("=", 1)
                os.environ.setdefault(key.strip(), value.strip())


# ============================================================================
# SYSTEM HANDLERS
# ============================================================================

async def call_ollama(system_prompt: str, user_prompt: str, model: str) -> str:
    """
    Call Ollama API for LLM inference.
    
    Args:
        system_prompt: System prompt to use
        user_prompt: User's prompt
        model: Model name
    
    Returns:
        str: LLM response
    """
    base_url = os.getenv("TITAN_LLM_BASE_URL", "http://localhost:11434/v1")
    api_key = os.getenv("TITAN_LLM_API_KEY", "ollama")
    
    response = requests.post(
        f"{base_url}/chat/completions",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        },
        json={
            "model": model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            "temperature": 0.7
        },
        timeout=120
    )
    response.raise_for_status()
    data = response.json()
    return data["choices"][0]["message"]["content"]


async def llm_callback(prompt: str) -> str:
    """LLM callback for background agents."""
    system_prompt = get_titan_prompt()
    response = await call_ollama(system_prompt, prompt, "qwen2.5-coder:3b")
    return format_titan_response(response)


async def notify_callback(notif: dict):
    """Send notification."""
    await notifications.add(notif)


def handle_shutdown(params: Dict) -> Dict:
    """Handle graceful shutdown."""
    # Stop all watchers on shutdown
    if HAS_WATCHER_HANDLER and watcher_manager:
        try:
            watcher_manager.stop_all()
        except Exception as e:
            log_error(str(e), "Watcher shutdown")
    
    # Stop scheduler on shutdown
    if HAS_SCHEDULER_HANDLER and scheduler:
        try:
            scheduler.stop()
        except Exception as e:
            log_error(str(e), "Scheduler shutdown")
    
    return format_response("success", message="Titan Core shutting down. Goodbye.")


def get_system_status() -> Dict:
    """Get current system status and capabilities."""
    status = {
        "status": "running",
        "version": "2.5",
        "timestamp": datetime.now().isoformat(),
        "capabilities": {
            "llm": True,  # Always available if Ollama is running
            "files": True,  # Core file operations always available
            "memory": True,  # Core memory operations always available
            "voice": True,  # Voice transcription available
        },
        "handlers": {
            "files_enhanced": HAS_FILES_HANDLER,
            "browser_secure": HAS_BROWSER_HANDLER,
            "agents": HAS_AGENTS_HANDLER,
        },
        "allowed_file_extensions": ALLOWED_EXTENSIONS if HAS_FILES_HANDLER else [],
    }
    return format_response("success", data=status)


# ============================================================================
# PROMPT HANDLER WITH AGENT INTENT DETECTION
# ============================================================================

def handle_prompt(params: Dict) -> Dict:
    """
    Handle prompt command - send user message to Ollama LLM.
    Detects agent-related intents and routes accordingly.
    
    Args:
        params: Dict with 'text' key containing user message
        
    Returns:
        Response dict with 'response' key containing AI response
    """
    text = params.get("text", "")
    if not text:
        return format_response("error", error="No text provided")
    
    # Check for agent intent first (only if agents handler available)
    intent = detect_agent_intent(text) if HAS_AGENTS_HANDLER else {"intent": None}
    
    if intent.get("intent") == "create" and HAS_AGENTS_HANDLER:
        result = handle_agents("create_from_description", {"description": text})
        if result.get("success"):
            agent = result.get("agent", {})
            return format_response("success", data={
                "response": f"✅ Agent '{agent.get('display_name')}' created successfully!\n\n**Role:** {agent.get('role')}\n**Capabilities:** {', '.join(agent.get('capabilities', []))}\n\nYou can now use this agent with `@{agent.get('agent_id')} <message>` or `ask {agent.get('display_name')} to <task>`",
                "agent": agent
            })
        return format_response("error", error=result.get("error", "Failed to create agent"))
    
    elif intent.get("intent") == "list" and HAS_AGENTS_HANDLER:
        result = handle_agents("list", {})
        if result.get("success"):
            agents = result.get("agents", [])
            if not agents:
                response_text = "No agents available yet. Create one with 'create an agent that...'"
            else:
                lines = ["**Available Agents:**\n"]
                for agent in agents:
                    agent_type = "📦 Template" if agent.get("type") == "template" else "🤖 Custom"
                    lines.append(f"- {agent_type} **{agent.get('display_name')}** - {agent.get('role')}")
                response_text = "\n".join(lines)
            return format_response("success", data={"response": response_text, "agents": agents})
        return format_response("error", error=result.get("error", "Failed to list agents"))
    
    elif intent.get("intent") == "templates" and HAS_AGENTS_HANDLER:
        result = handle_agents("templates", {})
        if result.get("success"):
            templates = result.get("templates", [])
            lines = ["**Agent Templates:**\n"]
            for t in templates:
                lines.append(f"- **{t.get('display_name')}** ({t.get('template_id')}) - {t.get('role')}")
            lines.append("\nUse a template with: `create an agent based on [template_name]`")
            return format_response("success", data={"response": "\n".join(lines), "templates": templates})
        return format_response("error", error=result.get("error", "Failed to get templates"))
    
    elif intent.get("intent") == "invoke" and HAS_AGENTS_HANDLER:
        # Find agent by name and invoke
        agent_name = intent.get("agent_name", "")
        message = intent.get("message", "")
        
        # Try to find agent by name
        list_result = handle_agents("list", {})
        agent_id = None
        if list_result.get("success"):
            for agent in list_result.get("agents", []):
                if agent_name.lower() in agent.get("display_name", "").lower() or agent_name.lower() == agent.get("agent_id", "").replace("template_", ""):
                    agent_id = agent.get("agent_id")
                    break
        
        if agent_id:
            result = handle_agents("invoke", {"agent_id": agent_id, "message": message})
            if result.get("ready_for_llm"):
                # Use agent's system prompt for this request
                params["text"] = message
                params["system_prompt"] = result.get("system_prompt")
                params["temperature"] = result.get("temperature", 0.7)
                params["agent_context"] = {"agent_id": agent_id, "agent_name": result.get("agent_name")}
                # Fall through to normal LLM handling with agent context
            else:
                return format_response("error", error=result.get("error", "Failed to invoke agent"))
        else:
            return format_response("error", error=f"Agent '{agent_name}' not found. Use /agents to see available agents.")
    
    # Get LLM configuration from environment
    base_url = os.getenv("TITAN_LLM_BASE_URL", "http://localhost:11434/v1")
    api_key = os.getenv("TITAN_LLM_API_KEY", "ollama")
    model = os.getenv("TITAN_MASTER_MODEL", "qwen2.5-coder:3b")
    
    # Query memory for context (only if not using custom agent prompt)
    memory_context = ""
    if not params.get("system_prompt"):
        try:
            # Get recent memories
            memory_result = handle_memory_command("get_memory", {"limit": 10})
            if memory_result.get("success"):
                entries = memory_result.get("data", {}).get("entries", [])
                if entries:
                    memory_lines = []
                    for entry in entries[:5]:  # Last 5 memories
                        content = entry.get("content", "")
                        if content:
                            memory_lines.append(f"- {content}")
                    if memory_lines:
                        memory_context = "\n".join(memory_lines)
            
            # Also search memory for keywords in the user's message
            if len(text.split()) >= 2:  # Only search if message has multiple words
                search_result = handle_memory_command("search_memory", {"query": text, "limit": 3})
                if search_result.get("success"):
                    search_entries = search_result.get("data", {}).get("entries", [])
                    for entry in search_entries:
                        content = entry.get("content", "")
                        if content and content not in memory_context:
                            if memory_context:
                                memory_context += f"\n- {content}"
                            else:
                                memory_context = f"- {content}"
        except Exception as e:
            log_error(f"Memory query failed: {e}", "handle_prompt")
    
    # Use custom system prompt if provided (e.g., from agent), otherwise use TITAN personality with memory
    system_prompt = params.get("system_prompt", get_titan_prompt(memory_context))
    temperature = params.get("temperature", 0.7)
    
    try:
        response = requests.post(
            f"{base_url}/chat/completions",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json"
            },
            json={
                "model": model,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": text}
                ],
                "temperature": temperature
            },
            timeout=120
        )
        response.raise_for_status()
        data = response.json()
        ai_response = data["choices"][0]["message"]["content"]
        
        # Apply TITAN personality formatting (unless overridden by agent)
        if not params.get("system_prompt"):
            ai_response = format_titan_response(ai_response)
        
        response_data = {"response": ai_response}
        
        # Include agent context if present
        if params.get("agent_context"):
            response_data["agent_context"] = params["agent_context"]
        
        return format_response("success", data=response_data)
    except requests.exceptions.ConnectionError:
        return format_response("error", error="LLM not available. Is Ollama running? Start it with: ollama serve")
    except requests.exceptions.Timeout:
        return format_response("error", error="LLM request timed out. The model may be loading or overloaded.")
    except requests.exceptions.HTTPError as e:
        if e.response.status_code == 404:
            return format_response("error", error=f"Model '{model}' not found. Run: ollama pull {model}")
        return format_response("error", error=f"LLM HTTP error: {str(e)}")
    except KeyError:
        return format_response("error", error="Invalid response from LLM")
    except Exception as e:
        log_error(str(e), "handle_prompt")
        return format_response("error", error=f"LLM error: {str(e)}")


# ============================================================================
# COMMAND HANDLERS DICTIONARY
# ============================================================================
# All commands are routed through this dictionary.
# Each handler receives a 'params' dict and returns a response dict.

COMMAND_HANDLERS = {
    # -------------------------------------------------------------------------
    # Boot/System Commands
    # -------------------------------------------------------------------------
    "boot": handle_boot,
    "shutdown": handle_shutdown,
    "status": lambda params: get_system_status(),
    
    # -------------------------------------------------------------------------
    # Main Chat/Prompt (with agent intent detection)
    # -------------------------------------------------------------------------
    "prompt": handle_prompt,
    
    # -------------------------------------------------------------------------
    # File Operations (core - backwards compatible)
    # -------------------------------------------------------------------------
    "save_file": lambda params: handle_file_command("save_file", params),
    "read_file": lambda params: handle_file_command("read_file", params),
    "list_files": lambda params: handle_file_command("list_files", params),
    
    # -------------------------------------------------------------------------
    # Memory Operations
    # -------------------------------------------------------------------------
    "log_memory": lambda params: handle_memory_command("log_memory", params),
    "get_memory": lambda params: handle_memory_command("get_memory", params),
    "clear_memory": lambda params: handle_memory_command("clear_memory", params),
    "delete_memory": lambda params: handle_memory_command("delete_memory", params),
    "search_memory": lambda params: handle_memory_command("search_memory", params),
    "memory_stats": lambda params: handle_memory_command("memory_stats", params),
    
    # -------------------------------------------------------------------------
    # Browser Operations (legacy - using browser_agent.py)
    # -------------------------------------------------------------------------
    "scrape_url": lambda params: handle_browser_command("scrape_url", params),
    "summarize": lambda params: handle_browser_command("summarize", params),
    
    # -------------------------------------------------------------------------
    # Voice Operations
    # -------------------------------------------------------------------------
    "transcribe_audio": lambda params: handle_voice_command("transcribe_audio", params),
}

# -------------------------------------------------------------------------
# Enhanced File Operations (if handler available)
# -------------------------------------------------------------------------
if HAS_FILES_HANDLER:
    COMMAND_HANDLERS["upload_file"] = lambda params: handle_upload(
        params.get("filename"),
        params.get("content"),
        params.get("content_type")
    )
    COMMAND_HANDLERS["files"] = lambda params: handle_files(
        params.get("action", "list"),
        params
    )
else:
    # Fallback upload using basic file operations
    COMMAND_HANDLERS["upload_file"] = lambda params: format_response(
        "error",
        error="Enhanced file upload not available. Use save_file instead."
    )

# -------------------------------------------------------------------------
# Secure Quarantined Browser (DISABLED in v3.0 for security hardening)
# -------------------------------------------------------------------------
# Browser temporarily offline - coming in v3.1 with proper sandboxing
COMMAND_HANDLERS["browser"] = lambda params: format_response(
    "error",
    error="Browser disabled in v3.0 Genesis. Coming in v3.1 with proper sandboxing."
)

# -------------------------------------------------------------------------
# Agent Operations (if handler available)
# -------------------------------------------------------------------------
if HAS_AGENTS_HANDLER:
    COMMAND_HANDLERS["agents"] = lambda params: handle_agents(
        params.get("action", "list"),
        params
    )
    COMMAND_HANDLERS["create_agent"] = lambda params: handle_agents(
        "create_from_description",
        params
    )
else:
    COMMAND_HANDLERS["agents"] = lambda params: format_response(
        "error",
        error="Agent system not available"
    )

# -------------------------------------------------------------------------
# File Watcher Operations (if handler available)
# -------------------------------------------------------------------------
if HAS_WATCHER_HANDLER:
    COMMAND_HANDLERS["watcher"] = lambda params: handle_watcher_command(
        params.get("action", "list"),
        params
    )
    COMMAND_HANDLERS["watch"] = lambda params: handle_watcher_command(
        params.get("action", "list"),
        params
    )
else:
    COMMAND_HANDLERS["watcher"] = lambda params: format_response(
        "error",
        error="File watcher not available. Install with: pip install watchdog"
    )

# -------------------------------------------------------------------------
# Scheduler Operations (if handler available)
# -------------------------------------------------------------------------
if HAS_SCHEDULER_HANDLER:
    COMMAND_HANDLERS["schedule"] = lambda params: handle_schedule_command(
        params.get("action", "list"),
        params
    )
else:
    COMMAND_HANDLERS["schedule"] = lambda params: format_response(
        "error",
        error="Scheduler not available"
    )

# -------------------------------------------------------------------------
# Notifications Operations
# -------------------------------------------------------------------------
COMMAND_HANDLERS["notifications"] = lambda params: handle_notifications_command(
    params.get("action", "list"),
    params
)
COMMAND_HANDLERS["notif"] = lambda params: handle_notifications_command(
    params.get("action", "list"),
    params
)


# ============================================================================
# COMMAND PROCESSOR
# ============================================================================

def process_command(request: Dict[str, Any]) -> Dict[str, Any]:
    """Process a single command and return response"""
    command = request.get("command", "")
    params = request.get("params", {})
    
    if not command:
        return format_response("error", error="No command specified")
    
    handler = COMMAND_HANDLERS.get(command)
    if not handler:
        return format_response("error", error=f"Unknown command: {command}")
    
    try:
        return handler(params)
    except Exception as e:
        log_error(str(e), f"Command: {command}")
        return format_response("error", error=str(e))


# ============================================================================
# MAIN LOOP
# ============================================================================

def main():
    """Main loop - read JSON from STDIN, process, write JSON to STDOUT"""
    log_error("Titan Core v2.5 starting up...", "Startup")
    log_error(f"Handlers loaded - Files: {HAS_FILES_HANDLER}, Browser: {HAS_BROWSER_HANDLER}, Agents: {HAS_AGENTS_HANDLER}, Watcher: {HAS_WATCHER_HANDLER}, Scheduler: {HAS_SCHEDULER_HANDLER}", "Startup")
    
    # Set up file watcher callbacks and start watchers
    if HAS_WATCHER_HANDLER and watcher_manager:
        try:
            watcher_manager.set_callbacks(llm_callback, notify_callback)
            watcher_manager.start_all()
            log_error("File watchers initialized and started", "Startup")
        except Exception as e:
            log_error(f"Failed to start watchers: {e}", "Startup")
    
    # Set up scheduler callbacks and start scheduler
    if HAS_SCHEDULER_HANDLER and scheduler:
        try:
            scheduler.set_callbacks(llm_callback, notify_callback)
            scheduler.start()
            log_error("Scheduler initialized and started", "Startup")
        except Exception as e:
            log_error(f"Failed to start scheduler: {e}", "Startup")
    
    # Send initial ready signal
    send_response(format_response("ready", message="Titan Core v2 awaiting commands"))
    
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        
        try:
            request = json.loads(line)
        except json.JSONDecodeError as e:
            send_response(format_response("error", error=f"Invalid JSON: {e}"))
            continue
        
        response = process_command(request)
        send_response(response)
        
        # Check for shutdown command
        if request.get("command") == "shutdown":
            break


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        send_response(format_response("shutdown", message="Titan Core interrupted"))
    except Exception as e:
        log_error(str(e), "Fatal error")
        send_response(format_response("error", error=f"Fatal error: {e}"))