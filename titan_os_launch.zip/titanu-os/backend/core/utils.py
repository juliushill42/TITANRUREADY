"""
Titan OS v2 - Utility Functions
Safe JSON operations, path handling, drive detection
"""
import json
import os
import sys
import string
from typing import Any, Optional, Dict, List
from pathlib import Path


def safe_json_read(filepath: str) -> Dict[str, Any]:
    """Safely read JSON file, return empty dict on error"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError, PermissionError, IOError):
        return {}


def safe_json_write(filepath: str, data: Dict[str, Any]) -> bool:
    """Safely write JSON file, return success status"""
    try:
        # Ensure parent directory exists
        ensure_directory(filepath)
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return True
    except (PermissionError, IOError, TypeError):
        return False


def get_titan_data_path() -> Path:
    """Get the path to titan_data folder (relative to backend)"""
    # Get the directory where this utils.py file is located (core/)
    core_dir = Path(__file__).parent
    # Go up to backend/ and then into titan_data/
    return core_dir.parent / "titan_data"


def detect_titan_drive() -> Optional[str]:
    """
    Detect Titan USB drive by looking for TITAN_DATA folder.
    On Windows: Check all drive letters (D:, E:, F:, etc.)
    Returns drive letter (e.g., "E:") or None if not found
    """
    if sys.platform != 'win32':
        return None
    
    # Check all possible drive letters (skip A:, B:, C: typically)
    for letter in string.ascii_uppercase[3:]:  # Start from D:
        drive = f"{letter}:"
        titan_data_path = os.path.join(drive, "TITAN_DATA")
        try:
            if os.path.isdir(titan_data_path):
                return drive
        except (PermissionError, OSError):
            # Drive not accessible, skip
            continue
    
    return None


def ensure_directory(filepath: str) -> bool:
    """Ensure parent directory exists for a file path"""
    try:
        parent_dir = os.path.dirname(filepath)
        if parent_dir and not os.path.exists(parent_dir):
            os.makedirs(parent_dir, exist_ok=True)
        return True
    except (PermissionError, OSError):
        return False


def safe_path_join(base: str, *paths: str) -> str:
    """Safely join paths, preventing directory traversal attacks"""
    # Normalize the base path
    base = os.path.normpath(os.path.abspath(base))
    
    # Join and normalize the full path
    joined = os.path.normpath(os.path.join(base, *paths))
    
    # Ensure the result stays within the base directory
    if not joined.startswith(base):
        raise ValueError("Path traversal attempt detected")
    
    return joined


def format_response(status: str, data: Any = None, message: Optional[str] = None, error: Optional[str] = None) -> Dict[str, Any]:
    """Format a standard JSON response"""
    response = {"status": status}
    if data is not None:
        response["data"] = data
    if message:
        response["message"] = message
    if error:
        response["error"] = error
    return response


def send_response(response: Dict[str, Any]) -> None:
    """Send JSON response to STDOUT with flush"""
    print(json.dumps(response), flush=True)


def log_error(error: str, context: str = "") -> None:
    """Log error to stderr for debugging"""
    sys.stderr.write(f"[TITAN ERROR] {context}: {error}\n")
    sys.stderr.flush()