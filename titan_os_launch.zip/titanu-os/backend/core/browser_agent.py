"""
Titan OS v2 - Browser Agent
Handles web operations: URL fetching, text extraction, summarization
Offline-friendly with minimal dependencies
"""
import re
import html
from typing import Dict, Any, Optional
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError

from utils import format_response

# Simple HTML tag stripper (no external dependencies)
def strip_html_tags(html_content: str) -> str:
    """Remove HTML tags and decode entities"""
    # Remove script and style elements
    html_content = re.sub(r'<script[^>]*>.*?</script>', '', html_content, flags=re.DOTALL | re.IGNORECASE)
    html_content = re.sub(r'<style[^>]*>.*?</style>', '', html_content, flags=re.DOTALL | re.IGNORECASE)
    # Remove HTML tags
    html_content = re.sub(r'<[^>]+>', ' ', html_content)
    # Decode HTML entities
    html_content = html.unescape(html_content)
    # Normalize whitespace
    html_content = re.sub(r'\s+', ' ', html_content).strip()
    return html_content

def extract_title(html_content: str) -> Optional[str]:
    """Extract title from HTML"""
    match = re.search(r'<title[^>]*>(.*?)</title>', html_content, re.IGNORECASE | re.DOTALL)
    if match:
        return html.unescape(match.group(1).strip())
    return None

def simple_summarize(text: str, max_sentences: int = 5) -> str:
    """Simple extractive summarization - first N sentences"""
    # Split into sentences
    sentences = re.split(r'(?<=[.!?])\s+', text)
    # Filter out very short sentences
    sentences = [s for s in sentences if len(s) > 20]
    # Return first N sentences
    return ' '.join(sentences[:max_sentences])

def handle_scrape_url(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Fetch and extract text from a URL.
    
    Input params:
        - url: str (required) - URL to fetch
        - timeout: int (optional) - Request timeout in seconds (default: 10)
    
    Output: {"status": "success", "data": {"title": ..., "text": ..., "length": ...}}
    """
    url = params.get("url")
    timeout = params.get("timeout", 10)
    
    if not url:
        return format_response("error", error="Missing required parameter: url")
    
    # Validate URL format
    if not url.startswith(('http://', 'https://')):
        url = 'https://' + url
    
    try:
        # Create request with user agent
        headers = {
            'User-Agent': 'TitanOS/2.0 (Desktop Assistant)'
        }
        req = Request(url, headers=headers)
        
        with urlopen(req, timeout=timeout) as response:
            content_type = response.headers.get('Content-Type', '')
            
            # Only process HTML/text content
            if 'text' not in content_type and 'html' not in content_type:
                return format_response("error", error=f"Unsupported content type: {content_type}")
            
            # Read and decode content
            raw_content = response.read()
            
            # Try to detect encoding
            encoding = 'utf-8'
            if 'charset=' in content_type:
                encoding = content_type.split('charset=')[-1].split(';')[0].strip()
            
            try:
                html_content = raw_content.decode(encoding)
            except UnicodeDecodeError:
                html_content = raw_content.decode('utf-8', errors='ignore')
            
            # Extract data
            title = extract_title(html_content)
            text = strip_html_tags(html_content)
            
            return format_response("success", data={
                "url": url,
                "title": title,
                "text": text[:10000],  # Limit text length
                "length": len(text),
                "truncated": len(text) > 10000
            })
            
    except HTTPError as e:
        return format_response("error", error=f"HTTP Error {e.code}: {e.reason}")
    except URLError as e:
        return format_response("error", error=f"URL Error: {e.reason}")
    except Exception as e:
        return format_response("error", error=f"Failed to fetch URL: {str(e)}")

def handle_summarize(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Summarize text content.
    
    Input params:
        - text: str (required) - Text to summarize
        - max_sentences: int (optional) - Max sentences in summary (default: 5)
    
    Output: {"status": "success", "data": {"summary": ..., "original_length": ...}}
    """
    text = params.get("text")
    max_sentences = params.get("max_sentences", 5)
    
    if not text:
        return format_response("error", error="Missing required parameter: text")
    
    # Simple extractive summarization
    summary = simple_summarize(text, max_sentences)
    
    return format_response("success", data={
        "summary": summary,
        "original_length": len(text),
        "summary_length": len(summary),
        "sentences": max_sentences
    })

def handle_browser_command(command: str, params: Dict[str, Any]) -> Dict[str, Any]:
    """Route browser commands to appropriate handler"""
    handlers = {
        "scrape_url": handle_scrape_url,
        "summarize": handle_summarize,
    }
    
    handler = handlers.get(command)
    if not handler:
        return format_response("error", error=f"Unknown browser command: {command}")
    
    return handler(params)