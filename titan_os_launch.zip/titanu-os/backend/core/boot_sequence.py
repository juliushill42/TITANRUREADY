"""
Titan OS v2 - Boot Sequence Handler
Handles system initialization and drive detection
"""
import os
import platform
from datetime import datetime
from typing import Dict, Any

from utils import (
    format_response, 
    detect_titan_drive, 
    get_titan_data_path,
    safe_json_read,
    safe_json_write
)

def get_system_info() -> Dict[str, Any]:
    """Gather system information for boot report"""
    return {
        "platform": platform.system(),
        "platform_version": platform.version(),
        "python_version": platform.python_version(),
        "boot_time": datetime.now().isoformat(),
    }

def initialize_titan_data() -> bool:
    """Ensure titan_data directory and memory.json exist"""
    data_path = get_titan_data_path()
    memory_file = data_path / "memory.json"
    
    # Create directory if needed
    data_path.mkdir(parents=True, exist_ok=True)
    
    # Initialize memory.json if it doesn't exist or is empty
    if not memory_file.exists():
        initial_memory = {
            "conversations": [],
            "metadata": {
                "version": "2.0",
                "created": datetime.now().isoformat(),
                "last_updated": datetime.now().isoformat()
            }
        }
        safe_json_write(str(memory_file), initial_memory)
    
    return True

def handle_boot(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Handle the boot command.
    
    Input:  {"command": "boot"}
    Output: {
        "status": "online",
        "drive_letter": "<auto or null>",
        "message": "Titan Core Active. Welcome.",
        "data": {
            "system_info": {...},
            "titan_data_path": "...",
            "memory_initialized": true
        }
    }
    """
    # Detect Titan USB drive
    drive_letter = detect_titan_drive()
    
    # Initialize local titan_data
    memory_initialized = initialize_titan_data()
    
    # Get system info
    system_info = get_system_info()
    
    # Determine data path
    if drive_letter:
        titan_data_path = f"{drive_letter}\\TITAN_DATA"
    else:
        titan_data_path = str(get_titan_data_path())
    
    return {
        "status": "online",
        "drive_letter": drive_letter,
        "message": "Titan Core Active. Welcome.",
        "data": {
            "system_info": system_info,
            "titan_data_path": titan_data_path,
            "memory_initialized": memory_initialized,
            "usb_detected": drive_letter is not None
        }
    }