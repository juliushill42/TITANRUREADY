"""
Titan OS v2.5 - Memory Agent
Handles conversation memory: log, retrieve, clear, delete
Uses JSON database stored in titan_data/memory.json
Supports tags, search, and flexible content storage
"""
import os
import hashlib
from datetime import datetime
from typing import Dict, Any, List, Optional
from pathlib import Path

from utils import (
    format_response,
    get_titan_data_path,
    safe_json_read,
    safe_json_write,
    detect_titan_drive
)

def get_memory_file() -> Path:
    """Get the path to memory.json (USB drive or local)"""
    drive = detect_titan_drive()
    if drive:
        return Path(f"{drive}\\TITAN_DATA\\memory.json")
    return get_titan_data_path() / "memory.json"

def load_memory() -> Dict[str, Any]:
    """Load memory from JSON file"""
    memory_file = get_memory_file()
    data = safe_json_read(str(memory_file))
    if not data:
        data = {
            "entries": [],
            "metadata": {
                "version": "2.5",
                "created": datetime.now().isoformat(),
                "last_updated": datetime.now().isoformat()
            }
        }
    # Migration: rename 'conversations' to 'entries' if needed
    if "conversations" in data and "entries" not in data:
        data["entries"] = data.pop("conversations")
    return data

def save_memory(data: Dict[str, Any]) -> bool:
    """Save memory to JSON file"""
    data["metadata"]["last_updated"] = datetime.now().isoformat()
    memory_file = get_memory_file()
    return safe_json_write(str(memory_file), data)

def generate_memory_id(content: str) -> str:
    """Generate unique memory ID"""
    return hashlib.md5(
        f"{content}{datetime.now().isoformat()}".encode()
    ).hexdigest()[:12]

def handle_log_memory(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Log a memory entry (conversation turn or general note).
    
    Input params:
        - content: str (required) - The message/note content
        - role: str (optional) - "user", "assistant", or "system" (for conversation memory)
        - tags: list (optional) - Tags for the entry
        - session_id: str (optional) - Session identifier
        - metadata: dict (optional) - Additional metadata
        - type: str (optional) - Memory type (default: "user")
    
    Output: {"status": "success", "data": {"entry": {...}, "id": ...}}
    """
    content = params.get("content")
    role = params.get("role")
    tags = params.get("tags", [])
    session_id = params.get("session_id", "default")
    metadata = params.get("metadata", {})
    mem_type = params.get("type", "user")
    
    # Content can come from 'content' or we infer from role-based structure
    if not content:
        return format_response("error", error="Missing required parameter: content")
    
    # Validate role if provided
    if role and role not in ["user", "assistant", "system"]:
        return format_response("error", error="Invalid role. Must be 'user', 'assistant', or 'system'")
    
    memory = load_memory()
    
    # Generate unique ID
    memory_id = generate_memory_id(content)
    
    entry = {
        "id": memory_id,
        "timestamp": datetime.now().isoformat(),
        "content": content.strip(),
        "tags": tags if isinstance(tags, list) else [],
        "type": mem_type,
        "session_id": session_id,
        "metadata": metadata
    }
    
    # Include role if provided (for conversation memory)
    if role:
        entry["role"] = role
    
    memory["entries"].append(entry)
    
    # Rotate logs if too large (keep last 1000 entries)
    MAX_ENTRIES = 1000
    if len(memory["entries"]) > MAX_ENTRIES:
        memory["entries"] = memory["entries"][-MAX_ENTRIES:]
    
    if save_memory(memory):
        return format_response("success", data={
            "entry": entry,
            "id": memory_id,
            "total_entries": len(memory["entries"]),
            "session_id": session_id
        }, message="Memory stored")
    else:
        return format_response("error", error="Failed to save memory")

def handle_get_memory(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Retrieve memory entries.
    
    Input params:
        - session_id: str (optional) - Filter by session
        - limit: int (optional) - Max entries to return (default: 50)
        - offset: int (optional) - Offset for pagination (default: 0)
        - tags: list (optional) - Filter by tags
        - search: str (optional) - Search in content
    
    Output: {"status": "success", "data": {"entries": [...], "total": ...}}
    """
    session_id = params.get("session_id")
    limit = params.get("limit", 50)
    offset = params.get("offset", 0)
    tags = params.get("tags")
    search = params.get("search")
    
    memory = load_memory()
    entries = memory.get("entries", [])
    
    # Filter by session if specified
    if session_id:
        entries = [e for e in entries if e.get("session_id") == session_id]
    
    # Filter by tags if specified
    if tags:
        if isinstance(tags, str):
            tags = [tags]
        entries = [e for e in entries if any(t in e.get("tags", []) for t in tags)]
    
    # Filter by search if specified
    if search:
        search_lower = search.lower()
        entries = [e for e in entries if search_lower in e.get("content", "").lower()]
    
    # Sort by timestamp (newest first)
    entries.sort(key=lambda x: x.get("timestamp", ""), reverse=True)
    
    total = len(entries)
    
    # Apply pagination
    paginated_entries = entries[offset:offset + limit]
    
    return format_response("success", data={
        "entries": paginated_entries,
        "total": total,
        "count": len(paginated_entries),
        "limit": limit,
        "offset": offset,
        "metadata": memory.get("metadata", {"version": "2.5"})
    })

def handle_delete_memory(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Delete a specific memory entry.
    
    Input params:
        - id: str (required) - Memory entry ID to delete
    
    Output: {"status": "success", "data": {"deleted": id}}
    """
    memory_id = params.get("id")
    
    if not memory_id:
        return format_response("error", error="Missing required parameter: id")
    
    memory = load_memory()
    original_count = len(memory.get("entries", []))
    
    memory["entries"] = [e for e in memory.get("entries", []) if e.get("id") != memory_id]
    
    if len(memory["entries"]) == original_count:
        return format_response("error", error="Memory entry not found")
    
    if save_memory(memory):
        return format_response("success", data={
            "deleted": memory_id,
            "remaining_count": len(memory["entries"])
        }, message="Memory deleted")
    else:
        return format_response("error", error="Failed to save memory after delete")

def handle_clear_memory(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Clear conversation memory.
    
    Input params:
        - session_id: str (optional) - Clear only specific session
        - confirm: bool (optional) - Must be True to clear (default: True for convenience)
    
    Output: {"status": "success", "data": {"cleared_count": ...}}
    """
    session_id = params.get("session_id")
    confirm = params.get("confirm", True)  # Default to True for convenience
    
    if not confirm:
        return format_response("error", error="Must set 'confirm': true to clear memory")
    
    memory = load_memory()
    original_count = len(memory.get("entries", []))
    
    if session_id:
        # Clear only specific session
        memory["entries"] = [
            e for e in memory.get("entries", [])
            if e.get("session_id") != session_id
        ]
        cleared = original_count - len(memory["entries"])
    else:
        # Clear all
        memory["entries"] = []
        cleared = original_count
    
    if save_memory(memory):
        return format_response("success", data={
            "cleared_count": cleared,
            "remaining_count": len(memory["entries"])
        }, message=f"Cleared {cleared} memory entries")
    else:
        return format_response("error", error="Failed to save memory after clear")

def handle_search_memory(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Search memory entries.
    
    Input params:
        - query: str (required) - Search query
        - limit: int (optional) - Max results (default: 100)
    
    Output: {"status": "success", "data": {"entries": [...], "total": ...}}
    """
    query = params.get("query", "")
    limit = params.get("limit", 100)
    
    return handle_get_memory({"search": query, "limit": limit})

def handle_memory_stats(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Get memory statistics.
    
    Output: {"status": "success", "data": {"total": ..., "by_type": {...}, "by_tag": {...}}}
    """
    memory = load_memory()
    entries = memory.get("entries", [])
    
    type_counts = {}
    tag_counts = {}
    role_counts = {}
    
    for entry in entries:
        # Count by type
        mem_type = entry.get("type", "user")
        type_counts[mem_type] = type_counts.get(mem_type, 0) + 1
        
        # Count by tag
        for tag in entry.get("tags", []):
            tag_counts[tag] = tag_counts.get(tag, 0) + 1
        
        # Count by role (for conversation memory)
        role = entry.get("role")
        if role:
            role_counts[role] = role_counts.get(role, 0) + 1
    
    memory_file = get_memory_file()
    file_size = memory_file.stat().st_size if memory_file.exists() else 0
    
    return format_response("success", data={
        "total": len(entries),
        "by_type": type_counts,
        "by_tag": tag_counts,
        "by_role": role_counts,
        "file_size": file_size,
        "metadata": memory.get("metadata", {})
    })

def handle_memory_command(command: str, params: Dict[str, Any]) -> Dict[str, Any]:
    """Route memory commands to appropriate handler"""
    handlers = {
        "log_memory": handle_log_memory,
        "get_memory": handle_get_memory,
        "clear_memory": handle_clear_memory,
        "delete_memory": handle_delete_memory,
        "search_memory": handle_search_memory,
        "memory_stats": handle_memory_stats,
    }
    
    handler = handlers.get(command)
    if not handler:
        return format_response("error", error=f"Unknown memory command: {command}")
    
    return handler(params)