// === Rotating Placeholder ===
const placeholderLines = [
    "What mission should Titan OS execute next?",
    "Run a task, deploy a specialist, or start a new workflow…",
    "Give Titan OS an objective. The swarm will handle the rest."
];

let placeholderIndex = 0;
function cyclePlaceholder() {
    const el = document.getElementById("task-input");
    if (!el) return;
    el.setAttribute("placeholder", placeholderLines[placeholderIndex]);
    placeholderIndex = (placeholderIndex + 1) % placeholderLines.length;
}
cyclePlaceholder();
setInterval(cyclePlaceholder, 4000);

// Model presets (Ollama tags; user can adjust in code/README)
const MODEL_PRESETS = {
    fast:     { label: "FAST",     model: "phi3:mini" },
    balanced: { label: "BALANCED", model: "llama3.2" },
    quality:  { label: "QUALITY",  model: "qwen2.5:7b" }
};

let currentMode  = localStorage.getItem("titan_mode")  || "fast";
let currentModel = localStorage.getItem("titan_model") || MODEL_PRESETS[currentMode].model;

function updateModeUI() {
    const display = document.getElementById("mode-display");
    const select  = document.getElementById("mode-select");
    if (display) {
        const label = MODEL_PRESETS[currentMode]?.label || currentMode.toUpperCase();
        display.textContent = `MODE: ${label}`;
    }
    if (select) {
        select.value = currentMode;
    }
}

function initModeSelector() {
    const select = document.getElementById("mode-select");
    if (!select) return;
    updateModeUI();
    select.addEventListener("change", (e) => {
        currentMode = e.target.value;
        currentModel = MODEL_PRESETS[currentMode]?.model || currentModel;
        localStorage.setItem("titan_mode", currentMode);
        localStorage.setItem("titan_model", currentModel);
        updateModeUI();
    });
}
initModeSelector();

// Command history
const commandHistory = [];
let historyIndex = -1;

// Slash commands
const commands = [
    { cmd: "/analyze",  label: "Analyze",  desc: "Deep analysis & reasoning",            template: "Analyze this: " },
    { cmd: "/research", label: "Research", desc: "Gather info, compare sources",        template: "Research this topic: " },
    { cmd: "/email",    label: "Email",    desc: "Draft a cold email or campaign",      template: "Draft a cold email about: " },
    { cmd: "/optimize", label: "Optimize", desc: "Improve a system or workflow",        template: "Optimize this workflow: " },
];
let commandMenuVisible = false;

// === WebSocket + Rendering =================================
let ws = new WebSocket(`ws://${window.location.host}/ws`);
let latestState = null;
let lastAgentsJson = "";
let lastChatJson = "";

ws.onopen = () => {
    console.log("WebSocket connected");
};

ws.onclose = () => {
    console.log("WebSocket disconnected");
};

ws.onmessage = (event) => {
    const data = JSON.parse(event.data);
    latestState = data;
    
    // Only re-render if agents changed to prevent flashing
    const agentsJson = JSON.stringify(data.agents);
    if (agentsJson !== lastAgentsJson) {
        lastAgentsJson = agentsJson;
        renderAgents(data.agents);
    }
    
    // Only re-render if chat changed to prevent flashing
    const chatJson = JSON.stringify(data.chat);
    const agentsBusyChanged = lastChatJson !== "" && anyAgentBusy(data.agents) !== anyAgentBusy(latestState?.agents);
    if (chatJson !== lastChatJson || agentsBusyChanged) {
        lastChatJson = chatJson;
        renderChat(data.chat, data.agents);
    }
};

function escapeHtml(text) {
    if (!text) return "";
    return text
        .replace(/&/g,"&amp;")
        .replace(/</g,"&lt;")
        .replace(/>/g,"&gt;")
        .replace(/"/g,"&quot;")
        .replace(/'/g,"&#039;");
}

function renderAgents(agents) {
    const container = document.getElementById("agents");
    container.innerHTML = "";

    agents.forEach(agent => {
        const wrapper = document.createElement("div");
        wrapper.className = "agent-card";

        const led = document.createElement("div");
        let ledClass = "agent-led ";
        if (agent.status === "active") ledClass += "active";
        else if (agent.status === "busy") ledClass += "busy";
        else ledClass += "error";
        led.className = ledClass;

        const body = document.createElement("div");
        body.className = "agent-body";

        const statusClass =
            agent.status === "active" ? "status-active" :
            agent.status === "busy" ? "status-busy" :
            "status-error";

        body.innerHTML = `
            <div class="agent-header-row">
                <div class="agent-name">${escapeHtml(agent.name)}</div>
                <div class="agent-status-pill ${statusClass}">
                    ${agent.status.toUpperCase()}
                </div>
            </div>
            <div class="agent-role">${escapeHtml(agent.role)}</div>
            <div class="agent-meta">
                <span>TASKS: ${agent.task_count}</span>
                <span>${agent.id === "coordinator" ? "ROUTER" : "SPECIALIST"}</span>
            </div>
        `;
        wrapper.appendChild(led);
        wrapper.appendChild(body);
        container.appendChild(wrapper);
    });
}

function anyAgentBusy(agents) {
    return agents && agents.some(a => a.status === "busy");
}

function renderChat(chat, agents) {
    const body = document.getElementById("chat-body");
    body.innerHTML = "";

    chat.forEach(msg => {
        const row = document.createElement("div");
        row.className = "chat-row " + (msg.role === "user" ? "user" : "agent");

        const bubble = document.createElement("div");

        let bubbleClass = "";
        if (msg.role === "user") {
            bubbleClass = "bubble bubble-user";
        } else if (msg.sender === "Coordinator") {
            bubbleClass = "bubble bubble-agent-coordinator";
        } else {
            bubbleClass = "bubble bubble-agent-sub";
        }
        bubble.className = bubbleClass;

        const senderLabel = escapeHtml(msg.sender || (msg.role === "user" ? "Operator" : "Agent"));
        const content = escapeHtml(msg.content);

        bubble.innerHTML = `
            <div class="bubble-meta">${senderLabel}</div>
            <div class="bubble-text">${content}</div>
        `;

        row.appendChild(bubble);
        body.appendChild(row);
    });

    // Typing indicator if any agent is busy
    if (anyAgentBusy(agents)) {
        const trow = document.createElement("div");
        trow.className = "typing-row";
        const tb = document.createElement("div");
        tb.className = "typing-bubble";
        tb.innerHTML = `
            <span>AGENT LINK LIVE</span>
            <div class="typing-dots">
                <span></span><span></span><span></span>
            </div>
        `;
        trow.appendChild(tb);
        body.appendChild(trow);
    }

    body.scrollTop = body.scrollHeight;
}

function transformSlashCommand(text) {
    // If text starts with a known slash command, expand template semantics
    for (const cmd of commands) {
        if (text.startsWith(cmd.cmd)) {
            const rest = text.slice(cmd.cmd.length).trim();
            const combined = `${cmd.template}${rest}`;
            return combined;
        }
    }
    return text;
}

async function submitTask() {
    const input = document.getElementById("task-input");
    let text = input.value.trim();
    if (!text) return;

    // Command history
    commandHistory.push(text);
    historyIndex = commandHistory.length;

    // Slash command expansion
    text = transformSlashCommand(text);

    // Clear input immediately for better UX
    const originalText = input.value;
    input.value = "";
    hideCommandMenu();

    try {
        const response = await fetch("/api/tasks", {
            method:"POST",
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify({
                description:text,
                priority:5,
                model: currentModel    // <- per-request model, stays local
            })
        });
        if (!response.ok) {
            console.error("Task submission failed:", response.status);
            // Restore input if request failed
            input.value = originalText;
        }
    } catch (err) {
        console.error("Task submission error:", err);
        // Restore input if request failed
        input.value = originalText;
    }
}

function applyQuickAction(cmd, fallbackText) {
    const input = document.getElementById("task-input");
    input.value = cmd + fallbackText;
    input.focus();
    showCommandMenu(); // show menu as hint of slash commands
}

function handleHistoryNav(e) {
    const input = document.getElementById("task-input");
    if (commandHistory.length === 0) return;

    if (e.key === "ArrowUp") {
        if (historyIndex > 0) historyIndex--;
        input.value = commandHistory[historyIndex] || "";
        e.preventDefault();
    } else if (e.key === "ArrowDown") {
        if (historyIndex < commandHistory.length - 1) {
            historyIndex++;
            input.value = commandHistory[historyIndex] || "";
        } else {
            historyIndex = commandHistory.length;
            input.value = "";
        }
        e.preventDefault();
    }
}

// Slash command UI
function showCommandMenu() {
    if (commandMenuVisible) return;
    const panel = document.querySelector(".chat-panel");
    const existing = document.getElementById("command-menu");
    if (existing) existing.remove();

    const menu = document.createElement("div");
    menu.className = "command-menu";
    menu.id = "command-menu";

    commands.forEach(c => {
        const item = document.createElement("div");
        item.className = "command-item";
        item.innerHTML = `
            <span>${c.cmd}</span>
            <span class="desc">${c.desc}</span>
        `;
        item.onclick = () => {
            const input = document.getElementById("task-input");
            input.value = c.cmd + " ";
            input.focus();
            hideCommandMenu();
        };
        menu.appendChild(item);
    });

    panel.appendChild(menu);
    commandMenuVisible = true;
}

function hideCommandMenu() {
    const menu = document.getElementById("command-menu");
    if (menu) menu.remove();
    commandMenuVisible = false;
}

document.getElementById("task-input").addEventListener("keypress", (e) => {
    if (e.key === "Enter") submitTask();
});

document.getElementById("task-input").addEventListener("keydown", (e) => {
    if (e.key === "ArrowUp" || e.key === "ArrowDown") {
        handleHistoryNav(e);
    }
});

document.getElementById("task-input").addEventListener("input", (e) => {
    const val = e.target.value;
    if (val.startsWith("/")) {
        showCommandMenu();
    } else {
        hideCommandMenu();
    }
});

// Export transcript
function exportTranscript() {
    if (!latestState || !latestState.chat) {
        alert("No mission log available yet.");
        return;
    }
    const lines = [];
    lines.push("TITAN OS MISSION LOG");
    lines.push(`Timestamp: ${new Date().toISOString()}`);
    lines.push("========================================");
    latestState.chat.forEach(msg => {
        const time = msg.timestamp || "";
        const sender = msg.sender || (msg.role === "user" ? "Operator" : "Agent");
        lines.push(`[${time}] ${sender}:`);
        lines.push(msg.content);
        lines.push("");
    });
    const blob = new Blob([lines.join("\n")], {type: "text/plain"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    const stamp = new Date().toISOString().replace(/[:.]/g,"-");
    a.href = url;
    a.download = `titan_os_mission_log_${stamp}.txt`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
}