# TitanU OS v2.5 - Agents Package
"""
Agents module for TitanU OS Central Brain architecture.
Contains specialized agents: file, browser, memory, voice, and custom agents.
"""

__version__ = "2.5.0"