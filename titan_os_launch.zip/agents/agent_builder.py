"""
TitanU OS v2.5 — Agent Builder
==============================
Create custom agents using natural language.
"""

import json
from pathlib import Path
from typing import Dict, Any, List, Optional
from datetime import datetime
from prompts.core_brain import AGENT_BUILDER_PROMPT

# Custom agents directory
AGENTS_DIR = Path("./agents/custom")
AGENTS_DIR.mkdir(parents=True, exist_ok=True)


class AgentBuilder:
    """
    Creates custom agents from natural language descriptions.
    """
    
    def __init__(self, llm_client):
        self.llm = llm_client
        self.system_prompt = AGENT_BUILDER_PROMPT
    
    async def create_agent(self, description: str) -> Dict[str, Any]:
        """
        Create an agent from a natural language description.
        
        Args:
            description: Natural language description of the agent
            
        Returns:
            Dict with success status and agent config or error
        """
        try:
            # Use LLM to generate agent config
            response = await self.llm.chat(
                system_prompt=self.system_prompt,
                user_prompt=f"Create an agent based on this description:\n\n{description}"
            )
            
            # Parse JSON from response
            start = response.find("{")
            end = response.rfind("}") + 1
            
            if start < 0 or end <= start:
                return {"success": False, "error": "Could not parse agent definition from response"}
            
            agent_json = json.loads(response[start:end])
            
            # Validate required fields
            required_fields = ["agent_id", "display_name", "system_prompt"]
            for field in required_fields:
                if field not in agent_json:
                    return {"success": False, "error": f"Missing required field: {field}"}
            
            # Add metadata
            agent_json["created_at"] = datetime.now().isoformat()
            agent_json["created_by"] = "operator"
            
            # Save agent
            agent_path = AGENTS_DIR / f"{agent_json['agent_id']}.json"
            agent_path.write_text(json.dumps(agent_json, indent=2))
            
            return {
                "success": True,
                "agent": agent_json,
                "path": str(agent_path)
            }
            
        except json.JSONDecodeError as e:
            return {"success": False, "error": f"Invalid JSON in response: {str(e)}"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def list_agents(self) -> List[Dict[str, Any]]:
        """
        List all custom agents.
        
        Returns:
            List of agent configurations
        """
        agents = []
        for agent_path in AGENTS_DIR.glob("*.json"):
            try:
                agent_data = json.loads(agent_path.read_text())
                agents.append(agent_data)
            except (json.JSONDecodeError, IOError):
                continue
        return agents
    
    def get_agent(self, agent_id: str) -> Optional[Dict[str, Any]]:
        """
        Get a specific agent by ID.
        
        Args:
            agent_id: The agent's unique identifier
            
        Returns:
            Agent configuration or None if not found
        """
        agent_path = AGENTS_DIR / f"{agent_id}.json"
        if agent_path.exists():
            try:
                return json.loads(agent_path.read_text())
            except (json.JSONDecodeError, IOError):
                return None
        return None
    
    def delete_agent(self, agent_id: str) -> bool:
        """
        Delete a custom agent.
        
        Args:
            agent_id: The agent's unique identifier
            
        Returns:
            True if deleted, False otherwise
        """
        agent_path = AGENTS_DIR / f"{agent_id}.json"
        if agent_path.exists():
            try:
                agent_path.unlink()
                return True
            except IOError:
                return False
        return False
    
    def update_agent(self, agent_id: str, updates: Dict[str, Any]) -> Dict[str, Any]:
        """
        Update an existing agent.
        
        Args:
            agent_id: The agent's unique identifier
            updates: Dict of fields to update
            
        Returns:
            Dict with success status and updated agent or error
        """
        agent = self.get_agent(agent_id)
        if not agent:
            return {"success": False, "error": f"Agent not found: {agent_id}"}
        
        # Apply updates
        for key, value in updates.items():
            if key != "agent_id":  # Don't allow changing ID
                agent[key] = value
        
        agent["updated_at"] = datetime.now().isoformat()
        
        # Save
        agent_path = AGENTS_DIR / f"{agent_id}.json"
        try:
            agent_path.write_text(json.dumps(agent, indent=2))
            return {"success": True, "agent": agent}
        except IOError as e:
            return {"success": False, "error": str(e)}
    
    def export_agent(self, agent_id: str) -> Optional[str]:
        """
        Export an agent as JSON string for sharing.
        
        Args:
            agent_id: The agent's unique identifier
            
        Returns:
            JSON string or None if not found
        """
        agent = self.get_agent(agent_id)
        if agent:
            return json.dumps(agent, indent=2)
        return None
    
    def import_agent(self, agent_json: str) -> Dict[str, Any]:
        """
        Import an agent from JSON string.
        
        Args:
            agent_json: JSON string of agent configuration
            
        Returns:
            Dict with success status and agent or error
        """
        try:
            agent_data = json.loads(agent_json)
            
            # Validate required fields
            required_fields = ["agent_id", "display_name", "system_prompt"]
            for field in required_fields:
                if field not in agent_data:
                    return {"success": False, "error": f"Missing required field: {field}"}
            
            # Check if agent already exists
            if self.get_agent(agent_data["agent_id"]):
                return {"success": False, "error": f"Agent already exists: {agent_data['agent_id']}"}
            
            agent_data["imported_at"] = datetime.now().isoformat()
            
            # Save
            agent_path = AGENTS_DIR / f"{agent_data['agent_id']}.json"
            agent_path.write_text(json.dumps(agent_data, indent=2))
            
            return {"success": True, "agent": agent_data}
            
        except json.JSONDecodeError as e:
            return {"success": False, "error": f"Invalid JSON: {str(e)}"}
        except Exception as e:
            return {"success": False, "error": str(e)}